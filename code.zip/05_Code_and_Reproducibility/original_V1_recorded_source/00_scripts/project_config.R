options(stringsAsFactors = FALSE)

if (.Platform$OS.type == "windows") {
  suppressWarnings(Sys.setlocale("LC_ALL", "Chinese"))
}

default_project_root <- file.path("F:/WCD", paste0("WCD", intToUtf8(c(0x751F, 0x4FE1))))
project_root_override <- Sys.getenv("WCD_PROJECT_ROOT", unset = "")
if (nzchar(project_root_override)) {
  # Keep an ASCII junction path unresolved so older Windows R builds do not
  # corrupt the UTF-8 target returned by normalizePath().
  PROJECT_ROOT <- chartr("\\", "/", project_root_override)
  stopifnot(dir.exists(PROJECT_ROOT))
} else {
  PROJECT_ROOT <- normalizePath(default_project_root, winslash = "/", mustWork = TRUE)
}
DIRS <- list(
  scripts = file.path(PROJECT_ROOT, "00_scripts"),
  data = file.path(PROJECT_ROOT, "01_data"),
  results = file.path(PROJECT_ROOT, "02_results"),
  figures = file.path(PROJECT_ROOT, "figures_for_article"),
  tables = file.path(PROJECT_ROOT, "tables_for_article"),
  manuscript = file.path(PROJECT_ROOT, "manuscript"),
  logs = file.path(PROJECT_ROOT, "logs")
)

stopifnot(all(vapply(DIRS, dir.exists, logical(1))))

SEED <- 20260826L
set.seed(SEED)

MIN_CELLS_PER_SAMPLE_CELLTYPE <- 20L
MIN_SAMPLES_PER_GROUP <- 3L
FDR_THRESHOLD <- 0.05
MIN_ABS_LOG2FC <- log2(1.25)

write_tsv_atomic <- function(x, path) {
  tmp <- paste0(path, ".tmp")
  data.table::fwrite(x, tmp, sep = "\t", quote = FALSE, na = "NA")
  if (file.exists(path)) file.remove(path)
  stopifnot(file.rename(tmp, path))
  invisible(path)
}

save_rds_atomic <- function(x, path, compress = "xz") {
  tmp <- paste0(path, ".tmp")
  saveRDS(x, tmp, compress = compress)
  if (file.exists(path)) file.remove(path)
  stopifnot(file.rename(tmp, path))
  invisible(path)
}
