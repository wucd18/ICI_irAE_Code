param(
    [string]$ProjectDir = (Split-Path -Parent $PSScriptRoot),
    [string]$Rscript = 'D:\software\R\R-4.2.2\bin\Rscript.exe',
    [string]$Python = (Join-Path (Split-Path -Parent $PSScriptRoot) 'python_env\Scripts\python.exe')
)

$ErrorActionPreference = 'Stop'
$ProjectDir = (Resolve-Path -LiteralPath $ProjectDir).Path
$env:WCD_PROJECT_ROOT = $ProjectDir
$log = Join-Path $ProjectDir 'logs\reproduction_run.log'

function Run-Step {
    param([string]$Name, [string]$Program, [string[]]$Arguments)
    $started = Get-Date -Format o
    Add-Content -LiteralPath $log -Value "START`t$started`t$Name"
    & $Program @Arguments 2>&1 | Tee-Object -FilePath $log -Append
    if ($LASTEXITCODE -ne 0) { throw "Step failed: $Name" }
    Add-Content -LiteralPath $log -Value "END`t$(Get-Date -Format o)`t$Name"
}

Set-Content -LiteralPath $log -Value "WCD reproducibility run started`t$(Get-Date -Format o)"

Run-Step 'core sample inventory' $Python @((Join-Path $PSScriptRoot 'build_core_sample_inventory.py'), $ProjectDir)
Run-Step 'primary patient-level differential expression' $Rscript @((Join-Path $PSScriptRoot 'run_patient_level_pseudobulk_de.R'), $ProjectDir)
Run-Step 'primary pathway enrichment' $Rscript @((Join-Path $PSScriptRoot 'run_celltype_pathway_enrichment.R'), $ProjectDir)
Run-Step 'independent colon differential expression' $Rscript @((Join-Path $PSScriptRoot 'run_independent_colon_pseudobulk_de.R'), $ProjectDir)
Run-Step 'independent colon pathway enrichment' $Rscript @((Join-Path $PSScriptRoot 'run_independent_colon_pathway_enrichment.R'), $ProjectDir)
Run-Step 'spatial sample-level differential expression' $Rscript @((Join-Path $PSScriptRoot 'run_spatial_sample_pseudobulk_de.R'), $ProjectDir)
Run-Step 'spatial sample-level pathway enrichment' $Rscript @((Join-Path $PSScriptRoot 'run_spatial_pathway_enrichment.R'), $ProjectDir)
Run-Step 'frozen module derivation and validation' $Rscript @((Join-Path $PSScriptRoot 'derive_and_validate_irAE_modules.R'), $ProjectDir)
Run-Step 'human organoid rescue screen' $Rscript @((Join-Path $PSScriptRoot 'screen_GSE313368_irAE_rescue.R'), $ProjectDir)
Run-Step 'organoid off-target audit' $Rscript @((Join-Path $PSScriptRoot 'audit_organoid_offtarget_pathways.R'), $ProjectDir)
Run-Step 'TNFSF12 signature reciprocity' $Rscript @((Join-Path $PSScriptRoot 'validate_TNFSF12_signature_reciprocity.R'), $ProjectDir)
Run-Step 'cross-organ receiver analysis' $Python @((Join-Path $PSScriptRoot 'analyze_cross_organ_receiver_programs.py'), $ProjectDir)
Run-Step 'patient-level module performance' $Python @((Join-Path $PSScriptRoot 'evaluate_patient_level_module_performance.py'), $ProjectDir)
Run-Step 'lung source-confounded sensitivity' $Rscript @((Join-Path $PSScriptRoot 'run_lung_source_confounded_sensitivity.R'), $ProjectDir)
Run-Step 'TCR evidence' $Python @((Join-Path $PSScriptRoot 'analyze_TCR_evidence.py'), $ProjectDir)
Run-Step 'TWEAK-SORL1 localization' $Python @((Join-Path $PSScriptRoot 'analyze_TWEAK_SORL1_axis.py'), $ProjectDir)
Run-Step 'ICI efficacy guardrail input audit' $Rscript @((Join-Path $PSScriptRoot 'audit_icb_guardrail_inputs.R'), $ProjectDir)
Run-Step 'ICI efficacy guardrails and downstream ranking' $Rscript @((Join-Path $PSScriptRoot 'run_icb_efficacy_guardrail.R'), $ProjectDir)
Run-Step 'final evidence synthesis tables' $Python @((Join-Path $PSScriptRoot 'build_final_synthesis_tables.py'), $ProjectDir)
Run-Step 'manuscript figures' $Rscript @((Join-Path $PSScriptRoot 'make_manuscript_figures.R'), $ProjectDir)
Run-Step 'submission manuscript DOCX' $Python @(
    (Join-Path $PSScriptRoot 'build_manuscript_docx.py'),
    (Join-Path $ProjectDir 'manuscript\manuscript_full.md'),
    (Join-Path $ProjectDir 'manuscript\manuscript_full.docx')
)
Run-Step 'data checksum manifest' $Python @((Join-Path $PSScriptRoot 'build_download_manifest.py'), $ProjectDir)

& $Rscript -e 'sessionInfo(); cat("\nKey package versions:\n"); pkgs <- c("edgeR","limma","fgsea","survival","metafor","ggplot2","cowplot","dplyr","readr"); for (p in pkgs) cat(p, if (requireNamespace(p, quietly=TRUE)) as.character(packageVersion(p)) else "NOT_INSTALLED", "\n")' 2>&1 | Set-Content -LiteralPath (Join-Path $ProjectDir 'logs\R_sessionInfo.txt')
& $Python -c 'import importlib.metadata as m,platform,sys; print("platform",platform.platform()); print("python",sys.version); pkgs=["pandas","numpy","scipy","scanpy","anndata","scikit-learn","lifelines","statsmodels","pyarrow","python-docx"]; installed={d.metadata["Name"].lower():d.version for d in m.distributions()}; [print(p, installed.get(p.lower(), "NOT_INSTALLED")) for p in pkgs]; print("\npip freeze:"); print("\n".join(sorted("{}=={}".format(k,v) for k,v in installed.items())))' 2>&1 | Set-Content -LiteralPath (Join-Path $ProjectDir 'logs\Python_environment.txt')

Run-Step 'reproducibility inventory' $Python @((Join-Path $PSScriptRoot 'build_reproducibility_inventory.py'), $ProjectDir)
Run-Step 'final package verification' $Python @((Join-Path $PSScriptRoot 'verify_final_package.py'), $ProjectDir)

Add-Content -LiteralPath $log -Value "WCD reproducibility run completed`t$(Get-Date -Format o)"
