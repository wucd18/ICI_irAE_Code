#!/usr/bin/env python3
"""Fail-fast verification of the manuscript-facing WCD package."""

from pathlib import Path
from datetime import datetime, timezone
import argparse
import pandas as pd


def check(condition, message, results):
    results.append(("PASS" if condition else "FAIL", message))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("project_dir", type=Path)
    args = parser.parse_args()
    root = args.project_dir.resolve()
    tables = root / "tables_for_article"
    figures = root / "figures_for_article"
    manuscript = root / "manuscript"
    logs = root / "logs"
    results = []

    for ext in ["pdf", "tiff", "png"]:
        files = list(figures.glob(f"*.{ext}"))
        check(len(files) == 12, f"12 final figure files with extension .{ext} (found {len(files)})", results)
        check(all(p.stat().st_size > 1000 for p in files), f"all .{ext} figures are non-empty", results)

    tsvs = sorted(tables.glob("*.tsv"))
    check(len(tsvs) >= 60, f"at least 60 manuscript-facing TSV files (found {len(tsvs)})", results)
    bad_tsv = []
    for path in tsvs:
        try:
            df = pd.read_csv(path, sep="\t", nrows=5)
            if len(df.columns) < 1:
                bad_tsv.append(path.name)
        except Exception:
            bad_tsv.append(path.name)
    check(not bad_tsv, f"all TSV files parse successfully; failures={bad_tsv}", results)

    s21 = pd.read_csv(tables / "Table_S21_frozen_module_definitions.tsv", sep="\t")
    if "analysis_role" in s21.columns:
        check(not s21["analysis_role"].astype(str).str.contains("data_derived_injury_module", regex=False).any(),
              "no obsolete data_derived_injury_module terminology remains", results)
    else:
        check(False, "Table S21 contains analysis_role", results)

    decisions = pd.read_csv(tables / "Table_S59_final_candidate_decision_matrix.tsv", sep="\t")
    tn = decisions.loc[decisions.candidate == "TNFSF12", "final_decision"].tolist()
    so = decisions.loc[decisions.candidate == "SORL1", "final_decision"].tolist()
    check(tn == ["REJECT_SYSTEMIC_TRANSLATION"], "TNFSF12 is rejected for systemic translation", results)
    check(so == ["EXPLORATORY_DOWNSTREAM_MARKER"], "SORL1 remains an exploratory downstream marker", results)

    claims = pd.read_csv(tables / "Table_S61_claim_evidence_map.tsv", sep="\t")
    check(set(["supported", "rejected", "exploratory", "not_claimed"]).issubset(set(claims.status)),
          "claim map contains positive, rejected, exploratory and non-claimed categories", results)

    manuscript_path = manuscript / "manuscript_full.md"
    text = manuscript_path.read_text(encoding="utf-8")
    forbidden = [
        "systemic TNFSF12 is safe",
        "SORL1 is a therapeutic target",
        "three-organ receiver-function program",
    ]
    check(not any(term.lower() in text.lower() for term in forbidden), "unsupported affirmative claims are absent", results)
    check("no spatial localization" in text.lower() or "did not perform spatial" in text.lower(),
          "spatial-coordinate limitation is explicit", results)

    required = [
        manuscript / "manuscript_full.md",
        manuscript / "manuscript_full.docx",
        manuscript / "cover_letter.md",
        manuscript / "report_for_user_CN.md",
        root / "README.md",
        logs / "R_sessionInfo.txt",
        logs / "Python_environment.txt",
        tables / "Table_1_study_cohorts_and_roles.tsv",
        tables / "Table_2_final_candidate_decisions.tsv",
        tables / "Table_S10_download_and_file_manifest.tsv",
        tables / "Table_S62_reproducibility_script_inventory.tsv",
        tables / "Table_S63_final_artifact_manifest.tsv",
    ]
    check(all(p.exists() and p.stat().st_size > 0 for p in required), "all required manuscript and provenance files exist", results)

    passed = all(status == "PASS" for status, _ in results)
    stamp = datetime.now(timezone.utc).isoformat()
    lines = [f"WCD final package verification", f"checked_utc\t{stamp}", f"overall\t{'PASS' if passed else 'FAIL'}", ""]
    lines.extend(f"{status}\t{message}" for status, message in results)
    report = "\n".join(lines) + "\n"
    (logs / "final_package_verification.txt").write_text(report, encoding="utf-8")
    print(report)
    if not passed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
