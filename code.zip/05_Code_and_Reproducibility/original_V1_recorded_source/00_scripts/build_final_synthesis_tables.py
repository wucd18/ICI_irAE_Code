#!/usr/bin/env python3
"""Build manuscript-facing cohort, gate, candidate, and claim-evidence tables."""

from pathlib import Path
import argparse
import numpy as np
import pandas as pd


def truth(value):
    if pd.isna(value):
        return False
    if isinstance(value, str):
        return value.strip().lower() in {"true", "1", "yes"}
    return bool(value)


def yn(value):
    return "yes" if truth(value) else "no"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("project_dir", type=Path)
    args = parser.parse_args()
    root = args.project_dir.resolve()
    tables = root / "tables_for_article"

    catalog = pd.read_csv(tables / "Table_S1_dataset_catalog.tsv", sep="\t")
    used = catalog[catalog["final_role"] != "not used"].copy()
    table1 = used[[
        "accession", "organ_or_context", "condition", "assays", "analysis_n",
        "control_design", "final_role", "decision_note",
    ]].rename(columns={
        "accession": "cohort",
        "organ_or_context": "context",
        "analysis_n": "evaluable_samples",
        "final_role": "role_in_study",
        "decision_note": "key_constraint",
    })
    table1.to_csv(tables / "Table_1_study_cohorts_and_roles.tsv", sep="\t", index=False)

    screen = pd.read_csv(tables / "Table_S23_GSE313368_irAE_rescue_screen.tsv", sep="\t")
    guard = pd.read_csv(tables / "Table_S30_candidate_tumor_efficacy_guardrail_summary.tsv", sep="\t")
    off = pd.read_csv(tables / "Table_S48_organoid_candidate_offtarget_summary.tsv", sep="\t")
    downstream = pd.read_csv(tables / "Table_S43_TNFSF12_downstream_multicohort_ranking.tsv", sep="\t")

    ligands = ["TNFSF12", "INHBA", "BMP2", "BMP4", "TGFB1", "TGFB2", "TGFB3"]
    rows = []
    for candidate in ligands:
        s = screen.loc[screen["perturbation"] == candidate].iloc[0]
        g = guard.loc[guard["candidate"] == candidate].iloc[0]
        o = off.loc[off["perturbation"] == candidate].iloc[0]
        inflammatory = int(o["n_positive_inflammatory_fdr05"]) > 0
        ifn_loss = int(o["n_negative_IFN_fdr05"]) > 0
        tumor_fail = str(g["guardrail_status"]).startswith("FAIL")
        expanded_pass = (
            truth(s["function_rescue_gate"])
            and truth(s["disease_program_not_aggravated_gate"])
            and not inflammatory
            and not ifn_loss
            and str(g["guardrail_status"]) == "NO_DETECTED_HARM_not_equivalent_to_safety"
        )

        reasons = []
        if not truth(s["disease_program_not_aggravated_gate"]):
            reasons.append("aggravates a prespecified disease program")
        if inflammatory:
            reasons.append("activates inflammatory Hallmark pathways")
        if ifn_loss:
            reasons.append("suppresses at least one interferon Hallmark pathway")
        if tumor_fail:
            reasons.append("detected adverse tumour-ICI association")
        elif str(g["guardrail_status"]).startswith("CONCERN"):
            reasons.append("tumour guardrail concern")
        if not reasons:
            reasons.append("absence of detected efficacy harm is not evidence of safety")

        rows.append({
            "candidate": candidate,
            "candidate_level": "systemic ligand perturbation",
            "organoid_function_rescue": yn(s["function_rescue_gate"]),
            "legacy_module_decoupling_gate": yn(s["full_decoupling_gate"]),
            "expanded_offtarget_gate": "pass" if expanded_pass else "fail",
            "positive_inflammatory_pathways_fdr05": int(o["n_positive_inflammatory_fdr05"]),
            "negative_interferon_pathways_fdr05": int(o["n_negative_IFN_fdr05"]),
            "tumor_efficacy_guardrail": g["guardrail_status"],
            "independent_tissue_support": "not applicable to the administered ligand as a whole",
            "final_decision": "REJECT_SYSTEMIC_TRANSLATION",
            "decision_basis": "; ".join(reasons),
            "claim_allowed": "mechanistic clue/local downstream program only",
        })

    sorl1 = downstream.loc[downstream["gene"] == "SORL1"].iloc[0]
    rows.append({
        "candidate": "SORL1",
        "candidate_level": "TNFSF12 downstream repair-core gene",
        "organoid_function_rescue": (
            f"up log2FC={sorl1['organoid_log2FC']:.3f}, FDR={sorl1['organoid_fdr']:.3g}"
        ),
        "legacy_module_decoupling_gate": "not applicable",
        "expanded_offtarget_gate": "not established for direct manipulation",
        "positive_inflammatory_pathways_fdr05": np.nan,
        "negative_interferon_pathways_fdr05": np.nan,
        "tumor_efficacy_guardrail": (
            f"response g={sorl1['response_meta_g']:.3f} "
            f"[{sorl1['response_ci_low']:.3f},{sorl1['response_ci_high']:.3f}]; "
            f"OS HR={sorl1['os_meta_hr']:.3f} "
            f"[{sorl1['os_ci_low']:.3f},{sorl1['os_ci_high']:.3f}]"
        ),
        "independent_tissue_support": (
            f"down in {int(sorl1['independent_n_down'])}/"
            f"{int(sorl1['independent_n_families'])} epithelial families; "
            f"spatial logFC={sorl1['spatial_logFC']:.3f}, FDR={sorl1['spatial_fdr']:.3g}"
        ),
        "final_decision": "EXPLORATORY_DOWNSTREAM_MARKER",
        "decision_basis": (
            "convergent organoid and independent-colitis evidence, but no direct SORL1 "
            "perturbation and no established systemic or tumour safety"
        ),
        "claim_allowed": "candidate marker/mechanistic hypothesis; not a therapeutic target",
    })
    final = pd.DataFrame(rows)
    final.to_csv(tables / "Table_2_final_candidate_decisions.tsv", sep="\t", index=False)
    final.to_csv(tables / "Table_S59_final_candidate_decision_matrix.tsv", sep="\t", index=False)

    gate_rows = [
        ("G1", "Novelty", "PASS_WITH_BOUNDARIES", "The work pivots away from published generic IFN classifiers, CTL taxonomies and JAK1 intervention.", "Table_S7"),
        ("G2", "Patient-level inference", "PASS", "Core single-cell tests use patient/sample pseudobulk; cell counts are not treated as biological replicates.", "Tables_S3-S6,S11-S19,S44-S46,S52-S58"),
        ("G3", "Cross-organ evidence", "PASS_FOR_SHARED_ATTACK; RESTRICTED_FOR_RECEIVER_FUNCTION", "Heart and colon support shared attack plus receiver divergence; confounded lung data support attack only. Receiver-function claims remain two-organ.", "Tables_S52-S54,S57-S58"),
        ("G4", "Independent validation", "PASS_FOR_COLON_MODULES", "Frozen colon modules reproduce in independent epithelial families and an independent spatial-transcriptomics platform at sample level.", "Tables_S21-S22,S49-S50,S55-S56"),
        ("G5", "Efficacy contrast", "PASS_FOR_TRIAGE", "Five tumour ICI cohorts provide response and/or survival guardrails; these tests reject or constrain candidates rather than proving safety.", "Tables_S24-S30,S38-S43"),
        ("G6", "Causal anchor", "PASS_FOR_LIGAND; NOT_MET_FOR_SORL1_TARGET", "Human organoid ligand perturbation anchors TNFSF12 effects. SORL1 lacks direct perturbation and is not nominated as a target.", "Tables_S20,S23,S38,S43"),
        ("G7", "Safety", "FAIL_FOR_SYSTEMIC_TRANSLATION", "Expanded organoid off-target and tumour guardrails reject all seven systemic ligand candidates, including TNFSF12.", "Tables_S47-S48,S59"),
        ("G8", "Reproducibility", "PASS_WHEN_PACKAGE_VERIFICATION_COMPLETES", "Scripts, data manifest, environment capture and manuscript-facing outputs are delivered together; final verification log records reruns.", "Table_S10;Table_S61;logs"),
    ]
    gates = pd.DataFrame(gate_rows, columns=["gate_id", "gate", "final_status", "evidence_based_interpretation", "supporting_outputs"])
    gates.to_csv(tables / "Table_S60_final_gate_status.tsv", sep="\t", index=False)

    claims = pd.DataFrame([
        ("C1", "Heart and colon nonimmune receiver compartments share immune-visibility/attack programs.", "supported", "Table_S52;Table_S53", "Does not imply identical downstream tissue dysfunction."),
        ("C2", "Receiver remodeling is organ-divergent beyond the shared attack response.", "supported", "Table_S53;Table_S54", "Based on heart and colon only."),
        ("C3", "Frozen ICI-colitis epithelial disease-up and function-loss modules reproduce independently.", "supported", "Table_S22;Table_S55;Table_S56", "Repeatable biology, not a clinical diagnostic classifier."),
        ("C4", "CIP immune cells show a concordant shared-attack signal.", "sensitivity_only", "Table_S57;Table_S58", "Disease and data source are perfectly confounded."),
        ("C5", "Colitis is associated with greater TCR expansion and CD4–CD8 clone sharing.", "exploratory_supported", "Table_S31;Table_S35", "Small cohort; state-level and epithelial-coupling analyses remain exploratory."),
        ("C6", "TNFSF12 restores a reproducible 66-gene epithelial function core and suppresses one disease-associated inflammatory subset.", "supported_as_perturbation_program", "Table_S49;Table_S50", "The broad TNFSF12 response is mixed and is not equivalent to tissue protection."),
        ("C7", "Systemic TNFSF12/Fn14 agonism is supported as a safe therapy.", "rejected", "Table_S30;Table_S47;Table_S48;Table_S59", "Inflammatory/off-target and tumour-context concerns preclude this claim."),
        ("C8", "SORL1 is a convergent downstream repair marker.", "exploratory", "Table_S43;Table_S44;Table_S46", "No direct perturbation or safety proof; not a therapeutic target."),
        ("C9", "Spatial localization of the frozen modules is established.", "not_claimed", "Table_S16-Table_S19", "Coordinates were unavailable; only sample-pseudobulk platform validation is used."),
    ], columns=["claim_id", "candidate_manuscript_claim", "status", "supporting_outputs", "mandatory_boundary"])
    claims.to_csv(tables / "Table_S61_claim_evidence_map.tsv", sep="\t", index=False)

    print(f"Wrote {len(table1)} cohort rows, {len(final)} candidate rows, {len(gates)} gates, and {len(claims)} claim rows")


if __name__ == "__main__":
    main()
