#!/usr/bin/env python3
"""Build the submission manuscript DOCX from the locked Markdown source."""

from __future__ import annotations

import re
import sys
from pathlib import Path

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.style import WD_STYLE_TYPE
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


BLUE = RGBColor(0x2E, 0x74, 0xB5)
DARK_BLUE = RGBColor(0x1F, 0x4D, 0x78)
INK_BLUE = RGBColor(0x0B, 0x25, 0x45)
MUTED = RGBColor(0x66, 0x66, 0x66)
LIGHT = RGBColor(0xF4, 0xF6, 0xF9)
BLACK = RGBColor(0x00, 0x00, 0x00)

ASCII_REPLACEMENTS = {
    "\u2018": "'",
    "\u2019": "'",
    "\u201c": '"',
    "\u201d": '"',
    "\u2013": "-",
    "\u2014": " - ",
    "\u2212": "-",
    "\u2011": "-",
    "\u00a0": " ",
    "\u03c1": "rho",
    "\u03b1": "alpha",
    "\u03b2": "beta",
    "\u03b3": "gamma",
    "\u03ba": "kappa",
    "\u0394": "Delta",
    "\u00d7": "x",
    "\u2264": "<=",
    "\u2265": ">=",
}


def normalize_text(text: str) -> str:
    for old, new in ASCII_REPLACEMENTS.items():
        text = text.replace(old, new)
    # Word may wrap an ASCII hyphen away from a negative number. A no-break
    # hyphen is used only for numeric signs to preserve scientific notation.
    text = re.sub(r"(?<![A-Za-z0-9])-(?=\d)", "\u2011", text)
    return text


def set_run_font(run, name="Calibri", size=None, color=None, bold=None, italic=None):
    run.font.name = name
    rpr = run._element.get_or_add_rPr()
    rfonts = rpr.rFonts
    if rfonts is None:
        rfonts = OxmlElement("w:rFonts")
        rpr.insert(0, rfonts)
    for key in ("ascii", "hAnsi", "eastAsia", "cs"):
        rfonts.set(qn(f"w:{key}"), name)
    if size is not None:
        run.font.size = Pt(size)
    if color is not None:
        run.font.color.rgb = color
    if bold is not None:
        run.bold = bold
    if italic is not None:
        run.italic = italic


def set_style_font(style, name: str, size: float, color: RGBColor, bold=False, italic=False):
    style.font.name = name
    style.font.size = Pt(size)
    style.font.color.rgb = color
    style.font.bold = bold
    style.font.italic = italic
    rpr = style.element.get_or_add_rPr()
    rfonts = rpr.rFonts
    if rfonts is None:
        rfonts = OxmlElement("w:rFonts")
        rpr.insert(0, rfonts)
    for key in ("ascii", "hAnsi", "eastAsia", "cs"):
        rfonts.set(qn(f"w:{key}"), name)


def set_spacing(style, *, before: int, after: int, line: int):
    ppr = style.element.get_or_add_pPr()
    spacing = ppr.find(qn("w:spacing"))
    if spacing is None:
        spacing = OxmlElement("w:spacing")
        ppr.append(spacing)
    spacing.set(qn("w:before"), str(before))
    spacing.set(qn("w:after"), str(after))
    spacing.set(qn("w:line"), str(line))
    spacing.set(qn("w:lineRule"), "auto")


def add_page_field(paragraph):
    run = paragraph.add_run()
    fld_begin = OxmlElement("w:fldChar")
    fld_begin.set(qn("w:fldCharType"), "begin")
    instr = OxmlElement("w:instrText")
    instr.set(qn("xml:space"), "preserve")
    instr.text = " PAGE "
    fld_sep = OxmlElement("w:fldChar")
    fld_sep.set(qn("w:fldCharType"), "separate")
    txt = OxmlElement("w:t")
    txt.text = "1"
    fld_end = OxmlElement("w:fldChar")
    fld_end.set(qn("w:fldCharType"), "end")
    run._r.extend([fld_begin, instr, fld_sep, txt, fld_end])
    set_run_font(run, size=9, color=MUTED)


def add_bottom_border(paragraph, color="D9E2F3", size="6"):
    ppr = paragraph._p.get_or_add_pPr()
    pbdr = ppr.find(qn("w:pBdr"))
    if pbdr is None:
        pbdr = OxmlElement("w:pBdr")
        ppr.append(pbdr)
    bottom = OxmlElement("w:bottom")
    bottom.set(qn("w:val"), "single")
    bottom.set(qn("w:sz"), size)
    bottom.set(qn("w:space"), "1")
    bottom.set(qn("w:color"), color)
    pbdr.append(bottom)


def configure_section(section, running_title: str):
    section.page_width = Inches(8.5)
    section.page_height = Inches(11)
    section.top_margin = Inches(1.0)
    section.right_margin = Inches(1.0)
    section.bottom_margin = Inches(1.0)
    section.left_margin = Inches(1.0)
    section.header_distance = Inches(0.492)
    section.footer_distance = Inches(0.492)

    header = section.header
    hp = header.paragraphs[0]
    hp.alignment = WD_ALIGN_PARAGRAPH.LEFT
    hp.paragraph_format.space_after = Pt(2)
    hr = hp.add_run(normalize_text(running_title))
    set_run_font(hr, size=8.5, color=MUTED, bold=True)
    add_bottom_border(hp)

    footer = section.footer
    fp = footer.paragraphs[0]
    fp.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    fp.paragraph_format.space_before = Pt(2)
    prefix = fp.add_run("Page ")
    set_run_font(prefix, size=9, color=MUTED)
    add_page_field(fp)


def configure_styles(doc: Document):
    styles = doc.styles

    normal = styles["Normal"]
    set_style_font(normal, "Calibri", 11, BLACK)
    normal.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    normal.paragraph_format.widow_control = True
    set_spacing(normal, before=0, after=160, line=320)

    h1 = styles["Heading 1"]
    set_style_font(h1, "Calibri", 16, BLUE, bold=True)
    h1.paragraph_format.keep_with_next = True
    h1.paragraph_format.keep_together = True
    set_spacing(h1, before=360, after=200, line=320)

    h2 = styles["Heading 2"]
    set_style_font(h2, "Calibri", 13, BLUE, bold=True)
    h2.paragraph_format.keep_with_next = True
    h2.paragraph_format.keep_together = True
    set_spacing(h2, before=240, after=120, line=320)

    h3 = styles["Heading 3"]
    set_style_font(h3, "Calibri", 12, DARK_BLUE, bold=True)
    h3.paragraph_format.keep_with_next = True
    h3.paragraph_format.keep_together = True
    set_spacing(h3, before=160, after=80, line=320)

    if "Figure Legend" not in styles:
        fig = styles.add_style("Figure Legend", WD_STYLE_TYPE.PARAGRAPH)
    else:
        fig = styles["Figure Legend"]
    set_style_font(fig, "Calibri", 10.5, BLACK)
    fig.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.LEFT
    fig.paragraph_format.keep_together = True
    set_spacing(fig, before=0, after=120, line=290)

    if "Reference" not in styles:
        ref = styles.add_style("Reference", WD_STYLE_TYPE.PARAGRAPH)
    else:
        ref = styles["Reference"]
    set_style_font(ref, "Calibri", 10.5, BLACK)
    ref.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.LEFT
    ref.paragraph_format.left_indent = Inches(0.25)
    ref.paragraph_format.first_line_indent = Inches(-0.25)
    set_spacing(ref, before=0, after=80, line=290)


INLINE_RE = re.compile(r"(\*\*.*?\*\*|\*.*?\*)")


def add_inline(paragraph, text: str, *, size=None, color=None):
    text = normalize_text(text)
    pos = 0
    for match in INLINE_RE.finditer(text):
        if match.start() > pos:
            run = paragraph.add_run(text[pos : match.start()])
            set_run_font(run, size=size, color=color)
        token = match.group(0)
        if token.startswith("**"):
            content = token[2:-2]
            run = paragraph.add_run(content)
            set_run_font(run, size=size, color=color, bold=True)
        else:
            content = token[1:-1]
            run = paragraph.add_run(content)
            set_run_font(run, size=size, color=color, italic=True)
        pos = match.end()
    if pos < len(text):
        run = paragraph.add_run(text[pos:])
        set_run_font(run, size=size, color=color)


def add_cover(doc: Document, title: str, metadata: dict[str, str]):
    spacer = doc.add_paragraph()
    spacer.paragraph_format.space_after = Pt(74)

    kicker = doc.add_paragraph()
    kicker.alignment = WD_ALIGN_PARAGRAPH.CENTER
    kicker.paragraph_format.space_after = Pt(20)
    kr = kicker.add_run("ORIGINAL RESEARCH")
    set_run_font(kr, size=10.5, color=BLUE, bold=True)

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(16)
    p.paragraph_format.keep_together = True
    title_run = p.add_run(normalize_text(title))
    set_run_font(title_run, size=25, color=INK_BLUE, bold=True)

    subtitle = doc.add_paragraph()
    subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER
    subtitle.paragraph_format.space_after = Pt(48)
    sr = subtitle.add_run("A public-data multimodal computational immunology study")
    set_run_font(sr, size=13, color=DARK_BLUE, italic=True)

    for key in ("Authors", "Affiliations", "Correspondence"):
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.space_after = Pt(7)
        label = p.add_run(f"{key}: ")
        set_run_font(label, size=11, color=INK_BLUE, bold=True)
        value = p.add_run(normalize_text(metadata.get(key, "[to be completed]")))
        set_run_font(value, size=11, color=MUTED)

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(64)
    rr = p.add_run("Submission manuscript | Public human datasets | No new patient data")
    set_run_font(rr, size=9.5, color=MUTED)

    doc.add_page_break()


def parse_source(path: Path):
    lines = path.read_text(encoding="utf-8").splitlines()
    title = normalize_text(lines[0].removeprefix("# ").strip())
    metadata = {}
    body_start = 0
    for idx, line in enumerate(lines[1:], start=1):
        m = re.match(r"\*\*(Running title|Authors|Affiliations|Correspondence):\*\*\s*(.*)", line)
        if m:
            metadata[m.group(1)] = normalize_text(m.group(2))
        if line.strip() == "## Abstract":
            body_start = idx
            break
    return title, metadata, lines[body_start:]


def add_body(doc: Document, lines: list[str]):
    in_references = False
    in_legends = False
    buffer: list[str] = []

    def flush():
        nonlocal buffer
        if not buffer:
            return
        text = " ".join(x.strip() for x in buffer).strip()
        buffer = []
        if not text:
            return
        if in_references and re.match(r"^\d+\.\s", text):
            p = doc.add_paragraph(style="Reference")
        elif in_legends:
            p = doc.add_paragraph(style="Figure Legend")
        else:
            p = doc.add_paragraph(style="Normal")
        add_inline(p, text)

    for raw in lines:
        line = raw.rstrip()
        if not line.strip():
            flush()
            continue
        if line.startswith("## "):
            flush()
            heading = normalize_text(line[3:].strip())
            in_references = heading == "References"
            in_legends = heading == "Figure legends"
            p = doc.add_paragraph(style="Heading 1")
            p.add_run(heading)
            continue
        if line.startswith("### "):
            flush()
            heading = normalize_text(line[4:].strip())
            p = doc.add_paragraph(style="Heading 2")
            add_inline(p, heading)
            continue
        if line.startswith("#### "):
            flush()
            heading = normalize_text(line[5:].strip())
            p = doc.add_paragraph(style="Heading 3")
            add_inline(p, heading)
            continue
        if in_references and re.match(r"^\d+\.\s", line.strip()):
            flush()
            p = doc.add_paragraph(style="Reference")
            add_inline(p, line.strip())
            continue
        buffer.append(line)
    flush()


def set_document_defaults(doc: Document):
    settings = doc.settings.element
    compat = settings.find(qn("w:compat"))
    if compat is None:
        compat = OxmlElement("w:compat")
        settings.append(compat)
    use_word_2010 = OxmlElement("w:compatSetting")
    use_word_2010.set(qn("w:name"), "compatibilityMode")
    use_word_2010.set(qn("w:uri"), "http://schemas.microsoft.com/office/word")
    use_word_2010.set(qn("w:val"), "15")
    compat.append(use_word_2010)

    update_fields = settings.find(qn("w:updateFields"))
    if update_fields is None:
        update_fields = OxmlElement("w:updateFields")
        settings.append(update_fields)
    update_fields.set(qn("w:val"), "true")


def audit(doc: Document):
    section = doc.sections[0]
    assert round(section.page_width.inches, 3) == 8.5
    assert round(section.page_height.inches, 3) == 11.0
    for value in (
        section.top_margin.inches,
        section.right_margin.inches,
        section.bottom_margin.inches,
        section.left_margin.inches,
    ):
        assert round(value, 3) == 1.0
    assert doc.styles["Normal"].font.name == "Calibri"
    assert doc.styles["Normal"].font.size.pt == 11
    assert doc.styles["Heading 1"].font.size.pt == 16
    assert doc.styles["Heading 2"].font.size.pt == 13
    assert doc.styles["Heading 3"].font.size.pt == 12


def main():
    if len(sys.argv) != 3:
        raise SystemExit("usage: build_manuscript_docx.py INPUT.md OUTPUT.docx")
    source = Path(sys.argv[1]).resolve()
    output = Path(sys.argv[2]).resolve()
    title, metadata, body = parse_source(source)

    doc = Document()
    configure_styles(doc)
    configure_section(doc.sections[0], metadata.get("Running title", title))
    set_document_defaults(doc)
    add_cover(doc, title, metadata)
    add_body(doc, body)

    core = doc.core_properties
    core.title = title
    core.subject = "Multimodal public-data analysis of immune checkpoint inhibitor toxicity"
    core.author = ""
    core.keywords = "immune checkpoint inhibitor; irAE; single-cell; organoid; TCR; public data"
    core.comments = "Generated reproducibly from manuscript_full.md"

    audit(doc)
    output.parent.mkdir(parents=True, exist_ok=True)
    doc.save(output)
    print(f"Wrote {output}")


if __name__ == "__main__":
    main()
