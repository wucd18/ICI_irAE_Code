from pathlib import Path
import re
W=Path(__file__).resolve().parents[1]
S=W.parents[1]
V=W/'visual_input_snapshot'
PLATE_SPANS={'S1':'S1','S2A':'S2a','S2B':'S2b','S3':'S3','S4A':'S4a-b','S4B':'S4c-d','S5A':'S5a-d','S5B':'S5e-h','S5C':'S5i','S6A':'S6a-b','S6B':'S6c-d','S7A':'S7a-d','S7B':'S7e-g','S7C':'S7h-k','S8':'S8a-b'}
def refs(text):
    return re.sub(r'\bS[24567][ABC]\b',lambda m:PLATE_SPANS[m[0]],text)
