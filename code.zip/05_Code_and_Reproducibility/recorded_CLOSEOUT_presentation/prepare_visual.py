"""Prepare closeout inputs from the exact VISUAL_FINAL snapshot; no statistics."""
from pathlib import Path
import csv,hashlib,json,shutil
W=Path(__file__).resolve().parents[1];S=W.parents[1];V=W/'visual_input_snapshot'
def readcsv(p):
 with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def writecsv(p,rows):
 p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def sync_rules(rows,source):
 index={}
 for r in source:
  k=(r['module'],r['gene'])
  if k in index:raise ValueError('Duplicate authoritative module/gene key')
  if not r['selection_rule']:raise ValueError('Missing authoritative selection rule')
  index[k]=r['selection_rule']
 seen=set();output=[];changes=[]
 for r in rows:
  k=(r['module'],r['gene'])
  if k in seen or k not in index:raise ValueError('Duplicate or missing displayed module/gene key')
  seen.add(k);new=dict(r);new['selection_rule']=index[k];output.append(new)
  if new['selection_rule']!=r['selection_rule']:
   changes.append(dict(module=k[0],gene=k[1],field='selection_rule',old=r['selection_rule'],new=new['selection_rule']))
 return output,changes
def prepare():
 manifest=json.loads((V/'selected_input_manifest.json').read_text(encoding='utf-8'))
 assert len(manifest)==len({r['path'] for r in manifest})
 for r in manifest:
  p=V/r['path'];assert p.stat().st_size==r['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==r['sha256'],r['path']
 for source,dest in [('source_data','source_data'),('supplement/full_source_tables','supplement/full_source_tables'),('supplement/reader_tables','supplement/reader_tables'),('supplement/plates','supplement/plates')]:
  shutil.copytree(V/source,W/dest,dirs_exist_ok=True)
 authoritative=readcsv(V/'supplement/full_source_tables/Source_021_frozen_module_definitions.csv');ledger=[]
 for rel in ['final_panels/F3C.csv','panel_sources/F3C_members.csv']:
  rows,changes=sync_rules(readcsv(V/'source_data'/rel),authoritative)
  writecsv(W/'source_data'/rel,rows)
  ledger.extend(dict(file='source_data/'+rel,**r) for r in changes)
 # Explicit canonical panel alias; the actual inherited filename is F3C_members.csv.
 shutil.copy2(W/'source_data/panel_sources/F3C_members.csv',W/'source_data/panel_sources/F3C.csv')
 defs=json.loads((V/'supplement/reader_tables/table_definitions.json').read_text(encoding='utf-8'))
 matches=[d for d in defs if d['table']=='S8'];assert len(matches)==1
 before=matches[0]['note'];assert 'Supplementary Figure 17' in before
 matches[0]['note']=before.replace('Supplementary Figure 17','Supplementary Figure S8 / Appendix C')
 (W/'supplement/reader_tables/table_definitions.json').write_text(json.dumps(defs,ensure_ascii=False,indent=2),encoding='utf-8')
 # Current public copies come from this prepared source; historical input snapshots stay unchanged.
 shutil.copytree(W/'source_data',S/'04_Source_Data/current_visual_sources',dirs_exist_ok=True)
 shutil.copytree(W/'supplement/reader_tables',S/'01_Journal_Upload/05_Supplementary_Tables/reader_csv',dirs_exist_ok=True)
 writecsv(W/'review/F3C_selection_rule_changes.csv',ledger)
 (W/'review/metadata_changes.json').write_text(json.dumps({'selection_rule_rows_changed':len(ledger),'S8_note_before':before,'S8_note_after':matches[0]['note'],'numeric_changes':0},indent=2),encoding='utf-8')
 (W/'review/closeout_input_preflight.json').write_text(json.dumps({'status':'PASS','checked_locked_files':len(manifest),'baseline_zip_sha256':'7537083659facb999e7a53bbddf11abb779851d54790f4bdb46427d102c390bd','member_selection':'unchanged','statistics':'not rerun'},indent=2),encoding='utf-8')
 print('CLOSEOUT_INPUT_PREFLIGHT_PASS',len(manifest),'locked files;',len(ledger),'selection-rule text updates')
if __name__=='__main__':prepare()
