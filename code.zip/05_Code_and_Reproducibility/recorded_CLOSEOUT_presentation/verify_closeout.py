"""Validate source keys, retained values, references, fields and actual execution."""
from closeout_common import W,S,V,refs
from pathlib import Path
from collections import Counter
from zipfile import ZipFile
from decimal import Decimal,InvalidOperation
from lxml import etree as E
import json,csv,re,hashlib,math,statistics
from docx import Document
from docx.oxml.ns import qn
from pypdf import PdfReader
import pdfplumber
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def cr(p):
    with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def cw(p,rows):
    with p.open('w',encoding='utf-8-sig',newline='') as f:w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
checks=[]
def ok(name,count,detail=''):checks.append({'check':name,'count':count,'status':'PASS','detail':detail})
inputs=json.loads((V/'selected_input_manifest.json').read_text())
for r in inputs:assert (V/r['path']).stat().st_size==r['bytes'] and sha(V/r['path'])==r['sha256'],r['path']
ok('immutable selected VISUAL_FINAL inputs',len(inputs))
preserved=json.loads((W/'review/preserved_model_snapshot_manifest.json').read_text())
for r in preserved:assert (W/'input_snapshot'/r['path']).stat().st_size==r['bytes'] and sha(W/'input_snapshot'/r['path'])==r['sha256'],r['path']
ok('complete baseline input snapshot including retained primary model outputs',len(preserved))
sources=sorted(p for p in (V/'supplement/full_source_tables').glob('Source_*.csv') if re.match(r'^Source_\d{3}_',p.name))
assert [int(p.name.split('_')[1]) for p in sources]==list(range(1,len(sources)+1))
numeric_cells=0
for p in sources:
    assert sha(p)==sha(W/'supplement/full_source_tables'/p.name)==sha(S/'04_Source_Data/full_source_tables'/p.name),p.name
    for row in cr(p):
        for val in row.values():
            try:
                if val.strip() and Decimal(val).is_finite():numeric_cells+=1
            except (InvalidOperation,AttributeError):pass
ok('all complete source tables byte-identical',len(sources),f'{numeric_cells} finite numeric cells retained')
allowed={'F3C.csv','F3C_members.csv'};panel_cells=0
for folder in ['final_panels','panel_sources']:
    for p in sorted((V/'source_data'/folder).glob('*.csv')):
        a=cr(p);b=cr(W/'source_data'/folder/p.name);assert len(a)==len(b),(folder,p.name)
        for x,y in zip(a,b):
            assert x.keys()==y.keys(),p.name
            for k in x:
                if p.name in allowed and k=='selection_rule':continue
                assert x[k]==y[k],(folder,p.name,k,x[k],y[k]);panel_cells+=1
ok('panel source fields unchanged except registered selection_rule',panel_cells)
auth={(r['module'],r['gene']):r['selection_rule'] for r in cr(V/'supplement/full_source_tables/Source_021_frozen_module_definitions.csv')}
for rel in ['final_panels/F3C.csv','panel_sources/F3C_members.csv','panel_sources/F3C.csv']:
    rows=cr(W/'source_data'/rel);assert len(rows)==len({(r['module'],r['gene']) for r in rows})
    assert all(r['selection_rule']==auth[r['module'],r['gene']] for r in rows)
ok('F3C module-gene joins and memberships',len(rows))
patients=cr(V/'supplement/full_source_tables/Source_031_colon_TCR_patient_metrics.csv');tcr=[]
for r in cr(V/'source_data/final_panels/F6C.csv'):
    case=[float(p[r['metric']]) for p in patients if p['disease']==r['group1']];ctrl=[float(p[r['metric']]) for p in patients if p['disease']==r['group0']]
    assert len(case)==int(r['n_group1']) and len(ctrl)==int(r['n_group0'])
    wins=sum(x>y for x in case for y in ctrl);ties=sum(x==y for x in case for y in ctrl);losses=len(case)*len(ctrl)-wins-ties
    delta=statistics.median(case)-statistics.median(ctrl);assert math.isclose(delta,float(r['median_difference']),abs_tol=1e-15)
    tcr.append({'metric':r['metric'],'n_case':len(case),'n_control':len(ctrl),'median_difference':delta,'wins':wins,'losses':losses,'ties':ties,'U':wins+ties/2,'original_p':r['p'],'original_fdr':r['fdr_within_analysis'],'verification':'rank tally and median only; no test or FDR recomputed'})
assert len({r['U'] for r in tcr})==1 and len({r['median_difference'] for r in tcr})==len(tcr)
cw(W/'review/F6C_closeout_verification.csv',tcr);ok('F6C different observed effects and identical rank U; original P/FDR retained',len(tcr))

def cells(p):
    result={}
    with ZipFile(p) as z:
        ss=[]
        if 'xl/sharedStrings.xml' in z.namelist():ss=[''.join(n.itertext()) for n in E.fromstring(z.read('xl/sharedStrings.xml')).findall('{*}si')]
        for name in z.namelist():
            if not re.fullmatch(r'xl/worksheets/sheet\d+\.xml',name):continue
            rt=E.fromstring(z.read(name))
            for c in rt.findall('.//{*}c'):
                v=c.find('{*}v');val=v.text if v is not None else ''.join(c.find('{*}is').itertext()) if c.find('{*}is') is not None else ''
                if c.get('t')=='s':val=ss[int(val)]
                result[name,c.get('r')]=(val,E.tostring(c.find('{*}f')) if c.find('{*}f') is not None else None,c.get('s'))
    return result
a=cells(V/'supplement/Supplementary_Tables.xlsx');b=cells(W/'supplement/Supplementary_Tables.xlsx')
assert a.keys()==b.keys();diff=[(k,a[k],b[k]) for k in a if a[k]!=b[k]]
assert len(diff)==1 and diff[0][0]==('xl/worksheets/sheet8.xml','K5'),diff[:5]
assert diff[0][2][0]==diff[0][1][0].replace('Supplementary Figure 17','Supplementary Figure S8 / Appendix C')
ok('XLSX values/formulas/style IDs retained; S8 K5 note only',len(a))

red=Document(W/'manuscript/manuscript_CLOSEOUT_RED.docx');clean=Document(W/'manuscript/manuscript_CLOSEOUT_CLEAN.docx');base=Document(V/'manuscript/manuscript_VISUAL_FINAL_CLEAN.docx')
accepted=[''.join(r.text for r in p.runs if not r.font.strike) for p in red.paragraphs]
assert accepted==[p.text for p in clean.paragraphs]
for d in [red,clean]:
    assert [E.tostring(e) for e in d._element.iter(qn('w:fldChar'))]==[E.tostring(e) for e in base._element.iter(qn('w:fldChar'))]
    assert [E.tostring(t._tbl) for t in d.tables]==[E.tostring(t._tbl) for t in base.tables]
text='\n'.join(p.text for p in clean.paragraphs);assert not re.search(r'\bS[24567][ABC]\b',text);assert 'RUN_VISUAL_FINAL' not in text
assert '95.24%' in text and 'Mann-Whitney U statistic' in text
ok('accepted RED equals CLEAN; all citation field nodes and tables preserved',len(accepted))

mapping=cr(S/'02_Supplementary_Figures_OneFilePerFigure/panel_mapping.csv')
expected={'S1':'','S2':'ab','S3':'','S4':'abcd','S5':'abcdefghi','S6':'abcd','S7':'abcdefghijk','S8':'ab'}
for tag,letters in expected.items():
    assert ''.join(r['panel'] for r in mapping if r['figure']==tag)==letters
    p=S/'02_Supplementary_Figures_OneFilePerFigure'/f'Supplementary_Figure_{tag}_combined.pdf';rd=PdfReader(p);assert len(rd.pages)==1
    txt=rd.pages[0].extract_text();assert not re.search(r'\bS[24567][ABC]\b',txt),(tag,'old plate reference')
for r in mapping:assert (S/r['source_pdf']).is_file()
for filename in ['Reader_SI.pdf']:
    txt='\n'.join(p.extract_text() for p in PdfReader(W/'supplement'/filename).pages);assert not re.search(r'\bS[24567][ABC]\b',txt)
ok('continuous scientific panel identities; one vector PDF per figure',len(mapping))

with pdfplumber.open(W/'figures/Figure_2_receiver_programmes.pdf') as doc:
    words=doc.pages[0].extract_words();heart=[r for r in words if r['text']=='Heart'];bottom=[r for r in words if r['text']=='Endothelial']
    assert len(bottom)==2 and min(r['top'] for r in bottom)>min(r['top'] for r in heart)
    assert max(r['top'] for r in bottom)<min(r['top'] for r in words if r['text']=='programmes')
ok('Figure 2A labels below groups and above following panels',len(bottom))
for r in cr(S/'05_Code_and_Reproducibility/exact_source_recovery_manifest.csv'):assert sha(S/r['file'])==r['expected_hash']
ok('all recovered original/targeted/spatial source hashes',len(cr(S/'05_Code_and_Reproducibility/exact_source_recovery_manifest.csv')))
for r in cr(S/'05_Code_and_Reproducibility/CURRENT_CODE_INDEX.csv'):assert sha(S/r['path'])==r['sha256']
ok('current code index resolves to exact local files',len(cr(S/'05_Code_and_Reproducibility/CURRENT_CODE_INDEX.csv')))

logs=[json.loads(p.read_text()) for p in (W/'logs').glob('*.json')]
required=['plot_final.R','plot_organoid_supplement.R','audit_fidelity.R','closeout_manuscript.py','closeout_supplement.py','build_manuscript.py','closeout_workbook.mjs','render_closeout_word.ps1','render_closeout_pdfs.py']
for name in required:
    entries=[r for r in logs if any(Path(c).name==name for c in r.get('command',[]))];assert entries and any(r['exit_code']==0 for r in entries),name
    assert not any(re.search(r'(?:RUN_ALL|DESeq2|coxph|meta_analysis)',Path(c).name,re.I) for r in entries for c in r['command'])
ok('actual successful presentation/rebuild/render commands',len(required))
render=json.loads((W/'review/closeout_word_render_records.json').read_text(encoding='utf-8-sig'));assert all(r['exit_code']==0 for r in render)
ok('native Word renders',len(render))
cw(W/'review/closeout_verification_checks.csv',checks)
report={'science_scope':'PASS - existing results retained, no new biological inference','numerical_fidelity':'PASS','production_and_references':'PASS - visual-review record required for release','execution':'PASS - presentation only','submission_information':'USER_PENDING','checks':checks,'original_full_source_numeric_cells':numeric_cells,'changed_statistical_values':0}
(W/'review/closeout_verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
dest=S/'06_Review_and_Codex/closeout'
import shutil
for name in ['closeout_verification.json','closeout_verification_checks.csv','manuscript_change_ledger.json','F3C_selection_rule_changes.csv','metadata_changes.json','F6C_closeout_verification.csv','red_clean_equivalence.json','supplement_closeout.json','closeout_word_render_records.json','panel_fidelity.csv']:
    shutil.copy2(W/'review'/name,dest/name)
print('CLOSEOUT_VERIFICATION_PASS',len(checks),'groups;',numeric_cells,'unchanged numeric source cells')
