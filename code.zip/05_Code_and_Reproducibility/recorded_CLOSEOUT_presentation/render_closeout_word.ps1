param([switch]$ManuscriptsOnly,[switch]$SupplementOnly)
$ErrorActionPreference='Stop'
$workRoot=Split-Path -Parent $PSScriptRoot
$submissionRoot=Split-Path -Parent (Split-Path -Parent $workRoot)
$items=@(
 @{input=(Join-Path $workRoot 'manuscript/manuscript_CLOSEOUT_RED.docx');tag='manuscript_CLOSEOUT_RED'},
 @{input=(Join-Path $workRoot 'manuscript/manuscript_CLOSEOUT_CLEAN.docx');tag='manuscript_CLOSEOUT_CLEAN'}
)
if($SupplementOnly){$items=@(@{input=(Join-Path $workRoot 'supplement/Reader_SI.docx');tag='Reader_SI_Word'})}
elseif(-not $ManuscriptsOnly){
 $reviewFile=@(Get-ChildItem -LiteralPath (Join-Path $submissionRoot '06_Review_and_Codex') -Filter '*.docx' -File)
 if($reviewFile.Count -ne 1){throw 'Ambiguous review Word'}
 $items+=@(
  @{input=(Join-Path $workRoot 'supplement/Reader_SI.docx');tag='Reader_SI_Word'},
  @{input=(Join-Path $submissionRoot '01_Journal_Upload/03_Main_Tables/Table_1.docx');tag='Table_1'},
  @{input=$reviewFile[0].FullName;tag='input_10_page_review'}
 )
}
$word=$null;$records=@();$retained=@()
$recordPath=Join-Path $workRoot 'review/closeout_word_render_records.json'
if($ManuscriptsOnly -and (Test-Path -LiteralPath $recordPath)){$retained=@((Get-Content -LiteralPath $recordPath -Raw|ConvertFrom-Json)|Where-Object {$_.input -notlike '*manuscript_CLOSEOUT*'})}
if($SupplementOnly -and (Test-Path -LiteralPath $recordPath)){$retained=@((Get-Content -LiteralPath $recordPath -Raw|ConvertFrom-Json)|Where-Object {$_.input -notlike '*Reader_SI.docx'})}
try{
 $word=New-Object -ComObject Word.Application
 $word.Visible=$false;$word.DisplayAlerts=0;$word.AutomationSecurity=3;$word.Options.UpdateLinksAtOpen=$false
 foreach($item in $items){
  $renderDir=Join-Path $workRoot ('review/closeout_render/'+$item.tag)
  New-Item -ItemType Directory -Path $renderDir -Force|Out-Null
  $outPdf=Join-Path $renderDir ($item.tag+'.pdf')
  $begin=[DateTime]::UtcNow.ToString('o')
  $doc=$word.Documents.Open($item.input,$false,$true,$false)
  try{
   $doc.Repaginate();$pages=$doc.ComputeStatistics(2)
   $doc.ExportAsFixedFormat($outPdf,17,$false,0,0,1,1,0,$true,$true,0,$true,$true,$false)
   $records += [pscustomobject]@{input=$item.input;output=$outPdf;pages=$pages;renderer='Microsoft Word COM';version=$word.Version;start_utc=$begin;end_utc=[DateTime]::UtcNow.ToString('o');exit_code=0}
  }finally{$doc.Close(0);[void][Runtime.InteropServices.Marshal]::ReleaseComObject($doc)}
 }
 @($retained+$records)|ConvertTo-Json -Depth 5|Set-Content -LiteralPath $recordPath -Encoding utf8
 $records|ConvertTo-Json -Compress
}finally{if($null-ne $word){$word.Quit(0);[void][Runtime.InteropServices.Marshal]::ReleaseComObject($word)}}
