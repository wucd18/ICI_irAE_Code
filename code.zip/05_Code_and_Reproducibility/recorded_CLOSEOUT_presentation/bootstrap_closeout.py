from pathlib import Path
import zipfile,hashlib,csv,json,shutil,sys,io
from datetime import datetime,timezone
sys.stdout.reconfigure(encoding='utf-8')
O=Path(__file__).resolve().parent
B=O/'baseline_visual';S=O/'ICI_CLOSEOUT_20260914'
baseline=Path(r'E:\ICI_irAE_V1_Redline_Revision\submission_candidate_VISUAL_FINAL_20260914T045831Z.zip')
prepared=Path(r'E:\ICI_VISUAL_FINAL_完整投稿候选目录_20260914.zip')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for x in iter(lambda:f.read(8388608),b''):h.update(x)
 return h.hexdigest()
assert sha(baseline)=='7537083659facb999e7a53bbddf11abb779851d54790f4bdb46427d102c390bd'
assert not B.exists() and not S.exists()
for archive,dest,strip in [(baseline,B,False),(prepared,S,True)]:
 with zipfile.ZipFile(archive) as z:
  for n in z.namelist():
   if n.endswith('/'):continue
   rel=Path(*Path(n).parts[1:]) if strip else Path(n)
   p=(dest/rel).resolve();assert dest.resolve() in p.parents
   p.parent.mkdir(parents=True,exist_ok=True)
   with z.open(n) as r,p.open('xb') as w:shutil.copyfileobj(r,w)
with (B/'artifact_manifest_SHA256.csv').open(encoding='utf-8-sig',newline='') as f:manifest=list(csv.DictReader(f))
for r in manifest:
 p=B/r['path'];assert p.stat().st_size==int(r['bytes']) and sha(p)==r['sha256'],r['path']
W=S/'05_Code_and_Reproducibility/current_visual_rebuild_source'
V=W/'visual_input_snapshot';V.mkdir()
paths=['source_data','supplement/full_source_tables','supplement/reader_tables','supplement/plates','supplement/reader_SI_source.json','supplement/figure_map.csv','manuscript/manuscript_VISUAL_FINAL_CLEAN.docx','manuscript/manuscript_source.md','review/manuscript_change_ledger.json','presentation_code','review/word_render_records.json']
for rel in paths:
 p=B/rel;dst=V/rel
 if p.is_dir():shutil.copytree(p,dst)
 else:dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dst)
snapshot=[]
for p in sorted(V.rglob('*')):
 if p.is_file():snapshot.append(dict(path=p.relative_to(V).as_posix(),bytes=p.stat().st_size,sha256=sha(p),source='submission_candidate_VISUAL_FINAL_20260914T045831Z.zip',role='locked closeout input'))
(V/'selected_input_manifest.json').write_text(json.dumps(snapshot,indent=2),encoding='utf-8')
R=S/'06_Review_and_Codex/closeout';R.mkdir()
for name in ['logs','review','temp','source_data','supplement','figures','appendices','tests']:(W/name).mkdir(exist_ok=True)
shutil.copy2(O/'bootstrap_closeout.py',W/'presentation_code/bootstrap_closeout.py')
shutil.copy2(r'E:\CODEX_VISUAL_FINAL_CLOSEOUT_20260914.md',R/'CODEX_VISUAL_FINAL_CLOSEOUT_20260914.md')
prepared_manifest=[]
with zipfile.ZipFile(prepared) as z:
 for n in z.namelist():
  if not n.endswith('/'):
   data=z.read(n);prepared_manifest.append(dict(path=Path(*Path(n).parts[1:]).as_posix(),bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
(R/'prepared_input_manifest.json').write_text(json.dumps(prepared_manifest,indent=2),encoding='utf-8')
(R/'baseline_manifest_verified.json').write_text(json.dumps({'baseline_zip':str(baseline),'sha256':sha(baseline),'verified_entries':len(manifest),'status':'PASS','prepared_zip':str(prepared),'prepared_sha256':sha(prepared),'prepared_entries':len(prepared_manifest),'created_utc':datetime.now(timezone.utc).isoformat(),'selected_visual_inputs':len(snapshot)},indent=2),encoding='utf-8')
print('BOOTSTRAP_PASS',len(manifest),'baseline entries;',len(snapshot),'locked closeout inputs;',str(S))
