"""Refresh the prepared submission directories and current, resolvable source indices."""
from closeout_common import W,S,V,refs,PLATE_SPANS
from pathlib import Path
import json,csv,shutil,hashlib
from collections import Counter
from pypdf import PdfReader,PdfWriter
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def csvread(p):
    with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def csvwrite(p,rows):
    with p.open('w',encoding='utf-8-sig',newline='') as f:w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
# Preserve the superseded prepared journal copies outside the upload directory.
archive=S/'06_Review_and_Codex/superseded_pre_closeout_journal';archive.mkdir(exist_ok=True)
md=S/'01_Journal_Upload/01_Manuscript'
for p in md.glob('manuscript_VISUAL_FINAL*'):
    target=archive/p.name
    assert not target.exists() or sha(target)==sha(p)
    if not target.exists():p.rename(target)
for mode in ['CLEAN','RED']:
    name=f'manuscript_CLOSEOUT_{mode}'
    shutil.copy2(W/f'manuscript/{name}.docx',md/f'{name}.docx')
    shutil.copy2(W/f'review/closeout_render/{name}/{name}.pdf',md/f'{name}.pdf')
fg=S/'01_Journal_Upload/02_Main_Figures';wr=PdfWriter()
for p in sorted((W/'figures').glob('Figure_*.pdf')):
    shutil.copy2(p,fg/p.name);shutil.copy2(p.with_suffix('.tiff'),fg/p.with_suffix('.tiff').name)
    wr.add_page(PdfReader(p).pages[0])
assert len(wr.pages)==6
# Keep the existing combined-preview filename if exactly one is present.
existing=[p for p in fg.glob('*.pdf') if not p.name.startswith('Figure_')]
assert len(existing)<=1
combined=existing[0] if existing else fg/'Main_Figures_1-6.pdf'
with combined.open('wb') as f:wr.write(f)
shutil.copy2(W/'supplement/Supplementary_Tables.xlsx',S/'01_Journal_Upload/05_Supplementary_Tables/Supplementary_Tables.xlsx')
shutil.copy2(W/'review/closeout_render/Table_1/Table_1.pdf',S/'01_Journal_Upload/03_Main_Tables/Table_1.pdf')

idx=csvread(V/'source_data/figure_source_index.csv')
for row in idx:
    p=W/row['path'];assert p.is_file(),p
    row.update(bytes=p.stat().st_size,sha256=sha(p),source='Locked VISUAL_FINAL 20260914T045831Z baseline; current descriptive display only; original accession and source-row keys retained')
csvwrite(W/'source_data/figure_source_index.csv',idx)
idx=csvread(V/'source_data/supplement_source_index.csv')
for row in idx:
    old=row['new_reader_id'];row['new_reader_id']=PLATE_SPANS.get(old,old)
    if old in PLATE_SPANS:row['new_plot']=f'supplement/closeout_plates/{old}.pdf'
    row['source_lookup']='source_data/panel_sources and visual_input_snapshot/supplement/full_source_tables; supplementary panel_mapping.csv records the current identities'
csvwrite(W/'source_data/supplement_source_index.csv',idx)
(W/'source_data/README.md').write_text('''# Current figure source data

The sole numerical baseline is submission_candidate_VISUAL_FINAL_20260914T045831Z.zip (SHA-256 7537083659facb999e7a53bbddf11abb779851d54790f4bdb46427d102c390bd). final_panels/ retains original record keys and statistics. The F3C selection_rule text is joined to the unchanged Source_021 module/gene definitions; panel_sources/F3C.csv is the canonical alias of F3C_members.csv.

Indices in this directory resolve relative to 05_Code_and_Reproducibility/current_visual_rebuild_source/. Current plotted coordinates, fill scales and source-field fidelity checks are in review/. The old input_snapshot is historical evidence; current presentation scripts read visual_input_snapshot. Supplementary figures use the panel mapping in 02_Supplementary_Figures_OneFilePerFigure/.
''',encoding='utf-8')
shutil.copytree(W/'source_data',S/'04_Source_Data/current_visual_sources',dirs_exist_ok=True)

code_root=S/'05_Code_and_Reproducibility';recovered=csvread(code_root/'exact_source_recovery_manifest.csv');counts=Counter(r['role'] for r in recovered)
index=[]
for r in recovered:
    p=S/r['file'];assert sha(p)==r['expected_hash']==r['hash'];index.append({'role':r['role'],'path':r['file'],'sha256':sha(p),'executed_in_closeout':'NO - preserved statistical/historical source'})
active=['prepare_visual.py','plot_final.R','plot_organoid_supplement.R','theme_final.R','csv_io.R','audit_fidelity.R','closeout_common.py','closeout_manuscript.py','closeout_supplement.py','build_manuscript.py','closeout_workbook.mjs','render_closeout_word.ps1','render_closeout_pdfs.py','closeout_assemble.py','verify_closeout.py','run_step.py','package_closeout.py']
active.append('record_closeout_review.py')
for name in active:
    p=W/'presentation_code'/name;assert p.is_file(),p;index.append({'role':'current_presentation','path':p.relative_to(S).as_posix(),'sha256':sha(p),'executed_in_closeout':'See command hashes and exit codes in current_visual_rebuild_source/logs/'})
entry=W/'RUN_CLOSEOUT.ps1';index.append({'role':'current_entry','path':entry.relative_to(S).as_posix(),'sha256':sha(entry),'executed_in_closeout':'Finalize stage; earlier stages have individual command logs'})
csvwrite(code_root/'CURRENT_CODE_INDEX.csv',index)
(code_root/'README_code_provenance.md').write_text(f'''# Source provenance and current execution

Current entry: current_visual_rebuild_source/RUN_CLOSEOUT.ps1. Run -Stage All only in a new writable copy to regenerate presentation outputs from visual_input_snapshot; -Stage Finalize assembles already rendered outputs and verifies the package. This closeout executed the figure, supplement, workbook and Word-render stages with individual command logs, followed by the Finalize entry. No primary statistical entry was run.

The numerical baseline is VISUAL_FINAL 20260914T045831Z, SHA-256 7537083659facb999e7a53bbddf11abb779851d54790f4bdb46427d102c390bd. visual_input_snapshot/selected_input_manifest.json records each current input. The older input_snapshot and RUN_VISUAL_FINAL.ps1 are historical provenance and are not the current closeout inputs or entry.

Recovered source: {dict(counts)}. All {len(recovered)} original/targeted/spatial source files match exact_source_recovery_manifest.csv. CURRENT_CODE_INDEX.csv gives actual package-relative locations and hashes. Full statistical source is included for review; do not run historical DE/GSEA/Cox/Meta/donor launchers for presentation work. The only display refit is the already authorized OLS mean and mean-response band for the same nine Fig. 6b patients; original Spearman statistics remain unchanged.

Original R 4.2.2 history and the targeted R 4.4.1 environment remain distinct. Paths are locked to the author machine; a complete raw-to-final portable reproduction is not claimed. No software was installed, public data downloaded, or scientific threshold changed in this closeout. Public repository, DOI and licence remain USER_PENDING. Files in 06_Review_and_Codex outside closeout/ are pre-closeout review evidence, including the NOT_RUN reference patch.
''',encoding='utf-8')
rows=[]
for k in ['Authors and order','Affiliations','Correspondence','Funding','Competing interests','CRediT','Ethics and data-use/licence confirmation','Repository and DOI','Code licence','Target journal and submission format','Cover-letter author confirmation']:
    rows.append({'item':k,'status':'USER_PENDING','classification':'submission information, not a scientific failure'})
csvwrite(S/'06_Review_and_Codex/closeout/USER_PENDING.csv',rows)
(S/'00_README_投稿与核查说明.md').write_text('''# CLOSEOUT 投稿候选目录

本目录已完成有限科学呈现修订。唯一数值基准为 submission_candidate_VISUAL_FINAL_20260914T045831Z.zip；SHA-256：7537083659facb999e7a53bbddf11abb779851d54790f4bdb46427d102c390bd。最新供者结果、所有原 P/FDR 和全部 Source_001–079 保留。

- 01_Journal_Upload：CLOSEOUT clean/红字 Word 与 PDF、六主图 PDF/TIFF、当前 Table 1、18 页 Reader SI、S1–S12 补充表。RED 用 FF0000 增补及红色删除线标记本轮相对于 VISUAL_FINAL clean 的修改；去除删除片段后与 clean 完全一致。
- 02_Supplementary_Figures_OneFilePerFigure：S1、S2a–b、S3、S4a–d、S5a–i、S6a–d、S7a–k、S8a–b，每图一个矢量 PDF，并附 8 页合并浏览文件。保持约 180 mm 绘图宽度；长页不压缩到 A4。panel_mapping.csv 和 original_44_page_disposition.csv 连接原图及当前面板。
- 03_Companion_Appendices：A 历史分析，B 完整空间图谱，C 全部队列估计；均保留。
- 04_Source_Data：79 个完整源表及当前绘图源数据、字段索引。
- 05_Code_and_Reproducibility：当前入口 RUN_CLOSEOUT.ps1、实际代码索引、35 个原始分析源码和 52 个已登记定向/空间源码。历史代码保留但未执行；不是任意机器上全流程重现的声明。
- 06_Review_and_Codex/closeout：有限修改账本、数值核验、退出码、逐页视觉检查和待作者补充清单。其他核查文件为本次输入或历史记录，不能据其 NOT_RUN 名称推断当前图未重绘。原整理目录中的旧正文副本保存在 superseded_pre_closeout_journal/。

作者、机构、通讯、基金、COI、CRediT、伦理/许可、代码许可、仓库 DOI、期刊及 cover letter 确认单列 USER_PENDING；这些不归入科学失败。目录为投稿候选，尚不声称作者信息或目标期刊格式齐备。
''',encoding='utf-8')
(S/'02_Supplementary_Figures_OneFilePerFigure/README.md').write_text('''# Supplementary Figures S1–S8

Each scientific figure is one vector PDF. Panel identities are S1 (single), S2a-b, S3 (single), S4a-d, S5a-i, S6a-d, S7a-k and S8a-b. The Reader SI uses the same identities across readable continued pages. Native chart width is 180 mm; long figures are not shrunk to A4. Captions are included once per source plate; S6 coefficients and patient-score descriptions are separated. panel_mapping.csv records every real inner panel; original_44_page_disposition.csv preserves access to every earlier source page. Full statistical and source-coordinate records remain in 04_Source_Data and the companion appendices.
''',encoding='utf-8')
suppdir=S/'02_Supplementary_Figures_OneFilePerFigure'
shutil.copy2(suppdir/'README.md',suppdir/'README_combined_figures.md')
mapping=csvread(suppdir/'panel_mapping.csv');manifest=[]
for number in range(1,9):
    tag=f'S{number}';p=suppdir/f'Supplementary_Figure_{tag}_combined.pdf';page=PdfReader(p).pages[0]
    panels=[r for r in mapping if r['figure']==tag]
    manifest.append({'figure':tag,'n_panels':len(panels),'page_width_mm':float(page.mediabox.width)*25.4/72,'page_height_mm':float(page.mediabox.height)*25.4/72,'native_chart_width_mm':180,'path':p.relative_to(S).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)})
csvwrite(suppdir/'combined_figure_manifest.csv',manifest)
print('ASSEMBLY_PASS',len(recovered),'recovered source files; six figures; current references and code index')
