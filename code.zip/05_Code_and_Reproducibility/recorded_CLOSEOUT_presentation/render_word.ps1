param([switch]$SkipSI)
$ErrorActionPreference='Stop'
$visualRoot=Split-Path -Parent $PSScriptRoot
$word=$null
$records=@()
$recordPath=Join-Path $visualRoot 'review/word_render_records.json'
$retained=@()
if($SkipSI -and (Test-Path -LiteralPath $recordPath)) {
 $retained=@((Get-Content -LiteralPath $recordPath -Raw|ConvertFrom-Json)|Where-Object {$_.input.StartsWith('supplement/')})
}
try {
 $word=New-Object -ComObject Word.Application
 $word.Visible=$false
 $word.DisplayAlerts=0
 $word.AutomationSecurity=3
 $word.Options.UpdateLinksAtOpen=$false
 foreach($relative in @('manuscript/manuscript_VISUAL_FINAL_RED.docx','manuscript/manuscript_VISUAL_FINAL_CLEAN.docx','supplement/Reader_SI.docx')) {
  if($SkipSI -and $relative.StartsWith('supplement/')){continue}
  $docPath=Join-Path $visualRoot $relative
  $tag=[IO.Path]::GetFileNameWithoutExtension($docPath)
  $outDir=Join-Path $visualRoot ('review/render/'+$tag)
  New-Item -ItemType Directory -Path $outDir -Force|Out-Null
  $pdf=Join-Path $outDir ($tag+'.pdf')
  $begin=[DateTime]::UtcNow.ToString('o')
  $doc=$word.Documents.Open($docPath,$false,$true,$false)
  try {
   $doc.Repaginate()
   $pages=$doc.ComputeStatistics(2)
   $doc.ExportAsFixedFormat($pdf,17,$false,0,0,1,1,0,$true,$true,0,$true,$true,$false)
   $records += [pscustomobject]@{input=$relative;output=$pdf;pages=$pages;renderer='Microsoft Word COM';version=$word.Version;start_utc=$begin;end_utc=[DateTime]::UtcNow.ToString('o');exit_code=0}
  } finally {$doc.Close(0);[void][Runtime.InteropServices.Marshal]::ReleaseComObject($doc)}
 }
 @($retained+$records)|ConvertTo-Json -Depth 5|Set-Content -LiteralPath $recordPath -Encoding utf8
 $records|ConvertTo-Json -Compress
} finally {
 if($null -ne $word){$word.Quit(0);[void][Runtime.InteropServices.Marshal]::ReleaseComObject($word)}
}
