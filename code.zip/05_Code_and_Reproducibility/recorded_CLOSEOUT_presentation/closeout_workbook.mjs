import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {createRequire} from 'node:module';
const rr=createRequire('C:/Users/frede/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/loader.cjs');
const {FileBlob,SpreadsheetFile}=await import(pathToFileURL(rr.resolve('@oai/artifact-tool')).href);
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const wb=await SpreadsheetFile.importXlsx(await FileBlob.load(path.join(root,'visual_input_snapshot/supplement/Supplementary_Tables.xlsx')));
const sh=wb.worksheets.getItem('S8');
const before=sh.getRange('K5').values[0][0];
if(!before.includes('Supplementary Figure 17')) throw new Error('Unexpected baseline S8 note');
const mode=process.argv[2]||'edit';
if(mode==='edit'){
 sh.getRange('K5').values=[[before.replace('Supplementary Figure 17','Supplementary Figure S8 / Appendix C')]];
 wb.recalculate();
 const output=await SpreadsheetFile.exportXlsx(wb);await output.save(path.join(root,'supplement/Supplementary_Tables.xlsx'));
}
await fs.mkdir(path.join(root,'review/workbook_closeout'),{recursive:true});
const img=await wb.render({sheetName:'S8',range:'K1:K6',scale:1.5,format:'png'});
await fs.writeFile(path.join(root,`review/workbook_closeout/S8_${mode}.png`),new Uint8Array(await img.arrayBuffer()));
const report=await wb.inspect({kind:'region',sheetId:'S8',range:'K1:K6',maxChars:2500});
await fs.writeFile(path.join(root,`review/workbook_closeout/${mode}.json`),JSON.stringify({before,after:sh.getRange('K5').values[0][0],report},null,2));
console.log('S8_NOTE',mode,'PASS');
