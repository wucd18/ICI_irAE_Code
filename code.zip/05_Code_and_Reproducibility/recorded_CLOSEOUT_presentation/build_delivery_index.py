"""Create delivery navigation and vector comparison sheets; no statistical analysis."""
from pathlib import Path
import csv, json, hashlib, shutil, io, re, sys
from datetime import datetime, timezone
from pypdf import PdfReader, PdfWriter, Transformation
from reportlab.pdfgen import canvas
from reportlab.lib.units import mm

O=Path(__file__).resolve().parents[1]
I=O/'input_snapshot'
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
    return h.hexdigest()
def readcsv(p):
    with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def writecsv(p,rows):
    with p.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def rel(p):return p.relative_to(O).as_posix()
def numbered_sources(directory):
    return sorted(p for p in directory.glob('*.csv') if re.match(r'^Source_\d{3}_',p.name))
def build():
    verification=json.loads((O/'review/machine_verification.json').read_text(encoding='utf-8'))
    assert verification['overall']=='PASS'
    repack=json.loads((O/'review/supplement_repack.json').read_text(encoding='utf-8'))
    changes=json.loads((O/'review/manuscript_change_ledger.json').read_text(encoding='utf-8'))
    figures=readcsv(O/'review/main_figure_dimensions.csv')
    # Combine the exact vector pages without rasterisation, rotation or clipping.
    merged=PdfWriter();comparison=PdfWriter()
    for r in figures:
        name=r['figure'];new=O/'figures'/f'{name}.pdf';old=I/'figures'/f'{name}.pdf'
        merged.add_page(PdfReader(new).pages[0])
        title=io.BytesIO();cv=canvas.Canvas(title,pagesize=(390*mm,235*mm))
        cv.setFont('Helvetica-Bold',11);cv.drawString(10*mm,224*mm,name.replace('_',' '))
        cv.setFont('Helvetica',9);cv.drawString(10*mm,215*mm,'Locked TARGETED_FINAL baseline')
        cv.drawString(200*mm,215*mm,'VISUAL_FINAL: new presentation')
        if name.startswith('Figure_6'):
            cv.setFont('Helvetica',8)
            cv.drawString(10*mm,15*mm,'Reference style: first_version_TCR_style.R.txt; blue points, grey OLS mean line / pale mean band, gold zero-to-effect segments.')
            cv.drawString(10*mm,10*mm,'Only style borrowed from the first TCR code. All patient coordinates and Spearman results come from the locked current baseline.')
        cv.save();title.seek(0);page=PdfReader(title).pages[0]
        for p,x in [(old,10),(new,200)]:
            source=PdfReader(p).pages[0];scale=180*mm/float(source.mediabox.width)
            height=float(source.mediabox.height)*scale
            page.merge_transformed_page(source,Transformation().scale(scale).translate(x*mm,208*mm-height))
        comparison.add_page(page)
    if '--indexes-only' not in sys.argv:
        with (O/'figures/Figures_1_to_6.pdf').open('wb') as f:merged.write(f)
        with (O/'review/baseline_vs_final_180mm.pdf').open('wb') as f:comparison.write(f)
    for kind in ['RED','CLEAN']:
        name=f'manuscript_VISUAL_FINAL_{kind}'
        shutil.copy2(O/'review/render'/name/f'{name}.pdf',O/'manuscript'/f'{name}.pdf')
    # Active panel source index is separate from immutable historical panel filenames.
    sources=[]
    def add(panel,p,role):
        assert p.is_file(),str(p)
        sources.append(dict(panel=panel,path=rel(p),bytes=p.stat().st_size,sha256=sha(p),role=role,
            source='Locked TARGETED_FINAL baseline or deterministic presentation transform; original accession and row keys retained in each CSV'))
    for r in figures:
        figure_number=int(r['figure'].split('_')[1])
        for letter in 'ABC':
            panel=f'F{figure_number}{letter}'
            if panel=='F1A':
                add(panel,O/'presentation_code/plot_final.R','R vector schematic; illustrative icons, no experimental measurements')
            elif panel=='F1B':
                add(panel,O/'source_data/display/F1B_coverage.csv','Core model case/control counts; display input')
                for f in ['F2A','F3A']:add(panel,O/'source_data/final_panels'/f'{f}.csv','Model-specific biological replicate counts')
            elif panel=='F1C':
                for f in ['F1C_coverage','F1C_donors']:add(panel,O/'source_data/display'/f'{f}.csv','Deterministic inventory / donor coverage')
                inventory=list((I/'organoid_donor_extension/results').glob('*/model_inventory.csv'))
                assert len(inventory)==1,'Ambiguous donor-model inventory'
                add(panel,inventory[0],'Unchanged donor-model inventory')
            else:
                add(panel,O/'source_data/final_panels'/f'{panel}.csv','Unchanged current panel measurements and original keys')
                for p in sorted((O/'source_data/display').glob(f'{panel}*.csv')):add(panel,p,'Display coordinates, labels or explicitly authorised F6B mean-band values')
    for f in ['F2B_statistics','F6A_stats','F6B_stats']:add(f,O/'source_data/panel_sources'/f'{f}.csv','Original statistical summary, unchanged')
    writecsv(O/'source_data/figure_source_index.csv',sources)
    # List all preserved inputs with content hashes and roles, not inferred biological identities.
    inputs=[]
    for base,source in [(I,'submission_candidate_TARGETED_FINAL_20260914T021531Z.zip'),(O/'task','ICI_TARGETED_FINAL_REDESIGN execution package')]:
        for p in sorted(base.rglob('*')):
            if not p.is_file():continue
            name=p.as_posix().lower()
            role=('coordinates / complete spatial atlas' if any(x in name for x in ['coordinates','spot_scores','spatial_view']) else
                  'preserved model result / full estimate' if any(x in name for x in ['/results/','full_source_tables']) else
                  'current panel input / reader table' if '/source_data/' in name or '/reader_tables/' in name else
                  'immutable provenance or historical presentation; not an analysis entry')
            inputs.append(dict(path=rel(p),bytes=p.stat().st_size,sha256=sha(p),source=source,analysis_role=role))
    writecsv(O/'review/used_input_inventory.csv',inputs)
    # Source mapping for each revised reader plate, keeping the original identifiers as provenance only.
    supp=[]
    for r in repack['reader_plates']:
        supp.append(dict(new_reader_id=r['new_id'],reader_pdf_page=r['reader_pdf_page'],old_id=r['old_id'],
                         new_plot=r['pdf'].replace('\\','/'),original_plot='input_snapshot/'+r['source_pdf'].replace('\\','/'),
                         source_lookup='source_data/panel_sources, supplement/full_source_tables and input_snapshot extension source_data; see full inventory'))
    writecsv(O/'source_data/supplement_source_index.csv',supp)
    originals=numbered_sources(O/'supplement/full_source_tables')
    writecsv(O/'source_data/full_source_table_index.csv',[dict(path=rel(p),bytes=p.stat().st_size,sha256=sha(p)) for p in originals])
    coords=[
      ('Oxford spot coordinates and programme scores','spatial_extension/source_data/spot_scores.csv.gz'),
      ('Oxford section and patient mapping','spatial_extension/source_data/sample_manifest.csv'),
      ('Oxford patient scores','spatial_extension/source_data/patient_scores.csv'),
      ('Xenium full cell coordinates and scores','xenium_extension/source_data/cell_coordinates_scores.csv.gz'),
      ('Xenium map cell keys','xenium_extension/source_data/spatial_view_cell_keys.csv.gz'),
      ('Xenium map bounds','xenium_extension/source_data/spatial_view_bounds.csv')]
    for _,p in coords:assert (I/p).is_file(),p
    (O/'appendices/README.md').write_text('# Complete companion appendices\n\n'
        'These files accompany the candidate package; public repository deposition remains USER_PENDING. '
        'They are not omitted evidence or claimed online publications.\n\n'
        '- [Appendix A: prior export and selection history](Appendix_A_history.pdf) — '+str(len(repack['appendices']['A']))+' pages.\n'
        '- [Appendix B: complete Oxford and Xenium maps](Appendix_B_spatial_atlas.pdf) — '+str(len(repack['appendices']['B']))+' pages.\n'
        '- [Appendix C: all cohort-specific clinical estimates](Appendix_C_full_cohorts.pdf) — '+str(len(repack['appendices']['C']))+' pages.\n\n'
        'Original captions mention spatial_extension/ or xenium_extension/; in this package those roots are inside input_snapshot/. Exact links:\n\n'+
        '\n'.join(f'- [{label}](../input_snapshot/{p})' for label,p in coords)+
        '\n\n[All original Source tables](../source_data/full_source_table_index.csv) · [All 44 original page destinations](../supplement/figure_map.csv).\n',encoding='utf-8')
    (O/'source_data/README.md').write_text('# Source data navigation\n\n'
        'Use [figure_source_index.csv](figure_source_index.csv) for the six current figures. '
        'Files under final_panels/ are unchanged locked measurements. display/ contains deterministic positions/labels and the explicitly authorised F6B OLS mean band. '
        'The historical panel_sources filenames are preserved for traceability; an old F4D/F4E name is not a current panel.\n\n'
        'New F1B and F1C use actual model coverage; historical F1.csv is not the active coverage display. '
        'New F3C uses exact frozen gene memberships, without new selection.\n\n'
        '[Supplementary plot map](supplement_source_index.csv) · [Full source-table index](full_source_table_index.csv) · '
        '[Complete input hashes and roles](../review/used_input_inventory.csv) · [Spatial coordinate links](../appendices/README.md).\n',encoding='utf-8')
    (O/'review/USER_PENDING.md').write_text('# USER_PENDING: author and submission metadata\n\n'
        'Authors, affiliations, correspondence, funding/acknowledgements, CRediT, competing interests, permanent repository and DOI must be supplied or confirmed by the submitting group. '
        'These are not treated as scientific failures, but the package is not labelled submission-ready. '
        'No public upload or journal submission has been performed.\n',encoding='utf-8')
    (O/'review/change_summary.md').write_text('# Executed presentation changes\n\n'
        '- Figure 1: R vector study icons, actual case/control coverage, donor and estimability graphics.\n'
        '- Figure 2: white group gaps; equal-unit NES scatter with edge labels; all raw lung NES retained.\n'
        '- Figure 3: full oriented-NES dot matrix, unchanged AUC intervals, exact frozen set partition.\n'
        '- Figure 4: all count-model programme NES, all paired donor changes, all external selected-set results.\n'
        '- Figure 5: aligned GENE/AXIS forests and a three-source SORL1 plot with a separate FDR column.\n'
        '- Figure 6: pale patient boxplots; reference blue points, grey OLS mean line and pale pointwise mean band; gold zero-to-effect segments.\n'
        f'- Manuscript: {len(changes)} paragraphs changed for figures, references and truthful display-method statements; canonical Markdown generates both Word versions. Red adds/replacements and red struck deletions are real, but are not native Word tracked changes. EndNote field XML and unchanged paragraph/table XML were checked.\n'
        f'- Supplement: {repack["reader_pdf_pages"]} reader pages plus '+str(sum(map(len,repack['appendices'].values())))+' separate companion appendix pages; every original page is mapped. Twelve workbook sheets and all full Source CSV files retained.\n'
        '- Important negative and discordant results remain in the reader summary: donor exact-test uncertainty, Stem/Goblet differences, platform selected-set discordance, external SORL1 FDR, IFN-conditional uncertainty, Oxford FDR, Xenium partial coverage and clinical cohort-specific differences.\n'
        '- No primary model, membership, sample filter, threshold or source result was changed. The only new fitted display is the unchanged nine-patient F6B OLS line and conditional-mean band. Source fields and plot geometry were checked independently.\n\n'
        'Execution: individual build steps were run successfully; RUN_VISUAL_FINAL.ps1 -VerifyOnly was executed successfully. The entire fresh-directory rebuild was not redundantly run a second time. '
        'The entry stops on errors and requires a new destination. A new rebuild still requires manual page review and explicit final packaging.\n',encoding='utf-8')
    (O/'README.md').write_text('# VISUAL_FINAL 投稿候选包\n\n'
        '唯一基准：submission_candidate_TARGETED_FINAL_20260914T021531Z.zip\n\n'
        'SHA-256: `2996632626e80d820494d6cab072cb4becc7f7a78628b035da94bef16da1aa89`。完整输入快照保存在 input_snapshot/；旧文件名仅保留作溯源，不作为本轮图号。\n\n'
        '## 阅读入口\n\n'
        '- [真实红字稿](manuscript/manuscript_VISUAL_FINAL_RED.docx) / [对应 clean 稿](manuscript/manuscript_VISUAL_FINAL_CLEAN.docx)；另附实际 Word 渲染 PDF。\n'
        '- [六张主图合并预览 PDF](figures/Figures_1_to_6.pdf)；figures/ 同时提供各图 R 矢量 PDF、600 dpi LZW TIFF 和 PNG。名义宽度 180 mm，Cairo PDF 的整数点取整实测值见检查记录。\n'
        f'- [读者补充材料 PDF](supplement/Reader_SI.pdf) / [Word](supplement/Reader_SI.docx)：{repack["reader_pdf_pages"]} 页。\n'
        '- [12-sheet 补充表](supplement/Supplementary_Tables.xlsx)，原 reader CSV 与 Source_001–Source_079 CSV 均保留。\n'
        '- [附录 A/B/C 与完整坐标链接](appendices/README.md)：历史来源、九页完整空间图谱、七页逐队列估计。附录是随候选稿提供的独立附件，尚未声称已公开上线。\n'
        '- [当前 44 页的逐页去向](supplement/figure_map.csv)、[当前主图源表](source_data/figure_source_index.csv)。\n\n'
        '## 核查与复现\n\n'
        'RUN_VISUAL_FINAL.ps1 是独立呈现入口。使用 config/presentation_paths.json 中已安装的运行时；没有安装包或联网。'
        '全量统计入口未运行，最新供者模型及所有基准结果按字节保留；唯一新增拟合是 Fig. 6B 同九人的描述性 OLS。\n\n'
        '[修改清单](review/change_summary.md) · [数值逐对象核对](review/numeric_diff.csv) · [图层/坐标核对](review/panel_fidelity.csv) · '
        '[视觉检查](review/visual_QA.json) · [输入清单](review/used_input_inventory.csv) · [最终检查](review/final_verification.json)。\n\n'
        '主图源代码在 presentation_code/，失败尝试和后续修复的日志也保留。最终 ZIP 的逐文件哈希校验及 ZIP 自身 SHA-256 随 ZIP 提供；artifact_manifest_SHA256.csv 登记包内文件。\n\n'
        '作者、单位、通讯、基金、CRediT、利益冲突、仓库与 DOI 仍为 [USER_PENDING](review/USER_PENDING.md)。本包是已完成本轮呈现修订的投稿候选包，不称可立即正式提交。\n',encoding='utf-8')
    print('DELIVERY_INDEX_PASS',len(inputs),'preserved inputs;',len(sources),'active source links;',len(originals),'full Source CSVs')
if __name__=='__main__':build()
