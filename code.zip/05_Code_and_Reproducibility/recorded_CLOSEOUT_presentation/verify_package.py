"""Deterministic presentation checks; never imports or runs a statistical entry."""
from pathlib import Path
import csv,json,hashlib,zipfile,re,math,sys,platform,importlib.metadata
import xml.etree.ElementTree as ET
import numpy as np
import pandas as pd
from docx import Document
from pypdf import PdfReader
from PIL import Image
O=Path(__file__).resolve().parents[1];I=O/'input_snapshot'
W='{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
S='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def rows(p):
 with Path(p).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def savecsv(p,records):
 with Path(p).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(records[0]));w.writeheader();w.writerows(records)
def same_keys(a,b,key):
 aa=[r[key] for r in a];bb=[r[key] for r in b]
 if len(set(aa))!=len(aa) or len(set(bb))!=len(bb) or set(aa)!=set(bb):raise ValueError('Missing, duplicate or mismatched identities')
 return {r[key]:r for r in b}
def accepted(doc):return [''.join(r.text for r in p.runs if not r.font.strike) for p in doc.paragraphs]
def fields(p):
 with zipfile.ZipFile(p) as z:
  root=ET.fromstring(z.read('word/document.xml'))
  return {t:[ET.tostring(e,encoding='unicode') for e in root.iter(W+t)] for t in ['instrText','fldData','fldChar','fldSimple']}
def xlsx_values(path):
 with zipfile.ZipFile(path) as z:
  strings=[]
  if 'xl/sharedStrings.xml' in z.namelist():strings=[''.join(e.itertext()) for e in ET.fromstring(z.read('xl/sharedStrings.xml'))]
  book=ET.fromstring(z.read('xl/workbook.xml'));out={}
  rels={r.attrib['Id']:r.attrib['Target'] for r in ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))}
  for sheet in book.find(S+'sheets'):
   rid=sheet.attrib['{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id'];target=rels[rid]
   name=target.lstrip('/') if target.startswith('/') else 'xl/'+target
   cells={}
   for c in ET.fromstring(z.read(name)).iter(S+'c'):
    typ=c.get('t');v=c.find(S+'v')
    if typ=='inlineStr':val=''.join(t.text or '' for t in c.iter(S+'t'))
    elif v is None:val=None
    elif typ=='s':val=strings[int(v.text)]
    elif typ in ['str','e']:val=v.text
    elif typ=='b':val=v.text=='1'
    else:val=float(v.text)
    assert typ!='e',('Excel error',sheet.get('name'),c.get('r'),val)
    cells[c.get('r')]=val
   out[sheet.get('name')]=cells
  return out
def verify():
 checks=[];diff=[]
 def check(name,condition,detail):
  checks.append({'check':name,'status':'PASS' if condition else 'FAIL','detail':detail})
  if not condition:raise AssertionError((name,detail))
 # Every baseline object is retained, including historical models and run evidence.
 manifest=rows(I/'artifact_manifest_SHA256.csv')
 for r in manifest:
  p=I/r['path'];check('baseline:'+r['path'],p.is_file() and p.stat().st_size==int(r['size']) and sha(p)==r['sha256'],'Exact immutable baseline object')
 for rel,dest in [('source_data','source_data'),('supplementary/full_source_tables','supplement/full_source_tables'),('supplementary/reader_tables','supplement/reader_tables')]:
  for src in (I/rel).rglob('*'):
   if src.is_file():
    target=O/dest/src.relative_to(I/rel)
    check('copy:'+str(src.relative_to(I)),target.is_file() and sha(src)==sha(target),'Byte-identical preservation')
    if src.suffix=='.csv':diff.append({'source':str(src.relative_to(I)),'output':str(target.relative_to(O)),'numeric_changes':0,'missingness_changes':0,'identity_changes':0,'sha256':sha(target),'status':'PASS'})
 # Manuscript redline, field codes/data, and untouched content.
 basepath=I/'manuscript/manuscript_TARGETED_FINAL_CLEAN.docx';base=Document(basepath)
 redpath=O/'manuscript/manuscript_VISUAL_FINAL_RED.docx';cleanpath=O/'manuscript/manuscript_VISUAL_FINAL_CLEAN.docx'
 red=Document(redpath);clean=Document(cleanpath)
 check('accepted_red_equals_clean',accepted(red)==[p.text for p in clean.paragraphs],'Deletion runs excluded; same accepted text')
 for path in [redpath,cleanpath]:check('EndNote:'+path.name,fields(path)==fields(basepath),'All instrText, fldData, fldChar and fldSimple XML preserved')
 for j,(a,b,c) in enumerate(zip(base.paragraphs,red.paragraphs,clean.paragraphs)):
  if a.text==c.text:check('unchanged_paragraph:'+str(j),a._p.xml==b._p.xml==c._p.xml,'Original run XML and formatting retained')
 check('tables_preserved',[t._tbl.xml for t in base.tables]==[t._tbl.xml for t in clean.tables]==[t._tbl.xml for t in red.tables],'Original table XML retained')
 source=(O/'manuscript/manuscript_source.md').read_text(encoding='utf-8')
 blocks={int(i):t.rstrip('\n') for i,t in re.findall(r'<!-- paragraph:(\d+) -->\n(.*?)(?=\n\n<!--|\Z)',source,re.S)}
 check('canonical_source',all(blocks[i]==p.text for i,p in enumerate(clean.paragraphs)),'All paragraphs generated from the sole canonical source')
 prose='\n'.join(p.text for p in clean.paragraphs)
 check('old_SI_references_absent',not re.search(r'Supplementary Fig(?:ure)?s?\.?\s+[0-9]',prose),'Accepted prose uses S1-S8 / Appendices A-C')
 check('entry_and_OLS_description','RUN_VISUAL_FINAL.ps1' in prose and 'RUN_PRESENTATION_ONLY.ps1' not in prose and 'No confidence intervals or fitted trends were generated solely for display' not in prose,'Code availability and Fig. 6 legend updated')
 # Supplement mapping and attachments.
 mapping=rows(O/'supplement/figure_map.csv')
 check('44_page_map',[int(r['current_pdf_page']) for r in mapping]==list(range(1,45)),'Every original page has a retained original link and new destination')
 for r in mapping:
  for f in r['file'].split('; '):check('destination:'+r['current_pdf_page']+':'+f,(O/f).is_file(),r['new_id'])
 repack=json.loads((O/'review/supplement_repack.json').read_text(encoding='utf-8'))
 for name,count in [('Reader_SI.pdf',repack['reader_pdf_pages'])]:check('reader_pages',len(PdfReader(O/'supplement'/name).pages)==count,str(count))
 for letter,name in [('A','history'),('B','spatial_atlas'),('C','full_cohorts')]:check('Appendix_'+letter,len(PdfReader(O/'appendices'/f'Appendix_{letter}_{name}.pdf').pages)==len(repack['appendices'][letter]),'All assigned original plates present')
 # Workbook numeric cells retain source values; only approved display labels change.
 wb=xlsx_values(O/'supplement/Supplementary_Tables.xlsx');payload=json.loads((O/'supplement/workbook_input.json').read_text(encoding='utf-8'))
 check('workbook_sheets',list(wb)==[d['sheet'] for d in payload],'Continuous S1-S12')
 cell_count=0
 for d in payload:
  for row_no,row in enumerate([d['columns']]+d['rows'],1):
   for col_no,v in enumerate(row):
    address=f'{chr(65+col_no)}{row_no}';actual=wb[d['sheet']].get(address)
    ok=math.isclose(actual,v,rel_tol=1e-14,abs_tol=0) if isinstance(v,(int,float)) and not isinstance(v,bool) and isinstance(actual,(int,float)) else actual==v
    check('cell:'+d['sheet']+'!'+address,ok,'Unrounded numeric payload or exact display string');cell_count+=1
 # Existing values underlying manuscript quantitative additions and negative summaries.
 fp=lambda id:pd.read_csv(I/f'source_data/final_panels/{id}.csv')
 tab=lambda n:pd.read_csv(next((I/'supplementary/full_source_tables').glob(f'Source_{n:03}_*.csv')))
 module='ICI_COLITIS_EPITHELIAL_LOSS_STRICT'
 countdir=I/'organoid_donor_extension/results/20260914T062958'
 inv=pd.read_csv(countdir/'model_inventory.csv');gsea=pd.read_csv(countdir/'module_GSEA.csv')
 claims=[]
 def claim(name,actual,expected,source_ref):
  check('claim:'+name,actual==expected,{'actual':actual,'expected_display':expected,'source':source_ref})
  claims.append({'claim':name,'verified_value':str(actual),'manuscript_or_SI_value':str(expected),'source':source_ref,'status':'PASS'})
 claim('estimable_count_models',len(inv),25,'model_inventory.csv')
 claim('planned_count_models',len(gsea[['ligand','celltype']].drop_duplicates()),32,'module_GSEA.csv')
 claim('estimable_set_tests',int((gsea.status=='ESTIMATED').sum()),100,'module_GSEA.csv')
 claim('planned_set_tests',len(gsea),128,'module_GSEA.csv')
 claim('paired_donors',int(inv.n_donors.min()),3,'model_inventory.csv')
 donor=tab(78);ta=donor[(donor.ligand=='TNFSF12')&(donor.celltype=='Transit_Amplifying')&(donor.module==module)].iloc[0]
 claim('TA_exact_donor_P',float(ta.exact_signflip_P),.25,'Source_078')
 claim('TA_exact_donor_FDR',float(ta.FDR_predeclared_family),.5,'Source_078')
 m=fp('F3C');sets={k:set(d.gene) for k,d in m.groupby('module')};up=sets['ICI_COLITIS_EPITHELIAL_UP_STRICT'];residual=sets['ICI_COLITIS_EPITHELIAL_UP_NON_IFN'];ifn=sets['CURATED_IFN_VISIBILITY']
 claim('up_residual_overlap_sizes',(len(up),len(residual),len(up&ifn)),(84,80,4),'F3C member table')
 check('set_partition',up-ifn==residual,'Exact membership partition, no new gene selection')
 claim('IFN_overlap',sorted(up&ifn),['CD47','IFITM3','LAP3','STAT3'],'F3C member table')
 claim('separate_reference_sizes',(len(ifn),len(sets[module])),(224,275),'F3C member table')
 lung=fp('F2C');claim('depleted_lung_FDR_passes',int(((lung.pathway==module)&(lung.padj<.05)).sum()),0,'F2C')
 so=fp('F5C');claim('external_SORL1_FDR_passes',int(((so.source_group=='External patient families')&(so.q<.05)).sum()),0,'F5C')
 conditional=tab(72);ext=conditional[conditional.role=='independent_primary'];claim('IFN_conditional_tests',len(ext),8,'Source_072');claim('IFN_conditional_FDR_passes',int((ext.fdr<.05).sum()),0,'Source_072')
 cover=tab(71);down=cover[cover.module==module].iloc[0];claim('Xenium_depleted_coverage',(int(down.available),int(down.requested)),(64,275),'Source_071')
 ox=rows(O/'supplement/reader_tables/Supplementary_Table_S10.csv');qkey=next(k for k in ox[0] if 'fdr' in k.lower());claim('Oxford_four_FDR',[round(float(r[qkey]),4) for r in ox],[.0667,.1167,.1167,.1167],'Reader S10 and full sources')
 # F6B: algebraic verification of the authorized display fit, no new test or patient selection.
 tc=fp('F6B');prediction=pd.read_csv(O/'source_data/display/F6B_OLS_mean_band.csv');x=tc.cross_cd4_cd8_cell_fraction.to_numpy();y=tc[module].to_numpy();xg=prediction.cross_cd4_cd8_cell_fraction.to_numpy()
 slope=np.sum((x-x.mean())*(y-y.mean()))/np.sum((x-x.mean())**2);intercept=y.mean()-slope*x.mean();fitted=intercept+slope*xg
 distribution=rows(O/'review/F6B_distribution_reference.csv')[0]
 df=len(x)-2;check('F6B_band_df',int(distribution['residual_df'])==df,'OLS residual degrees of freedom')
 variance=np.sum((y-intercept-slope*x)**2)/df;half=float(distribution['t_critical'])*np.sqrt(variance*(1/len(x)+(xg-x.mean())**2/np.sum((x-x.mean())**2)))
 check('F6B_OLS_mean_band',bool(np.allclose(prediction.fit,fitted,rtol=0,atol=1e-12) and np.allclose(prediction.lwr,fitted-half,rtol=0,atol=1e-12) and np.allclose(prediction.upr,fitted+half,rtol=0,atol=1e-12)),'Closed-form audit of same patient data and conditional mean band')
 stats=rows(I/'source_data/panel_sources/F6B_stats.csv')
 (O/'review/F6B_display_fit_full_precision.json').write_text(json.dumps({'patient_ids':tc.patient_id.tolist(),'n':len(tc),'intercept':intercept,'slope':slope,'residual_df':df,'band':'Pointwise 95% OLS conditional-mean band; descriptive only','original_spearman_full_precision_strings':stats},indent=2),encoding='utf-8')
 # Physical dimensions, TIFF density/compression and vector content.
 for r in rows(O/'review/main_figure_dimensions.csv'):
  name=r['figure'];p=PdfReader(O/'figures'/f'{name}.pdf').pages[0]
  # Cairo PDF quantizes its media box to whole PostScript points (1 pt = 0.353 mm).
  actual_mm=(float(p.mediabox.width)*25.4/72,float(p.mediabox.height)*25.4/72)
  check('PDF_size:'+name,abs(actual_mm[0]-float(r['width_mm']))<25.4/72 and abs(actual_mm[1]-float(r['height_mm']))<25.4/72,{'requested_mm':[r['width_mm'],r['height_mm']],'actual_mm':actual_mm,'device_rounding':'within one Cairo PDF point'})
  check('PDF_vector_text:'+name,len(p.extract_text())>80,'Text extractable; direct R Cairo PDF')
  with Image.open(O/'figures'/f'{name}.tiff') as im:check('TIFF:'+name,im.tag_v2[259]==5 and all(abs(float(v)-600)<.1 for v in im.info['dpi']),'600 dpi, LZW compression')
 geometry=rows(O/'review/panel_fidelity.csv');check('plot_fidelity',all(r['status']=='PASS' for r in geometry),'Source fields, geometry, shared colour scales and original CI endpoints')
 savecsv(O/'review/numeric_diff.csv',diff);savecsv(O/'review/numerical_claim_checks.csv',claims)
 # Audit counts in overview do not replace object-level evidence.
 versions={p:importlib.metadata.version(p) for p in ['pandas','numpy','python-docx','pypdf','pypdfium2','reportlab','Pillow']}
 versions.update(python=sys.version,python_executable=sys.executable,platform=platform.platform(),R='See logs/presentation_R_sessionInfo.txt',Word='See review/word_render_records.json')
 (O/'review/artifact_environment.json').write_text(json.dumps(versions,indent=2),encoding='utf-8')
 (O/'review/machine_verification.json').write_text(json.dumps({'overall':'PASS','checks':checks,'check_count':len(checks),'baseline_manifest_entries':len(manifest),'workbook_cells_checked':cell_count,'primary_numeric_changes':0,'new_display_only':'same nine-patient F6B OLS conditional-mean line and band','visual_QA':'Separate manual render review required','submission_metadata':'USER_PENDING'},indent=2),encoding='utf-8')
 print('MACHINE_VERIFICATION_PASS',len(checks),'checks;',cell_count,'workbook cells; primary numeric changes 0')
if __name__=='__main__':verify()
