"""Record completed visual inspection and finite closeout results before sealing."""
from closeout_common import W,S,V
from pathlib import Path
from datetime import datetime,timezone
import ast,csv,json,hashlib,shutil
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def readcsv(p):
    with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def writejson(p,obj):p.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
dest=S/'06_Review_and_Codex/closeout'
# Static syntax checks do not import or execute any historical analysis module.
parsed=[]
for folder in [W/'presentation_code',W/'tests']:
    for p in sorted(folder.glob('*.py')):
        ast.parse(p.read_text(encoding='utf-8-sig'),filename=str(p));parsed.append(p.relative_to(W).as_posix())
writejson(W/'review/python_static_parse.json',{'status':'PASS','files':parsed})
att=json.loads((W/'review/visual_attestation_input.json').read_text())
manifest=json.loads((W/'review/visual_render_manifest.json').read_text())
viewed={Path(p).as_posix() for p in att['viewed']}
assert viewed=={Path(p).as_posix() for p in manifest['review_images']}
images=[{'path':p,'sha256':sha(W/p),'status':'VISUALLY_REVIEWED'} for p in sorted(viewed)]
pdfs=sorted({Path(r['file']).as_posix() for r in manifest['pages']})
mains=[{'path':p.relative_to(W).as_posix(),'sha256':sha(p),'status':'VISUALLY_REVIEWED'} for p in sorted((W/'figures').glob('*_preview.png'))]
review={'status':'PASS','method':'Actual native Word PDF rendering and PDFium page/crop rendering, followed by agent visual inspection of every listed image. Automated hash checks only bind this record to the inspected files; they are not a substitute for inspection.','review_images':images,'reviewed_pdfs':[{'path':p,'sha256':sha(S/p),'pages':sum(Path(r['file']).as_posix()==p for r in manifest['pages'])} for p in pdfs],'rendered_pdf_pages':len(manifest['pages']),'main_figures':mains,'workbook_note':'S8 K5 before and after artifact-tool render inspected','corrections_verified':['Figure 2A labels below Heart/Colon groups; no collision with the following panels','Figure 3C retained partition and selection rule','Figure 6B blue points/grey OLS mean/pale-grey mean band and Figure 6C gold segments with distinct median differences','Main RED/CLEAN code-path paragraphs left-aligned after visible stretched justification; final versions reviewed','Reader SI first-page panel index moved before S1; inherited blue heading borders removed and revised pages re-rendered and inspected','S4 a-d, S5 a-i, S7 a-k and original in-plot S4a-b reference visible at native chart width','All preserved Appendix A/B/C pages viewed; no missing panel or clipping identified'],'unresolved_production_issues':[],'completed_utc':datetime.now(timezone.utc).isoformat()}
writejson(W/'review/visual_review.json',review)
audit=json.loads((W/'review/closeout_verification.json').read_text())
assert all(r['status']=='PASS' for r in audit['checks'])
logs=[dict(json.loads(p.read_text()),record_file=p.relative_to(S).as_posix()) for p in sorted((W/'logs').glob('*.json'))]
failed=[]
for r in logs:
    if r.get('exit_code',0)==0:continue
    command=' '.join(r.get('command',[]))
    if 'configure_closeout.py' in command:reason='Presentation patch expected a non-existent old string; corrected the exact patch and reran successfully.'
    elif 'audit_fidelity.R' in command:reason='Required work-root command argument omitted; rerun with the argument passed all source-field checks.'
    elif 'verify_closeout.py' in command or 'RUN_CLOSEOUT.ps1' in command:reason='Verifier initially included Source_index.csv in numbered source tables; restricted to numbered source files and reran verifier and entry successfully.'
    else:raise AssertionError('Unclassified failure: '+command)
    failed.append({'record':r['record_file'],'exit_code':r['exit_code'],'classification':'RESOLVED_PRESENTATION_OR_AUDIT_ERROR','resolution':reason})
execution={'status':'PASS','command_records':[{'record':r['record_file'],'command':r.get('command'),'exit_code':r.get('exit_code'),'start_utc':r.get('start_utc'),'end_utc':r.get('end_utc')} for r in logs if 'exit_code' in r],'retained_resolved_failures':failed,'additional_session_command_issue':'A PDF refresh launcher was initially given a non-executable label; no child process started. Corrected invocation completed successfully. Read-only Get-Content probes for two guessed file paths failed; the actual paths were then read. These were not analysis failures.','forbidden_primary_runs':'NOT_RUN by explicit task scope: DE, GSEA, Cox, Meta, donor refits and raw clone rarefaction; no package installation/download','allowed_fit':'Same nine Fig. 6B patients, descriptive OLS mean/band only','static_python_files':len(parsed),'static_R':'Seven presentation R files parsed successfully; see actual command log','fixture_tests':'Five closeout fixture/scope tests passed; see actual command log','package_verification':'Performed by package_closeout.py; authoritative ZIP receipt is alongside the ZIP to avoid a self-referential checksum.'}
writejson(W/'review/execution_closeout.json',execution)
tcr=readcsv(W/'review/F6C_closeout_verification.csv')
red=json.loads((W/'review/red_clean_equivalence.json').read_text())
changes=[
 {'item':'Figure 2A','change':'scale_x_continuous position top to bottom; regenerated six main figures via current R presentation code','unchanged':'Original NES/FDR, order, cells and Heart/Colon headers','evidence':'review/panel_fidelity.csv; figures/Figure_2_receiver_programmes.pdf'},
 {'item':'Figure 3C','change':'Definition title and retained fraction; selection_rule joined from Source_021 by module+gene in reproducible prepare_visual.py and public panel copies','unchanged':'All gene memberships and numerical fields; no DE/GSEA','evidence':'review/F3C_selection_rule_changes.csv; manuscript_change_ledger.json'},
 {'item':'Figure 6C','change':'Distinct delta-median labels; legend explains equal rank U and original equal P/BH FDR','unchanged':'Two original metrics, patients, rarefaction, tests and nine-test BH family','evidence':'F6C_closeout_verification.csv'},
 {'item':'Supplementary S1-S8','change':'Continuous inner-panel letters, one vector file per figure; synchronized manuscript, legends, Reader SI, mappings and indices; retained original-width long canvases','unchanged':'All positive/negative/NE/discordant panels and original scientific coordinates','evidence':'02_Supplementary_Figures_OneFilePerFigure/panel_mapping.csv; original_44_page_disposition.csv'},
 {'item':'Supplementary Table S8','change':'Only K5 explanatory reference changed to Supplementary Figure S8 / Appendix C; JSON note synchronized','unchanged':'All workbook numerical values, formulas and style IDs','evidence':'closeout_verification.json'},
 {'item':'Manuscript RED/CLEAN','change':'Seven scoped paragraphs revised; FF0000 insertions and red strikeout deletions; corresponding clean; code-path alignment corrected after visual inspection','unchanged':'Clinical introduction, biological discussion, citation fields and all original tables','evidence':'manuscript_change_ledger.json; red_clean_equivalence.json; visual_review.json'},
 {'item':'Code and provenance','change':'Actual RUN_CLOSEOUT.ps1 entry and indexed current presentation source; preserved complete exact recovered analysis code; refreshed manifests','unchanged':'Original models, historical analysis files and source archives','evidence':'05_Code_and_Reproducibility/CURRENT_CODE_INDEX.csv; exact_source_recovery_manifest.csv'},
 {'item':'Submission information','change':'Author/affiliation/correspondence/funding/COI/CRediT/ethics/licence/repository/DOI/journal information separately listed USER_PENDING','unchanged':'No invented metadata, licence or submission-readiness claim','evidence':'USER_PENDING.csv'}]
with (dest/'LIMITED_CHANGE_LEDGER.csv').open('w',encoding='utf-8-sig',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=changes[0]);writer.writeheader();writer.writerows(changes)
rows='\n'.join('| '+r['item']+' | '+r['change']+' | '+r['unchanged']+' |' for r in changes)
effects='; '.join(f"{r['metric']}: delta median={r['median_difference']}, U={r['U']}, original P={r['original_p']}, original FDR={r['original_fdr']}" for r in tcr)
(dest/'LIMITED_CHANGE_LEDGER.md').write_text(f"""# 本轮有限修改账本

唯一数值基准：submission_candidate_VISUAL_FINAL_20260914T045831Z.zip；SHA-256 7537083659facb999e7a53bbddf11abb779851d54790f4bdb46427d102c390bd。新目录采用已整理的 01–06 投稿结构。原 ZIP 与基准快照未修改。

| 项目 | 本轮实际修改 | 保留范围 |
|---|---|---|
{rows}

Figure 6C 核对：{effects}。仅核对观察值、中位数及成对秩比较；没有重新计算 P 或 BH FDR。

验证：{len(audit['checks'])} 类审计全部 PASS；完整 Source_001–079 字节一致；完整基准 input_snapshot 的所有登记文件哈希一致。红字稿采用可见 FF0000 和删除线，并非原生 Word Track Changes；接受后的文字与 clean 完全一致，原引用域与表格保留。原 44 页材料均可通过页映射获取，18 页 Reader SI 保留阴性与不一致结果摘要，附录 A–C 保留完整内容。

视觉检查：六主图分别查看；两份 26 页主文、18 页 SI Word、18 页矢量 SI、Table 1、8 个合并补图和附录 A–C 全部实际渲染并逐页/逐区查看。输入的 10 页核查 Word 也完整阅读、渲染查看。详见 visual_review.json 的具体文件与哈希；不是仅凭文件存在判定通过。

运行：R 绘图、原统计保真审计、Word 原生渲染与最终入口均实际成功。早期呈现/调用/核验错误已分类修复，失败日志原样保留，见 execution_closeout.json。禁止的 DE/GSEA/Cox/Meta/供者重拟合均未运行。

状态：科学范围 PASS；数值 PASS；制作/引用 PASS；执行 PASS；作者与期刊等投稿信息 USER_PENDING。最后的 ZIP 成员逐项 SHA-256 与 CRC 验证见 ZIP 同名 .verification.json。
""",encoding='utf-8')
for name in ['visual_review.json','visual_attestation_input.json','visual_render_manifest.json','python_static_parse.json','execution_closeout.json','preserved_model_snapshot_manifest.json','closeout_input_preflight.json','closeout_code_patch_ledger.json']:
    shutil.copy2(W/'review'/name,dest/name)
old=S/'DELIVERY_STATUS.json';archive=dest/'pre_closeout_DELIVERY_STATUS.json'
if old.exists() and not archive.exists():shutil.copy2(old,archive)
writejson(old,{'baseline_zip':'submission_candidate_VISUAL_FINAL_20260914T045831Z.zip','baseline_sha256':'7537083659facb999e7a53bbddf11abb779851d54790f4bdb46427d102c390bd','science_scope':'PASS','numerical_fidelity':'PASS','production_and_references':'PASS','execution':'PASS','submission_information':'USER_PENDING','release':'CANDIDATE_PENDING_AUTHOR_AND_JOURNAL_INFORMATION','changed_statistical_values':audit['changed_statistical_values'],'visual_review':'06_Review_and_Codex/closeout/visual_review.json','limited_change_ledger':'06_Review_and_Codex/closeout/LIMITED_CHANGE_LEDGER.md','execution_record':'06_Review_and_Codex/closeout/execution_closeout.json','user_pending':'06_Review_and_Codex/closeout/USER_PENDING.csv','primary_models_refit':False,'zip_verification':'Actual sealed-archive member hash/CRC receipt is the .verification.json beside the delivered ZIP.'})
print('FINAL_REVIEW_RECORD_PASS',len(images),'review images;',len(manifest['pages']),'rendered PDF pages;',len(mains),'main figures;',len(parsed),'Python syntax checks')

