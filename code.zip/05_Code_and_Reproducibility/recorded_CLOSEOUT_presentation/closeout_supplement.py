"""Vector composition and reference changes only; all statistical marks are retained."""
from closeout_common import W,S,V,refs,PLATE_SPANS
from pathlib import Path
from copy import deepcopy
from collections import defaultdict
import json,csv,re,io,shutil
from pypdf import PdfReader,PdfWriter,Transformation
from pypdf.generic import ContentStream,NameObject,TextStringObject
import pdfplumber
import pypdfium2 as pdfium
from reportlab.pdfgen import canvas
from reportlab.platypus import Paragraph
from reportlab.lib.styles import ParagraphStyle
from docx import Document
from docx.shared import Mm,Pt,RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
mm=72/25.4
out=W/'supplement/closeout_plates';out.mkdir(exist_ok=True)
payload=json.loads((V/'supplement/reader_SI_source.json').read_text(encoding='utf-8'))
groups=defaultdict(list);tag_ledger=[]

def relabel(src,dst,mapping):
    rd=PdfReader(src);pg=rd.pages[0]
    with pdfplumber.open(src) as doc:
        chars=[c for c in doc.pages[0].chars if c['text'] in mapping and abs(c['size']-14)<.1]
    assert len(chars)==len(mapping),(src,chars)
    assert sorted(c['text'] for c in chars)==sorted(mapping)
    cs=ContentStream(pg.get_contents(),rd);removed=[]
    for args,op in cs.operations:
        if op==b'Tj' and str(args[0]) in mapping:
            removed.append(str(args[0]));args[0]=TextStringObject('')
    assert sorted(removed)==sorted(mapping),(src,removed)
    pg[NameObject('/Contents')]=cs
    b=io.BytesIO();c=canvas.Canvas(b,pagesize=(float(pg.mediabox.width),float(pg.mediabox.height)))
    c.setFont('Helvetica-Bold',14)
    for ch in chars:
        c.drawString(ch['x0'],float(pg.mediabox.height)-ch['bottom']+2.8,mapping[ch['text']])
        tag_ledger.append({'plate':src.stem,'old':ch['text'],'new':mapping[ch['text']],'x':ch['x0'],'top':ch['top'],'action':'remove original single-glyph text operation, add vector label'})
    c.save();pg.merge_page(PdfReader(b).pages[0]);wr=PdfWriter();wr.add_page(pg)
    with dst.open('wb') as f:wr.write(f)

def whole_tag(src,dst,letter):
    # Add a tag margin without covering or shrinking any scientific content.
    p=PdfReader(src).pages[0];w=float(p.mediabox.width);h=float(p.mediabox.height)
    b=io.BytesIO();c=canvas.Canvas(b,pagesize=(w,h+16));c.setFont('Helvetica-Bold',12);c.drawString(3,h+3,letter);c.save()
    p0=PdfReader(b).pages[0];p0.merge_page(p);wr=PdfWriter();wr.add_page(p0)
    with dst.open('wb') as f:wr.write(f)
    tag_ledger.append({'plate':src.stem,'new':letter,'action':'add vector panel tag in new margin'})

for p in payload['plates']:
    old=p['new_id'];src=W/'supplement/plates'/f'{old}.pdf';dst=out/f'{old}.pdf'
    if old=='S7B':relabel(src,dst,dict(zip('abc','efg')))
    elif old=='S7C':relabel(src,dst,dict(zip('abcd','hijk')))
    elif old in ['S2A','S2B','S5C']:whole_tag(src,dst,PLATE_SPANS[old][-1])
    else:shutil.copy2(src,dst)
    p['source_plate_id']=old;p['new_id']=PLATE_SPANS[old]
    p['pdf']=dst.relative_to(W).as_posix();p['png']=dst.with_suffix('.png').relative_to(W).as_posix()
    cap=refs(p['caption']).replace('platform samples are from GSE210037','GSE210037 measurements are sample pseudobulk')
    if old=='S7B':cap=cap.replace('a-c,','e-g,')
    if old=='S7C':cap=cap.replace('a-d,','h-k,')
    if old=='S4B':cap=cap.replace('across two panels.','across panels c-d.')
    if old=='S6A':
        cap='Patient-level programme associations conditional on IFN. a-b, Adjusted disease coefficients and pointwise 95% HC3 t intervals for the fixed non-IFN and disease-depleted programmes. Open points show unadjusted coefficients, and q values use BH correction across all eight independent-cohort tests. Complete scores, coefficients and leave-one-patient-out estimates are in Supplementary Table S12.'
    if old=='S6B':
        cap='c-d, All observed patient scores, with separate family axes to show overlap. Each family contains the same eight irColitis and five PD-1-treated control patients; these are not four cohorts. Loss scores are oriented as one minus raw rank. Little IFN-score overlap and small sample size limit conditional interpretation. Complete scores, coefficients and leave-one-patient-out estimates are in Supplementary Table S12.'
    p['caption']=cap;groups[re.match(r'S\d+',old)[0]].append(p)
    doc=pdfium.PdfDocument(str(dst));doc[0].render(scale=300/72).to_pil().save(dst.with_suffix('.png'));doc.close()

# Synchronize current reader-facing references. Historical source files stay unchanged.
for content in payload['front_pages']:
    for r in content:
        r[1]=refs(r[1]).replace('Supplementary Figure 17','Supplementary Figure S8 / Appendix C')
        r[1]=r[1].replace('Matching CSV files are in reader_tables/. Full Source_001-Source_079 files are in full_source_tables/', 'Matching CSV files are in 01_Journal_Upload/05_Supplementary_Tables/reader_csv/. Full Source_001-Source_079 files are in 04_Source_Data/full_source_tables/')
payload['front_pages'][0].insert(4,['body','Panel index: S1 (single); S2a-b; S3 (single); S4a-d; S5a-i; S6a-d; S7a-k; S8a-b. Each figure has one vector PDF in 02_Supplementary_Figures_OneFilePerFigure/. Continued pages below retain the same figure and panel identities at readable chart width.'])
(W/'supplement/reader_SI_source.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')

def setup(doc):
    sec=doc.sections[0];sec.page_width=Mm(210);sec.page_height=Mm(297);sec.left_margin=sec.right_margin=Mm(15);sec.top_margin=sec.bottom_margin=Mm(10);sec.footer_distance=Mm(5)
    for name,size in [('Normal',10.5),('Title',15),('Heading 1',11.5)]:
        st=doc.styles[name];st.font.name='Arial';st.font.size=Pt(size);st.font.color.rgb=RGBColor(0,0,0);st.paragraph_format.space_after=Pt(5)
        for border in st.element.xpath('.//w:pBdr'):border.getparent().remove(border)
    p=sec.footer.paragraphs[0];p.alignment=1;f=OxmlElement('w:fldSimple');f.set(qn('w:instr'),'PAGE');p._p.append(f)
def dp(doc,role,text):
    p=doc.add_paragraph(text,'Title' if role=='title' else 'Heading 1' if role=='h' else 'Normal')
    if role=='body':p.paragraph_format.keep_with_next=False
    return p
doc=Document();setup(doc)
for n,content in enumerate(payload['front_pages']):
    if n:doc.add_page_break()
    for role,text in content:dp(doc,role,text)
for p in payload['plates']:
    doc.add_page_break();dp(doc,'h','Supplementary Figure '+p['new_id'])
    q=doc.add_paragraph();q.paragraph_format.space_after=Pt(4);q.add_run().add_picture(str(W/p['png']),width=Mm(180))
    q=doc.add_paragraph(p['caption']);q.paragraph_format.space_after=Pt(0)
    for r in q.runs:r.font.size=Pt(9)
doc.save(W/'supplement/Reader_SI.docx')

style=ParagraphStyle('body',fontName='Helvetica',fontSize=9.5,leading=12)
def para(text,width,role='body'):
    st=ParagraphStyle('p',parent=style,fontName='Helvetica-Bold' if role in ['title','h'] else 'Helvetica',fontSize=15 if role=='title' else 11 if role=='h' else 9.5,leading=18 if role=='title' else 12)
    p=Paragraph(text.replace('&','&amp;').replace('\n','<br/>'),st);_,h=p.wrap(width,10000);return p,h
def textpage(content,n):
    b=io.BytesIO();c=canvas.Canvas(b,pagesize=(210*mm,297*mm));y=285*mm
    for role,text in content:
        p,h=para(text,180*mm,role);assert y-h>12*mm,('front-page overflow',n,y,h);p.drawOn(c,15*mm,y-h);y-=h+(7 if role!='body' else 4)
    c.setFont('Helvetica',9);c.drawCentredString(105*mm,5*mm,str(n));c.save();return PdfReader(b).pages[0]
def figurepage(parts,title,page_num=None,long=False):
    info=[]
    for p in parts:
        page=PdfReader(W/p['pdf']).pages[0];scale=180*mm/float(page.mediabox.width);h=float(page.mediabox.height)*scale
        cap,ch=para(p['caption'],180*mm);info.append((page,scale,h,cap,ch,p))
    width=(200 if long else 210)*mm;margin=(10 if long else 15)*mm
    total=27*mm+sum(h+ch+12 for page,scale,h,cap,ch,p in info)
    if not long:total=max(297*mm,total)
    b=io.BytesIO();c=canvas.Canvas(b,pagesize=(width,total));c.setFont('Helvetica-Bold',12);c.drawString(margin,total-12*mm,title)
    y=total-19*mm;positions=[]
    for page,scale,h,cap,ch,p in info:
        y-=h;positions.append((page,scale,y));cap.drawOn(c,margin,y-5-ch);y-=ch+12
    if page_num is not None:c.setFont('Helvetica',9);c.drawCentredString(width/2,5*mm,str(page_num))
    c.save();page0=PdfReader(b).pages[0]
    for page,scale,y in positions:page0.merge_transformed_page(page,Transformation().scale(scale).translate(margin,y))
    return page0
rd=PdfWriter()
for n,content in enumerate(payload['front_pages'],1):rd.add_page(textpage(content,n))
for n,p in enumerate(payload['plates'],4):rd.add_page(figurepage([p],'Supplementary Figure '+p['new_id'],n));p['reader_pdf_page']=n
with (W/'supplement/Reader_SI.pdf').open('wb') as f:rd.write(f)
combined=PdfWriter();target=S/'02_Supplementary_Figures_OneFilePerFigure'
for name,parts in groups.items():
    page=figurepage(parts,'Supplementary Figure '+name,long=True);wr=PdfWriter();wr.add_page(page)
    with (target/f'Supplementary_Figure_{name}_combined.pdf').open('wb') as f:wr.write(f)
    combined.add_page(page)
with (target/'Supplementary_Figures_S1-S8_combined.pdf').open('wb') as f:combined.write(f)

mapping=list(csv.DictReader((target/'panel_mapping.csv').open(encoding='utf-8-sig')))
for row in mapping:
    row['source_pdf']='05_Code_and_Reproducibility/current_visual_rebuild_source/supplement/closeout_plates/'+row['original_plate']+'.pdf'
with (target/'panel_mapping.csv').open('w',newline='',encoding='utf-8-sig') as f:wr=csv.DictWriter(f,fieldnames=mapping[0]);wr.writeheader();wr.writerows(mapping)
rows=list(csv.DictReader((V/'supplement/figure_map.csv').open(encoding='utf-8-sig')))
for row in rows:
    row['new_id']=refs(row['new_id']);row['file']=row['file'].replace('supplement/Reader_SI.pdf','01_Journal_Upload/04_Supplementary_Information/Reader_SI.pdf').replace('supplement/Supplementary_Tables.xlsx','01_Journal_Upload/05_Supplementary_Tables/Supplementary_Tables.xlsx').replace('appendices/','03_Companion_Appendices/')
    row['complete_original_page']='05_Code_and_Reproducibility/current_visual_rebuild_source/'+row['complete_original_page']
with (W/'supplement/figure_map.csv').open('w',newline='',encoding='utf-8-sig') as f:wr=csv.DictWriter(f,fieldnames=rows[0]);wr.writeheader();wr.writerows(rows)
shutil.copy2(W/'supplement/figure_map.csv',target/'original_44_page_disposition.csv')
for ext in ['pdf','docx']:shutil.copy2(W/f'supplement/Reader_SI.{ext}',S/f'01_Journal_Upload/04_Supplementary_Information/Reader_SI.{ext}')
(W/'review/supplement_closeout.json').write_text(json.dumps({'status':'PASS','reader_pdf_pages':len(rd.pages),'merged_figures':len(groups),'panel_mapping_rows':len(mapping),'chart_width_mm':180,'tag_changes':tag_ledger,'old_44_pages_mapped':len(rows),'captions':'each original plate appears once with its mapped panel span'},ensure_ascii=False,indent=2),encoding='utf-8')
print('SUPPLEMENT_CLOSEOUT_PASS',len(rd.pages),'reader pages;',len(groups),'merged figures')
