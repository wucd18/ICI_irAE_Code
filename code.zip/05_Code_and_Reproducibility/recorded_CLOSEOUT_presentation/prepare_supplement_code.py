"""Extract audited plotting-only fragments from the exact input archive."""
from pathlib import Path
import re
O=Path(__file__).resolve().parents[1];I=O/'input_snapshot'
(O/'supplement/plates').mkdir(exist_ok=True)
s=(I/'presentation_code/plot_supplement_final.R').read_text(encoding='utf-8-sig')
s=s[:s.index('# Every cohort-level')]
s=s.replace("O<-normalizePath(args[1],winslash='/')","O<-normalizePath(args[1],winslash='/');I<-file.path(O,'input_snapshot')")
s=s.replace('read.csv(file.path(O,p)','read.csv(file.path(I,p)').replace("list.files(file.path(O,'supplementary/tables')","list.files(file.path(I,'supplementary/tables')")
start=s.index('savep<-function');end=s.index('# Existing results only')
save="""savep<-function(p,id,h){
 ids<-c(Supplementary_Figure_1_complete_Hallmarks='S1',Supplementary_Figure_2_all_module_transfer='S2A',Supplementary_Figure_3_lung_sensitivity='S2B',Supplementary_Figure_5_paired_repertoires='S3',Supplementary_Figure_7_complete_core_effects='S4A',Supplementary_Figure_14_original_and_assay_context='S5C')
 if(!id%in%names(ids))return(invisible(NULL))
 if(id=='Supplementary_Figure_14_original_and_assay_context'){p<-p3;h<-115}
 b<-file.path(O,'supplement/plates',ids[[id]])
 ggsave(paste0(b,'.pdf'),p,width=180,height=h,units='mm',device=cairo_pdf,bg='white')
 ggsave(paste0(b,'.png'),p,width=180,height=h,units='mm',dpi=300,bg='white')
 message('Supplement plate ',ids[[id]])
}
flabs<-c('Absorptive','Immature','Mature absorptive','Secretory','GSE210037 sample pseudobulk')
theme_update(axis.text=element_text(size=7),legend.text=element_text(size=7))
"""
s=s[:start]+save+s[end:]
s=s.replace("element_text(size=6.6)","element_text(size=7)")
s=s.replace("compose(plotlist=parts,ncol=2,labs=c('a','b'))","plot_grid(plotlist=parts,ncol=2,labels=c('a','b'),label_size=10)")
s=s.replace("d<-tidyr::complete(d,module_label,label);", "d$label<-gsub('Platform samples','GSE210037 sample pseudobulk',d$label,fixed=TRUE);d<-tidyr::complete(d,module_label,label);")
s+="\ncat('SUPPLEMENT_READER_PLOTS_PASS\\n')\n"
(O/'presentation_code/plot_supplement_final.R').write_text(s,encoding='utf-8')
s=(I/'presentation_code/plot_organoid_supplement.R').read_text(encoding='utf-8-sig')
s=s.replace("E<-file.path(O,'organoid_donor_extension')","E<-file.path(O,'input_snapshot/organoid_donor_extension')")
start=s.index('savep<-function');end=s.index('lim<-max',start)
s=s[:start]+"""savep<-function(p,id,h){
 ids<-c(Supplementary_Figure_15A_complete_donor_GSEA='S5A',Supplementary_Figure_15B_complete_donor_points='S5B',Supplementary_Figure_16_complete_core_donor_models='S4B')
 if(!id%in%names(ids))return(invisible(NULL))
 b<-file.path(O,'supplement/plates',ids[[id]])
 ggsave(paste0(b,'.pdf'),p,width=180,height=h*25.4,units='mm',device=cairo_pdf,bg='white')
 ggsave(paste0(b,'.png'),p,width=180,height=h*25.4,units='mm',dpi=300,bg='white')
 dimensions[[length(dimensions)+1]]<<-data.frame(figure=ids[[id]],width_mm=180,height_mm=h*25.4)
 message('Supplement plate ',ids[[id]])
}
"""+s[end:]
s=s.replace("file.path(E,'source_data/all_donor_plot_coordinates.csv')","file.path(O,'source_data/display/S5B_all_donor_plot_coordinates.csv')")
s=s.replace('Supplementary Fig. 7','Supplementary Fig. S4A')
# All original rows and values remain. Footnotes keep the original qualifications.
(O/'presentation_code/plot_organoid_supplement.R').write_text(s,encoding='utf-8')
print('Prepared two audited plotting-only scripts; no statistical entry sourced')
