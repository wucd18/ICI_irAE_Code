"""Seal the reviewed closeout copy; never modifies source archives or models."""
from closeout_common import W,S,V
from pathlib import Path
from datetime import datetime,timezone
from zipfile import ZipFile,ZIP_DEFLATED
import csv,json,hashlib,shutil,sys,io

def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(4*1024*1024),b''):h.update(chunk)
    return h.hexdigest()

def include(path):
    """Exclude only current generated temp/cache files; preserve historical snapshots."""
    rel=path.relative_to(S)
    try:tail=path.relative_to(W).parts
    except ValueError:return True
    return not (tail and tail[0]=='temp' or tail[:2]==('presentation_code','__pycache__') or tail[:2]==('tests','__pycache__'))

def writecsv(path,rows):
    with path.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)

def main(outdir):
    started=datetime.now(timezone.utc).isoformat()
    status=json.loads((S/'DELIVERY_STATUS.json').read_text(encoding='utf-8'))
    assert all(status[k]=='PASS' for k in ['science_scope','numerical_fidelity','production_and_references','execution'])
    assert status['submission_information']=='USER_PENDING'
    audit=json.loads((W/'review/closeout_verification.json').read_text())
    assert all(r['status']=='PASS' for r in audit['checks']) and audit['changed_statistical_values']==0
    review=json.loads((W/'review/visual_review.json').read_text())
    renders=json.loads((W/'review/visual_render_manifest.json').read_text())
    assert review['status']=='PASS'
    assert {r['path'] for r in review['review_images']}=={Path(p).as_posix() for p in renders['review_images']}
    for r in review['review_images']:assert sha(W/r['path'])==r['sha256'],r['path']
    for r in review['reviewed_pdfs']:assert sha(S/r['path'])==r['sha256'],r['path']
    for r in review['main_figures']:assert sha(W/r['path'])==r['sha256'],r['path']
    for r in csv.DictReader((S/'05_Code_and_Reproducibility/CURRENT_CODE_INDEX.csv').open(encoding='utf-8-sig')):
        assert sha(S/r['path'])==r['sha256'],r['path']
    outdir=Path(outdir).resolve();assert outdir.is_dir() and not outdir.is_relative_to(S)
    stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    target=outdir/f'submission_candidate_CLOSEOUT_{stamp}.zip';assert not target.exists()
    manifest=S/'FILE_MANIFEST_SHA256.csv'
    historical=S/'06_Review_and_Codex/closeout/pre_closeout_FILE_MANIFEST_SHA256.csv'
    if manifest.exists() and not historical.exists():shutil.copy2(manifest,historical)
    files=sorted((p for p in S.rglob('*') if p.is_file() and p!=manifest and include(p)),key=lambda p:p.relative_to(S).as_posix())
    rows=[{'path':p.relative_to(S).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)} for p in files]
    writecsv(manifest,rows)
    with ZipFile(target,'x',ZIP_DEFLATED,compresslevel=6,allowZip64=True) as z:
        for p in files+[manifest]:z.write(p,p.relative_to(S).as_posix())
    # Re-open and verify every member's bytes, size and CRC from the sealed archive.
    with ZipFile(target) as z:
        entries=list(csv.DictReader(io.TextIOWrapper(z.open('FILE_MANIFEST_SHA256.csv'),encoding='utf-8-sig')))
        assert len(z.namelist())==len(entries)+1 and len(set(z.namelist()))==len(z.namelist())
        assert set(z.namelist())=={r['path'] for r in entries}|{'FILE_MANIFEST_SHA256.csv'}
        for r in entries:
            h=hashlib.sha256();size=0
            with z.open(r['path']) as f:
                for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b);size+=len(b)
            assert size==int(r['bytes']) and h.hexdigest()==r['sha256'],r['path']
        assert z.read('FILE_MANIFEST_SHA256.csv')==manifest.read_bytes()
    receipt={'status':'PASS','zip':str(target),'bytes':target.stat().st_size,'sha256':sha(target),'manifest_members_verified':len(rows),'zip_member_count':len(rows)+1,'crc':'PASS - every member read to EOF','exact_member_set':'PASS','start_utc':started,'end_utc':datetime.now(timezone.utc).isoformat(),'exit_code':0,'command':sys.argv,'packager_sha256':sha(Path(__file__)),'scope':'presentation closeout; no primary models executed'}
    target.with_suffix('.verification.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf-8')
    target.with_suffix('.sha256').write_text(receipt['sha256']+'  '+target.name+'\n',encoding='utf-8')
    print(json.dumps(receipt,ensure_ascii=False,indent=2))
if __name__=='__main__':
    assert len(sys.argv)==2,'Usage: package_closeout.py EXISTING_OUTPUT_DIRECTORY'
    main(sys.argv[1])

