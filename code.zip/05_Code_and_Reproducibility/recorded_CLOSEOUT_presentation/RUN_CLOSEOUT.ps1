param([ValidateSet('All','Finalize','Verify')][string]$Stage='All')
$ErrorActionPreference='Stop'
$workRoot=$PSScriptRoot
$py='C:/Users/frede/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
$node='C:/Users/frede/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe'
$r='D:/Software/Bioinformatics/R/R-4.4.1/bin/x64/Rscript.exe'
$pwsh='C:/Users/frede/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe'
$launcher=Join-Path $workRoot 'presentation_code/run_step.py'
function Invoke-Step([string[]]$Command){
 & $py $launcher @Command
 if($LASTEXITCODE-ne 0){throw ('Closeout step failed: '+($Command-join ' '))}
}
if($Stage-eq 'All'){
 Invoke-Step @($py,'-X','utf8',(Join-Path $workRoot 'presentation_code/prepare_visual.py'))
 Invoke-Step @($py,'-X','utf8','-m','unittest','discover','-s',(Join-Path $workRoot 'tests'),'-p','test_closeout.py','-v')
 foreach($script in @('plot_final.R','plot_organoid_supplement.R','audit_fidelity.R')){Invoke-Step @($r,'--vanilla',(Join-Path $workRoot ('presentation_code/'+$script)),$workRoot)}
 foreach($script in @('closeout_manuscript.py','closeout_supplement.py','build_manuscript.py')){Invoke-Step @($py,'-X','utf8',(Join-Path $workRoot ('presentation_code/'+$script)))}
 Invoke-Step @($node,(Join-Path $workRoot 'presentation_code/closeout_workbook.mjs'),'edit')
 Invoke-Step @($pwsh,'-NoProfile','-File',(Join-Path $workRoot 'presentation_code/render_closeout_word.ps1'))
 Invoke-Step @($py,'-X','utf8',(Join-Path $workRoot 'presentation_code/render_closeout_pdfs.py'))
}
if($Stage-ne 'Verify'){Invoke-Step @($py,'-X','utf8',(Join-Path $workRoot 'presentation_code/closeout_assemble.py'))}
Invoke-Step @($py,'-X','utf8',(Join-Path $workRoot 'presentation_code/verify_closeout.py'))
Write-Output ('CLOSEOUT_ENTRY_PASS '+$Stage+'; review regenerated pages before a new release')
