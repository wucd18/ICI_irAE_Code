from pathlib import Path
import json,sys,hashlib
import pypdfium2 as pdfium
O=Path(__file__).resolve().parents[1]
files=[]
if len(sys.argv)>1:files=[O/a for a in sys.argv[1:]]
else:
 files=list((O/'review/render').glob('*/*.pdf'))+list((O/'supplement').glob('Reader_SI.pdf'))+list((O/'appendices').glob('*.pdf'))+list((O/'figures').glob('*.pdf'))
records=[]
for p in files:
 out=O/'review/page_images'/('WORD_'+p.stem if 'review' in p.relative_to(O).parts else p.stem)
 out.mkdir(parents=True,exist_ok=True);doc=pdfium.PdfDocument(str(p))
 digest=hashlib.sha256(p.read_bytes()).hexdigest()
 for i in range(len(doc)):
  dest=out/f'page-{i+1:02}.png';doc[i].render(scale=1.5).to_pil().save(dest)
  records.append({'pdf':str(p.relative_to(O)),'page':i+1,'pdf_sha256':digest,'image':str(dest.relative_to(O))})
 doc.close();print(p.name,len([r for r in records if r['pdf']==str(p.relative_to(O))]),flush=True)
path=O/'review/render_manifest.json'
old=json.loads(path.read_text()) if path.exists() else []
now={r['pdf'] for r in records};old=[r for r in old if r['pdf'] not in now]
path.write_text(json.dumps(old+records,indent=2),encoding='utf-8')
