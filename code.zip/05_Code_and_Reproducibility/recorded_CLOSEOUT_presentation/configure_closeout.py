"""One-time minimal source patching against the verified VISUAL_FINAL baseline."""
from pathlib import Path
import shutil,json,hashlib
W=Path(__file__).resolve().parents[1];S=W.parents[1];B=S.parent/'baseline_visual';V=W/'visual_input_snapshot'
extra=['organoid_donor_extension/results/20260914T062958/module_GSEA.csv','organoid_donor_extension/results/20260914T062958/model_inventory.csv','organoid_donor_extension/results/20260914T062958/donor_module_scores.csv','organoid_donor_extension/source_data/pseudobulk_metadata.csv','organoid_donor_extension/source_data/frozen_core_donor_gene_effects.csv','organoid_donor_extension/review/analysis_complete.json','organoid_donor_extension/review/analysis_plan_locked.json']
manifest=json.loads((V/'selected_input_manifest.json').read_text(encoding='utf-8'))
for rel in extra:
 src=B/'input_snapshot'/rel;dst=V/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
 manifest.append(dict(path=rel,baseline_member='input_snapshot/'+rel,bytes=dst.stat().st_size,sha256=hashlib.sha256(dst.read_bytes()).hexdigest(),source='submission_candidate_VISUAL_FINAL_20260914T045831Z.zip',role='existing donor-result input; never recomputed'))
(V/'selected_input_manifest.json').write_text(json.dumps(list({r['path']:r for r in manifest}.values()),indent=2),encoding='utf-8')
ledger=[]
def patch(file,old,new):
 p=W/'presentation_code'/file;s=p.read_text(encoding='utf-8')
 if s.count(old)==0:
  assert s.count(new)==1,(file,old,'neither exact old nor new text found')
 else:
  assert s.count(old)==1,(file,old,s.count(old));p.write_text(s.replace(old,new),encoding='utf-8')
 ledger.append(dict(file=file,old=old,new=new))
patch('plot_final.R',"I<-file.path(O,'input_snapshot')","I<-file.path(O,'visual_input_snapshot')")
patch('plot_final.R',"fp<-function(p)rd(paste0('source_data/final_panels/',p,'.csv'))","fp<-function(p)read.csv(file.path(O,'source_data/final_panels',paste0(p,'.csv')),check.names=FALSE,na.strings=c('NA',''),stringsAsFactors=FALSE)")
patch('plot_final.R',"tab<-function(n) {p<-list.files(file.path(I,'supplementary/full_source_tables'),pattern=sprintf('^Source_%03d_',n));stopifnot(length(p)==1);rd(paste0('supplementary/full_source_tables/',p))}","tab<-function(n) {p<-list.files(file.path(I,'supplement/full_source_tables'),pattern=sprintf('^Source_%03d_',n));stopifnot(length(p)==1);rd(paste0('supplement/full_source_tables/',p))}")
patch('plot_final.R',"position='top',expand=expansion(add=.5)","position='bottom',expand=expansion(add=.5)")
patch('plot_final.R',"paste0(sz[[modids[3]]],' residual')","paste0(sz[[modids[3]]],' residual (',sprintf('%.2f',100*sz[[modids[3]]]/sz[[modids[2]]]),'%)')")
patch('plot_final.R',"coord_cartesian(xlim=c(0,sz[[modids[2]]]*1.5),ylim=c(-.3,1.8),clip='off')+theme_void()+theme(plot.margin=margin(8,12,4,30))","coord_cartesian(xlim=c(0,sz[[modids[2]]]*1.5),ylim=c(-.3,1.8),clip='off')+labs(title='Definition of the IFN-gene-excluded set')+theme_void()+theme(plot.title=element_text(size=8.5,face='bold'),plot.margin=margin(8,12,4,30))")
patch('plot_final.R',"labs(title='Depth-controlled sensitivity',subtitle='Each effect retains its own metric units',x='Median difference\\n(ICI colitis - healthy)',y=NULL)","geom_text(aes(x=0,label=paste0('Median difference = ',sprintf('%.5f',median_difference))),vjust=2,hjust=0,size=2.5)+labs(title='Depth-controlled sensitivity',subtitle='Each effect retains its own metric units',x='Median difference\\n(ICI colitis - healthy)',y=NULL)")
patch('plot_organoid_supplement.R',"E<-file.path(O,'input_snapshot/organoid_donor_extension')","E<-file.path(O,'visual_input_snapshot/organoid_donor_extension')")
patch('plot_organoid_supplement.R',"labels=c('a','b')","labels=c('c','d')")
patch('plot_organoid_supplement.R','Supplementary Fig. S4A.','Supplementary Fig. S4a-b.')
patch('build_manuscript.py',"template=O/'input_snapshot/manuscript/manuscript_TARGETED_FINAL_CLEAN.docx'","template=O/'visual_input_snapshot/manuscript/manuscript_VISUAL_FINAL_CLEAN.docx'")
patch('audit_fidelity.R',"I<-file.path(O,'input_snapshot')","I<-file.path(O,'visual_input_snapshot')")
(W/'review/closeout_code_patch_ledger.json').write_text(json.dumps(ledger,indent=2),encoding='utf-8')
print('CONFIGURE_CLOSEOUT_PASS',len(ledger),'local source patches')
