"""Seal a unique candidate ZIP and verify every member; never runs analysis."""
from pathlib import Path
from datetime import datetime, timezone
import csv, io, json, hashlib, zipfile, sys, traceback
O=Path(__file__).resolve().parents[1]
MANIFEST='artifact_manifest_SHA256.csv'
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
    return h.hexdigest()
def require_new_destination(destination,root):
    destination=Path(destination).resolve();root=Path(root).resolve()
    if destination.exists():raise FileExistsError('Candidate ZIP already exists; choose a unique new path')
    if destination==root or root in destination.parents:raise ValueError('ZIP must be outside the package directory')
    if not destination.parent.is_dir():raise FileNotFoundError('ZIP parent does not exist')
    return destination
def verify_archive(path):
    with zipfile.ZipFile(path) as z:
        names=z.namelist()
        if len(names)!=len(set(names)):raise ValueError('Duplicate ZIP member')
        records=list(csv.DictReader(io.StringIO(z.read(MANIFEST).decode('utf-8-sig'))))
        keys=[r['path'] for r in records]
        if len(keys)!=len(set(keys)):raise ValueError('Duplicate manifest path')
        if set(names)!=set(keys)|{MANIFEST}:raise ValueError('ZIP and manifest membership differ')
        for r in records:
            h=hashlib.sha256();n=0
            with z.open(r['path']) as f:
                for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b);n+=len(b)
            if n!=int(r['bytes']) or h.hexdigest()!=r['sha256']:raise ValueError('Member integrity failure: '+r['path'])
        return {'status':'PASS','verified_file_count':len(records),'zip_member_count':len(names),
                'zip_crc':'All members fully read; CRC checked by ZipFile',
                'manifest_sha256':hashlib.sha256(z.read(MANIFEST)).hexdigest()}
def seal(destination):
    destination=require_new_destination(destination,O)
    if (O/MANIFEST).exists():raise FileExistsError('This directory is already sealed; do not overwrite its manifest')
    final=json.loads((O/'review/final_verification.json').read_text(encoding='utf-8'))
    if final['presentation_overall']!='PASS':raise ValueError('Final presentation verification did not pass')
    started=datetime.now(timezone.utc).isoformat()
    command={'command':[sys.executable,*sys.argv],'start_utc':started,'script_sha256':sha(Path(__file__)),
             'input':'review/final_verification.json','input_sha256':sha(O/'review/final_verification.json'),
             'completion_record':'Adjacent ZIP .execution.json and .verification.json; kept outside to avoid a circular hash manifest'}
    (O/'review/package_command.json').write_text(json.dumps(command,indent=2),encoding='utf-8')
    files=[]
    for p in sorted(O.rglob('*')):
        if not p.is_file():continue
        r=p.relative_to(O)
        # Preserve input_snapshot in full, including any originally supplied auxiliary files.
        if r.parts[0]=='temp' or (r.parts[0] in ['presentation_code','tests'] and '__pycache__' in r.parts):continue
        if r.as_posix()==MANIFEST:continue
        files.append(p)
    records=[dict(path=p.relative_to(O).as_posix(),bytes=p.stat().st_size,sha256=sha(p)) for p in files]
    with (O/MANIFEST).open('x',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=['path','bytes','sha256']);w.writeheader();w.writerows(records)
    print('Sealing',len(records),'files',flush=True)
    try:
        with zipfile.ZipFile(destination,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6,allowZip64=True) as z:
            for i,(p,r) in enumerate(zip(files,records)):
                z.write(p,r['path'])
                if i%400==0:print('Archived',i+1,'/',len(records),flush=True)
            z.write(O/MANIFEST,MANIFEST)
        report=verify_archive(destination)
        # Confirm the published bytes still match the working candidate after archiving.
        for p,r in zip(files,records):
            if p.stat().st_size!=r['bytes'] or sha(p)!=r['sha256']:raise ValueError('Working file changed during sealing: '+r['path'])
        report.update(overall='PASS',zip_path=str(destination),zip_bytes=destination.stat().st_size,
                      zip_sha256=sha(destination),end_utc=datetime.now(timezone.utc).isoformat(),
                      presentation_gate=final['presentation_overall'],submission_metadata='USER_PENDING',
                      manifest_exclusions=['runtime temp directory','new Python bytecode caches','the manifest itself is verified by this external record'])
        destination.with_suffix('.verification.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
        destination.with_suffix('.sha256').write_text(report['zip_sha256']+'  '+destination.name+'\n',encoding='ascii')
        command.update(end_utc=report['end_utc'],exit_code=0,zip_sha256=report['zip_sha256'])
        destination.with_suffix('.execution.json').write_text(json.dumps(command,indent=2),encoding='utf-8')
        print(json.dumps(report,indent=2),flush=True)
    except Exception:
        command.update(end_utc=datetime.now(timezone.utc).isoformat(),exit_code=1,error=traceback.format_exc())
        destination.with_suffix('.execution.json').write_text(json.dumps(command,indent=2),encoding='utf-8')
        raise
if __name__=='__main__':
    if len(sys.argv)!=2:raise SystemExit('Usage: package_candidate.py NEW_ZIP_PATH')
    seal(sys.argv[1])
