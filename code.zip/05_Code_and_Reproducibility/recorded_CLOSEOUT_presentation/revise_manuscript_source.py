"""Create the canonical revision from the explicitly authorized clean baseline."""
from pathlib import Path
import json,re
from docx import Document
O=Path(__file__).resolve().parents[1]
p=json.loads((O/'review/baseline_paragraphs.json').read_text(encoding='utf-8'))
original=p.copy();ledger=[]
def replace(i,old,new):
 assert p[i].count(old)==1,(i,old)
 p[i]=p[i].replace(old,new)
def setp(i,anchor,text):
 assert anchor in p[i],(i,anchor)
 p[i]=text
# Figure and appendix citations use one explicit map, never sequential number substitutions.
mapping={
 'Supplementary Figure 14a,b,d':'Appendix A, plates A3-A4',
 'Supplementary Figs. 4, 14e and 15':'Supplementary Fig. S5; Appendix A, plates A1 and A4',
 'Supplementary Figures 7 and 16':'Supplementary Fig. S4',
 'Supplementary Figure 14f':'Appendix A, plate A4',
 'Supplementary Fig. 14':'Appendix A, plate A3',
 'Supplementary Figs. 14':'Appendix A, plate A3',
 'Supplementary Fig. 9A-F':'Spatial Atlas Appendix B, plates B1-B6',
 'Supplementary Figs. 11-12':'Supplementary Fig. S7C and Spatial Atlas Appendix B, plates B7-B9',
 'Supplementary Fig. 13':'Supplementary Fig. S6',
 'Supplementary Figure 17':'Supplementary Fig. S8 and Appendix C',
 'Supplementary Fig. 10':'Supplementary Fig. S7B',
 'Supplementary Fig. 8':'Supplementary Fig. S7A',
 'Supplementary Fig. 5':'Supplementary Fig. S3',
}
for i,text in enumerate(p):
 for a,b in mapping.items():text=text.replace(a,b)
 p[i]=text
replace(28,'Registered coordinate maps show within-section distributions','Complete registered coordinate maps show within-section distributions')
replace(36,'All original signature features, cohort-specific estimates, endpoints and sensitivity results are retained in Supplementary Fig. S8 and Appendix C and the complete source tables.','All original signature meta-estimates are retained in Supplementary Fig. S8; cohort-specific estimates, endpoints and sensitivity results are provided in Appendix C and the complete source tables.')
replace(37,'The earlier perturbation-signature estimate is retained as a separate feature in Supplementary Fig. S8 and Appendix C.','The earlier perturbation-signature estimate is retained as a separate feature in Supplementary Fig. S8, with full cohort estimates in Appendix C.')
replace(39,'They add cellular localization, not an independent efficacy or causal test.','They provide descriptive cellular context, not an independent efficacy or causal test. Complete tissue maps are provided in Spatial Atlas Appendix B.')
replace(71,'with correction across 16 prespecified TCR-module combinations.','with correction across 16 prespecified TCR-module combinations. For Fig. 6b only, an ordinary least-squares line and pointwise 95% confidence band for the conditional mean are displayed for these same nine patients, without exclusions or additional inferential claims. This descriptive band is neither a Spearman confidence interval nor an individual-response prediction interval.')
replace(83,'RUN_PRESENTATION_ONLY.ps1 specifies the revision execution order.','RUN_VISUAL_FINAL.ps1 specifies the presentation-only revision execution order.')
replace(83,'the present final revision only reads those completed results.','the present final revision reads those completed results and adds only the explicitly descriptive OLS display in Fig. 6b.')
replace(87,'RUN_PRESENTATION_ONLY.ps1','RUN_VISUAL_FINAL.ps1')
replace(87,'The entry reads completed results and does not invoke model fitting.','The entry reads completed results and computes only the descriptive nine-patient OLS display in Fig. 6b; primary statistical models are not rerun.')
replace(85,'The package provides the acquisition hash, every retained cell-to-pseudobulk key, paired count matrices, complete fitted gene tables and explicit exclusions.','The package provides the acquisition hash, every retained cell-to-pseudobulk key, paired count matrices, complete fitted gene tables and explicit exclusions. The reader supplement, twelve-sheet Supplementary_Tables.xlsx workbook, full Source_001-Source_079 CSV files and Appendices A-C accompany the candidate manuscript. Appendix A preserves prior-export analyses and selection history; Appendix B contains the complete Oxford and Xenium tissue maps with source-coordinate links; Appendix C preserves all cohort-specific clinical estimates. Public repository identifiers remain to be supplied by the authors.')
setp(130,'a, Patient-level tissue discovery',
 'a, Schematic vector icons link patient-level heart and colon discovery, frozen-programme transfer, paired human-organoid counts and observational tumour-cohort assessment. Icons and workflow arrows are illustrative and do not represent experimental images or proven causal steps; TCR and source-confounded lung analyses are supporting branches. b, Case and control counts from the actual core models are encoded by paired lollipops: the heart compartments have 10/8, 10/6 and 10/8 eligible patients; the three colon compartments each have 9/3; the four GSE206300 families each have 8/5; and the GSE210037 sample-pseudobulk comparison has 7/8. Related compartments do not represent additional independent cohorts. c, Three paired donors and the estimability of the targeted models: 25 of 32 planned condition-by-family models and 100 of 128 set comparisons. The pale remainder represents unavailable estimates, not negative results. Counts refer to different analysis layers and must not be summed as independent participants. Additional spatial quantitative context is shown in Supplementary Fig. S7; complete maps are in Spatial Atlas Appendix B.')
replace(132,'Asterisks denote the original compartment-level FDR < 0.05; missing values are distinct from small effects.','White gaps separate organs and the original descriptive pathway groups. Asterisks denote the original compartment-level FDR < 0.05; missing values are distinct from small effects.')
replace(132,'with the original Spearman estimate and P value.','on axes with identical limits and unit lengths, with the original Spearman estimate and P value.')
replace(132,'c, Raw module NES values in BALF immune populations.','c, Raw module NES values for CIP versus externally sourced healthy BALF in four immune populations. Offsets occur only along the programme-category axis. Filled points meet the original FDR < 0.05 criterion and open points do not.')
replace(134,'a, Direction-oriented NES across','a, Fixed-size enrichment dots coloured by direction-oriented NES across')
replace(134,'Markers denote concordant results passing the original FDR criterion.','Asterisks denote concordant results passing the original FDR criterion; all twenty results are retained on one colour scale.')
replace(134,'c, Fixed set sizes and membership relations computed from the original member table.','c, The disease-up set is partitioned into the 80 retained residual members and four IFN-overlap members, CD47, IFITM3, LAP3 and STAT3, accounting for all 84 original members. The independent reference sizes are 224 IFN-set and 275 disease-depleted-set members; no unmeasured disjointness between these sets is implied.')
platform='Whole-tissue sample-pseudobulk comparison; 7 ICI-colitis and 8 healthy-colon samples. Individual spots were not treated as biological replicates.'
p[134]+=' '+platform
replace(136,'a, Raw NES values','a, Faceted lollipops show raw NES values')
replace(136,'b, Observed treatment-minus-control mean expression-rank changes','b, Zero-to-point lines show observed treatment-minus-matched-control mean expression-rank changes')
replace(136,'c, Original disease-tissue enrichment','c, Original un-reversed disease NES values with source FDR < 0.05 asterisks show disease-tissue enrichment')
replace(136,'Discovery self-checks are reported separately.','White space separates four GSE206300 families from the GSE210037 sample-pseudobulk comparison. All fifteen results are retained, including the discordant, nonsignificant 75-up result in GSE210037. Discovery self-checks are in Appendix A, plate A4.')
p[136]+=' '+platform
replace(138,'All other feature classes and cohort-specific estimates remain available in Supplementary Fig. S8 and Appendix C and source tables.','All other feature classes remain available in Supplementary Fig. S8, and complete cohort-specific estimates are in Appendix C and source tables.')
replace(138,'a,b, Original response','a,b, Aligned forests retain all eight direct-gene and seven axis features, grouped in the same order. Original response')
replace(138,'c, SORL1 gene-specific log2 fold changes and FDR values','c, Source-coloured zero-to-point lines show all nine SORL1 gene-specific log2 fold changes; the separately aligned text column reports gene-level FDR values')
replace(138,'the separate GSE210037 platform contrast','the separate GSE210037 sample-pseudobulk contrast')
p[138]+=' '+platform
replace(140,'c, Original depth-controlled sensitivity metrics, on explicitly labelled scales. No confidence intervals or fitted trends were generated solely for display.',
 'The blue points and patient labels identify the same nine ICI-colitis patients. The grey line is a descriptive ordinary least-squares fit; the pale grey band is its pointwise 95% conditional-mean confidence band. The fit uses all nine patients without exclusions and does not replace the original Spearman rho, P value or FDR; the band is not a Spearman interval or independent validation. c, Gold segments connect zero to the original median differences for the two depth-controlled metrics. Each effect retains its own original metric units; the segments are not confidence intervals. Original P values and FDR are displayed separately for each metric.')
# Use source blocks as the single authoring authority. Preserve blank paragraphs and styles in the template.
for i,(a,b) in enumerate(zip(original,p)):
 if a!=b:ledger.append({'paragraph_index':i,'old':a,'new':b,'reason':'Approved figure redesign, supplementary mapping, or explicit display-model explanation'})
doc=Document(O/'input_snapshot/manuscript/manuscript_TARGETED_FINAL_CLEAN.docx')
text='\n\n'.join(f'<!-- paragraph:{i} -->\n{s}' for i,s in enumerate(p))
for j,t in enumerate(doc.tables):
 text+='\n\n'+f'<!-- preserved-table:{j} -->\n'+'\n'.join('| '+' | '.join(c.text.replace('\n','<br>') for c in r.cells)+' |' for r in t.rows)
(O/'manuscript/manuscript_source.md').write_text(text+'\n',encoding='utf-8')
(O/'review/manuscript_change_ledger.json').write_text(json.dumps(ledger,ensure_ascii=False,indent=2),encoding='utf-8')
print('Canonical source created;',len(ledger),'paragraphs changed')
