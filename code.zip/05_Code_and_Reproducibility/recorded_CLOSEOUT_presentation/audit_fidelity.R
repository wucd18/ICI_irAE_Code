#!/usr/bin/env Rscript
# Read-only geometry audit. No statistical fitting or inference.
args<-commandArgs(TRUE);stopifnot(length(args)==1)
O<-normalizePath(args[1],winslash='/');I<-file.path(O,'visual_input_snapshot')
source(file.path(O,'presentation_code/theme_final.R'))
source(file.path(O,'presentation_code/csv_io.R'))
rd<-function(p)read.csv(p,check.names=FALSE,stringsAsFactors=FALSE,na.strings=c('NA',''))
checks<-list();add<-function(panel,field,n,delta=0){stopifnot(is.finite(delta),delta<1e-12);checks[[length(checks)+1]]<<-data.frame(panel,field,objects=n,max_abs_difference=delta,status='PASS')}
for(id in c('F2A','F2B','F2C','F3A','F3B','F4A','F4B','F4C','F5A','F5B','F5C','F6A','F6B','F6C')){
 src<-rd(file.path(I,'source_data/final_panels',paste0(id,'.csv')))
 obj<-file.path(O,'review/plot_build',paste0(id,'_plot.rds'))
 if(file.exists(obj)){p<-readRDS(obj);b<-ggplot_build(p)}else{b<-readRDS(file.path(O,'review/plot_build',paste0(id,'.rds')));p<-b$plot}
 d<-p$data;stopifnot(!anyDuplicated(src$final_record_key),!anyDuplicated(d$final_record_key),setequal(src$final_record_key,d$final_record_key))
 d<-d[match(src$final_record_key,d$final_record_key),,drop=FALSE]
 for(k in names(src)){
  stopifnot(k%in%names(d));a<-src[[k]];z<-d[[k]]
  if(id=='F4C'&&k=='signature'){
   stopifnot(identical(as.character(z),src$pathway));add(id,'signature_display_uses_unchanged_pathway_key',length(a));next
  }
  if(is.numeric(a)){
   stopifnot(identical(is.na(a),is.na(z)));delta<-if(all(is.na(a)))0 else max(abs(a-z),na.rm=TRUE)
   add(id,k,length(a),delta)
  }else{a<-as.character(a);z<-as.character(z);a[is.na(a)]<-'';z[is.na(z)]<-'';if(!identical(a,z))stop(paste(id,k,paste(head(a[a!=z]),collapse=' | '),paste(head(z[a!=z]),collapse=' | ')));add(id,k,length(a))}
 }
 if(id%in%c('F2A','F3A','F4C')){
  val<-if(id=='F3A')'oriented_NES' else 'NES';layer<-b$data[[1]]
  # Trained shared fill scale must map the retained numerical values exactly.
  expected<-b$plot$scales$get_scales('fill')$map(p$data[[val]])
  stopifnot(identical(toupper(layer$fill),toupper(expected)));add(id,'built_shared_colour_mapping',length(expected))
 }
 for(j in seq_along(b$data)){
  dat<-b$data[[j]];for(k in names(dat))if(is.list(dat[[k]]))dat[[k]]<-vapply(dat[[k]],function(x)as.character(jsonlite::toJSON(x,auto_unbox=TRUE)),character(1))
  write.csv(dat,file.path(O,'review/plot_build',paste0(id,'_layer_',j,'.csv')),row.names=FALSE)
 }
}
# Explicit coordinate pairs and confidence-interval endpoints, not only sorted x.
eq<-function(id,layer,fields){
 b<-readRDS(file.path(O,'review/plot_build',paste0(id,'.rds')));d<-b$plot$data;g<-b$data[[layer]]
 for(dest in names(fields)){
  wanted<-d[[fields[[dest]]]];if(id=='F5B'&&dest%in%c('x','xend'))wanted<-log10(wanted)
  # Facets reorder rows; compare paired records after stable ordering.
  add(id,paste0('geometry_',dest),length(wanted),max(abs(sort(g[[dest]])-sort(wanted))))
 }
}
eq('F2B',3,c(x='heart_median_NES',y='colon_median_NES'))
eq('F2C',2,c(x='NES',y='y'))
eq('F3B',2,c(x='bootstrap_auc_ci_low',xend='bootstrap_auc_ci_high'))
eq('F5A',2,c(x='ci_low',xend='ci_high'))
eq('F5B',2,c(x='ci_low_hr',xend='ci_high_hr'))
eq('F6B',3,c(x='cross_cd4_cd8_cell_fraction',y='ICI_COLITIS_EPITHELIAL_LOSS_STRICT'))
# The source's F2B medians are recomputed deterministically from existing NES rows.
raw<-rd(file.path(I,'source_data/panel_sources/SF1.csv'))
stopifnot(all(c('pathway','organ','NES')%in%names(raw)))
{
 med<-aggregate(NES~pathway+organ,raw,median);s<-rd(file.path(I,'source_data/final_panels/F2B.csv'))
 for(organ in c('heart','colon')){q<-med[med$organ==organ,];q<-q[match(s$pathway,q$pathway),];add('F2B',paste0(organ,'_median_from_full_NES'),nrow(s),max(abs(s[[paste0(organ,'_median_NES')]]-q$NES)))}
}
tc<-rd(file.path(I,'source_data/final_panels/F6B.csv'))
write.csv(data.frame(residual_df=nrow(tc)-2,confidence=.95,t_critical=qt(.975,nrow(tc)-2)),file.path(O,'review/F6B_distribution_reference.csv'),row.names=FALSE)
write.csv(do.call(rbind,checks),file.path(O,'review/panel_fidelity.csv'),row.names=FALSE)
cat('PANEL_FIDELITY_PASS',length(checks),'field and geometry checks\n')
