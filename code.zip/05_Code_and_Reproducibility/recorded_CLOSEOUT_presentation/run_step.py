"""Logged subprocess launcher; restores Windows variables in child processes only."""
from pathlib import Path
from datetime import datetime,timezone
import os,sys,subprocess,json,hashlib
O=Path(__file__).resolve().parents[1]
env=os.environ.copy()
env.update(SystemRoot='C:\\Windows',windir='C:\\Windows',ComSpec='C:\\Windows\\System32\\cmd.exe',SystemDrive='C:',APPDATA='C:\\Users\\frede\\AppData\\Roaming',LOCALAPPDATA='C:\\Users\\frede\\AppData\\Local',PROGRAMDATA='C:\\ProgramData',ALLUSERSPROFILE='C:\\ProgramData',OS='Windows_NT',PROCESSOR_ARCHITECTURE='AMD64',TEMP=str(O/'temp'),TMP=str(O/'temp'),TMPDIR=str(O/'temp'),R_USER=str(O/'temp'),LANG='C',LC_ALL='C')
cmd=sys.argv[1:];stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ');start=datetime.now(timezone.utc).isoformat()
p=subprocess.run(cmd,cwd=O,env=env,capture_output=True)
(O/'logs'/f'{stamp}.stdout.txt').write_bytes(p.stdout);(O/'logs'/f'{stamp}.stderr.txt').write_bytes(p.stderr)
rec={'command':cmd,'start_utc':start,'end_utc':datetime.now(timezone.utc).isoformat(),'exit_code':p.returncode,'stdout':f'{stamp}.stdout.txt','stderr':f'{stamp}.stderr.txt','inputs':'visual_input_snapshot/selected_input_manifest.json','outputs':'../../FILE_MANIFEST_SHA256.csv','software':'logs/presentation_R_sessionInfo.txt','command_files':[{'path':c,'sha256':hashlib.sha256(Path(c).read_bytes()).hexdigest()} for c in cmd if Path(c).is_file()]}
(O/'logs'/f'{stamp}.json').write_text(json.dumps(rec,indent=2),encoding='utf-8')
sys.stdout.reconfigure(encoding='utf-8');print(p.stdout.decode('utf-8',errors='replace'));print(p.stderr.decode('utf-8',errors='replace'));print('ACTUAL_EXIT_CODE',p.returncode);sys.exit(0 if p.returncode==0 else 1)
