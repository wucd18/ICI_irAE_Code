"""Preserve template runs and fields; generate a genuine red text review and clean peer."""
from pathlib import Path
from copy import deepcopy
import re,json,difflib
from docx import Document
from docx.shared import RGBColor
from docx.oxml.ns import qn
from docx.enum.text import WD_ALIGN_PARAGRAPH
O=Path(__file__).resolve().parents[1]
source=(O/'manuscript/manuscript_source.md').read_text(encoding='utf-8')
blocks={int(i):s.rstrip('\n') for i,s in re.findall(r'<!-- paragraph:(\d+) -->\n(.*?)(?=\n\n<!--|\Z)',source,re.S)}
template=O/'visual_input_snapshot/manuscript/manuscript_VISUAL_FINAL_CLEAN.docx'
def slice_runs(p,start,end):
 pos=0;out=[]
 for r in p.runs:
  n=len(r.text);lo=max(start,pos);hi=min(end,pos+n)
  if hi>lo:out.append((r.text[lo-pos:hi-pos],deepcopy(r._r.rPr)))
  pos+=n
 return out
def copy_equal(dst,src,start,end):
 # Preserve complete nested EndNote field blocks verbatim, including binary fldData.
 units=[];group=[];depth=0;pos=0
 for el in src._p:
  if el.tag==qn('w:pPr'):continue
  chars=list(el.iter(qn('w:fldChar')))
  before=depth
  for f in chars:
   if f.get(qn('w:fldCharType'))=='begin':depth+=1
   elif f.get(qn('w:fldCharType'))=='end':depth-=1
  if before or depth or group:
   group.append(el)
   if depth==0:
    text=''.join(t.text or '' for e in group for t in e.iter(qn('w:t')))
    units.append((pos,pos+len(text),group,True));pos+=len(text);group=[]
  else:
   text=''.join(t.text or '' for t in el.iter(qn('w:t')))
   units.append((pos,pos+len(text),[el],el.tag!=qn('w:r')));pos+=len(text)
 assert depth==0 and not group
 for lo,hi,elements,protected in units:
  if hi==lo:
   if start<=lo<end:
    for el in elements:dst._p.append(deepcopy(el))
   continue
  if hi<=start or lo>=end:continue
  if protected:
   assert lo>=start and hi<=end,('Cannot split citation field',lo,hi,start,end)
   for el in elements:dst._p.append(deepcopy(el))
  else:
   r=deepcopy(elements[0]);text=''.join(t.text or '' for t in r.iter(qn('w:t')))
   for child in list(r):
    if child.tag!=qn('w:rPr'):r.remove(child)
   from docx.oxml import OxmlElement
   t=OxmlElement('w:t');t.set(qn('xml:space'),'preserve');t.text=text[max(start-lo,0):min(end-lo,hi-lo)];r.append(t);dst._p.append(r)
def append(p,text,pr=None,red=False,strike=False):
 r=p.add_run(text)
 if pr is not None:r._r.insert(0,deepcopy(pr))
 if red:r.font.color.rgb=RGBColor.from_string('FF0000')
 if strike:r.font.strike=True
 return r
report=[]
for mode in ['RED','CLEAN']:
 doc=Document(template)
 for i,p in enumerate(doc.paragraphs):
  new=blocks[i];old=p.text
  if old==new:continue
  # No silent loss of fields, references, or hyperlinks in an edited paragraph.
  before=deepcopy(p);fallback=deepcopy(p.runs[0]._r.rPr) if p.runs else None
  a=re.findall(r'\s+|[\w]+|[^\w\s]',old);b=re.findall(r'\s+|[\w]+|[^\w\s]',new)
  aa=[0];bb=[0]
  for t in a:aa.append(aa[-1]+len(t))
  for t in b:bb.append(bb[-1]+len(t))
  for el in list(p._p):
   if el.tag!=qn('w:pPr'):p._p.remove(el)
  for op,i1,i2,j1,j2 in difflib.SequenceMatcher(a=a,b=b,autojunk=False).get_opcodes():
   if op=='equal':
    copy_equal(p,before,aa[i1],aa[i2])
   else:
    if mode=='RED' and op in ['delete','replace']:
     for text,pr in slice_runs(before,aa[i1],aa[i2]):append(p,text,pr,red=True,strike=True)
    if op in ['insert','replace']:
     # Inserted prose inherits nearby non-superscript character formatting.
     append(p,''.join(b[j1:j2]),fallback,red=mode=='RED')
  accepted=''.join(r.text for r in p.runs if not r.font.strike)
  assert accepted==new,(mode,i)
  assert len(before._p.xpath('.//w:fldChar'))==len(p._p.xpath('.//w:fldChar')),('Field loss',i)
  if i in [83,85,87]:p.alignment=WD_ALIGN_PARAGRAPH.LEFT
 path=O/'manuscript'/f'manuscript_CLOSEOUT_{mode}.docx';doc.save(path)
 report.append({'mode':mode,'paragraphs':len(doc.paragraphs),'changed_paragraphs':len(json.loads((O/'review/manuscript_change_ledger.json').read_text(encoding='utf-8'))),'red_runs':sum(r.font.color.rgb==RGBColor.from_string('FF0000') for p in doc.paragraphs for r in p.runs),'strike_runs':sum(bool(r.font.strike) for p in doc.paragraphs for r in p.runs)})
red=Document(O/'manuscript/manuscript_CLOSEOUT_RED.docx');clean=Document(O/'manuscript/manuscript_CLOSEOUT_CLEAN.docx')
assert [''.join(r.text for r in p.runs if not r.font.strike) for p in red.paragraphs]==[p.text for p in clean.paragraphs]
assert [[c.text for c in r.cells] for t in red.tables for r in t.rows]==[[c.text for c in r.cells] for t in clean.tables for r in t.rows]
(O/'review/red_clean_equivalence.json').write_text(json.dumps({'status':'PASS','review_format':'FF0000 additions/replacements and red strikeout deletions; not native Word tracking','accepted_red_equals_clean':True,'reports':report},indent=2),encoding='utf-8')
print('RED_CLEAN_EQUIVALENCE_PASS',report)
