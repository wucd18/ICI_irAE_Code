"""Record the assistant's completed manual review and verified pre-seal gates.

This is an explicit review attestation for the inspected render set, not an image
quality detector. Never run --record-reviewed-current-render-set on unseen pages.
"""
from pathlib import Path
from datetime import datetime,timezone
import sys,json,csv,re,hashlib,ast
from build_delivery_index import sha,readcsv,numbered_sources
O=Path(__file__).resolve().parents[1]
def load(p):return json.loads((O/p).read_text(encoding='utf-8-sig'))
def save(p,value):(O/p).write_text(json.dumps(value,indent=2,ensure_ascii=False),encoding='utf-8')
def main():
 if sys.argv[1:]!=['--record-reviewed-current-render-set']:raise SystemExit('An explicit completed-manual-review attestation is required')
 expected={
  'WORD_manuscript_VISUAL_FINAL_RED':25,'WORD_manuscript_VISUAL_FINAL_CLEAN':25,'WORD_Reader_SI':18,
  'Reader_SI':18,'Appendix_A_history':4,'Appendix_B_spatial_atlas':9,'Appendix_C_full_cohorts':7,
  'Figures_1_to_6':6,'WORD_baseline_vs_final_180mm':6,
  'Figure_1_study_design':1,'Figure_2_receiver_programmes':1,'Figure_3_frozen_module_transfer':1,
  'Figure_4_organoid_reciprocity':1,'Figure_5_tumour_guardrails':1,'Figure_6_TCR_support':1}
 records=load('review/render_manifest.json');observed={};pages=[];hashes={}
 for r in records:
  p=O/r['pdf'];im=O/r['image'];group=im.parent.name
  assert group in expected,('unreviewed group',group)
  observed.setdefault(group,[]).append(r['page'])
  if str(p) not in hashes:hashes[str(p)]=sha(p)
  assert hashes[str(p)]==r['pdf_sha256'],('stale rendering',str(p))
  assert im.is_file()
  pages.append(dict(**r,image_sha256=sha(im),manual_layout_status='PASS',review_method='Opened and visually inspected in the assistant image viewer'))
 assert set(observed)==set(expected)
 for g,n in expected.items():assert sorted(observed[g])==list(range(1,n+1)),g
 sheets=[]
 for i in range(1,13):
  p=O/'review/workbook_previews'/f'S{i}.png'
  assert p.is_file()
  sheets.append(dict(sheet=f'S{i}',image=str(p.relative_to(O)),sha256=sha(p),status='PASS',scope='Rendered first rows/columns checked visually; all data cells audited separately'))
 for kind in ['RED','CLEAN']:
  name=f'manuscript_VISUAL_FINAL_{kind}.pdf'
  assert sha(O/'manuscript'/name)==sha(O/'review/render'/name[:-4]/name)
 review=dict(overall='PASS',recorded_utc=datetime.now(timezone.utc).isoformat(),reviewer='Codex manual visual inspection',
  pdf_pages_reviewed=len(pages),workbook_sheet_previews_reviewed=len(sheets),pages=pages,sheets=sheets,
  limitations='Visual QA is human-like inspection, not proof of scientific validity. Author metadata remains USER_PENDING. Historical archived outputs were retained rather than all re-rendered.',
  resolved_layout_findings=[
   'F1C letter/title collision removed by separating the title and panel label.',
   'F2B shared-programme labels moved to the margin with leaders; clipping disabled without moving the data.',
   'F5A/B repeated GENE/AXIS y positions separated and kept in identical order.',
   'Clean manuscript code-availability paragraph corrected to RUN_VISUAL_FINAL and the explicit same-nine-patient display exception; both Word documents re-rendered and checked.'],
  main_figures='Six direct R vector PDFs and 600 dpi LZW TIFFs checked at nominal 180 mm. Side-by-side baseline comparison reviewed at 180 mm per figure.',
  tcr_reference='Task reference/first_version_TCR_style.R.txt inspected. Current values retained; blue points, grey mean fit, pale mean band and gold zero-to-effect segments restored.')
 save('review/visual_QA.json',review)
 # Parse Python without executing any imported pipeline, and inspect R source calls.
 parsed=[]
 for p in sorted((O/'presentation_code').glob('*.py'))+sorted((O/'tests').glob('*.py')):
  ast.parse(p.read_text(encoding='utf-8-sig'),filename=str(p));parsed.append(dict(path=str(p.relative_to(O)),sha256=sha(p)))
 rfiles=[];lm_count=0
 forbidden=r'\b(?:DESeq|DESeqDataSetFromMatrix|estimateDispersions|glmQLFit|fgsea|fgseaSimple|coxph|rma|boot|cor\.test|wilcox\.test|install\.packages|download\.file|system|system2)\s*\('
 for p in sorted((O/'presentation_code').glob('*.R')):
  text=p.read_text(encoding='utf-8-sig');assert not re.search(forbidden,text),p
  lm_count+=len(re.findall(r'(?<![A-Za-z_])lm\s*\(',text))
  calls=re.findall(r"source\(file.path\(O,'([^']+)'\)\)",text)
  assert all(c in ['presentation_code/theme_final.R','presentation_code/csv_io.R'] for c in calls)
  assert len(re.findall(r'\bsource\s*\(',text))==len(calls),(p,'unclassified source call')
  rfiles.append(dict(path=str(p.relative_to(O)),sha256=sha(p),source_calls=calls))
 assert lm_count==1
 entries=[]
 for p in sorted((O/'logs').glob('*.json')):
  r=json.loads(p.read_text(encoding='utf-8-sig'));r['log']=str(p.relative_to(O));entries.append(r)
 assert any(r['exit_code']==0 and any('static_parse.R' in c for c in r['command']) for r in entries)
 fixture=[r for r in entries if r['exit_code']==0 and 'unittest' in r['command']][-1]
 fixture_text=(O/'logs'/fixture['stderr']).read_text(encoding='utf-8-sig')
 fixture_count=int(re.search(r'Ran (\d+) tests',fixture_text).group(1));assert '\nOK' in fixture_text
 static=dict(overall='PASS',python_ast=parsed,R_source_audit=rfiles,allowed_display_lm_count=lm_count,
  R_parse='Executed Rscript --vanilla presentation_code/static_parse.R; see log inventory',
  fixture_tests=fixture_count,fixture_log=fixture['log'],
  entry_sha256=sha(O/'RUN_VISUAL_FINAL.ps1'),
  entry_scope='Only the independent presentation scripts and read-only audits are called. The original full-statistical entries are not invoked.')
 save('review/static_source_audit.json',static)
 resolutions={
  '20260914T042116863222Z':'CSV BOM caused a missing dataset field; UTF-8 BOM-aware CSV helper used and all source rows verified.',
  '20260914T042137111246Z':'ggplot build list columns could not be written directly to CSV; list columns are serialised and full RDS is also saved.',
  '20260914T042812101515Z':'Edited paragraph contained EndNote fields; unchanged complex XML fields are now copied intact and verified against the baseline.',
  '20260914T042902305520Z':'Generic lxml node did not carry the docx XPath namespace map; explicit qualified field lookup fixed it.',
  '20260914T042923516218Z':'The same XPath namespace issue persisted once; the final explicit qualified lookup passed field-preservation checks.',
  '20260914T042957964587Z':'Bundled renderer could not find LibreOffice; installed Microsoft Word COM rendered all three documents successfully without package installation.',
  '20260914T043143618322Z':'Node package resolution from E: failed; createRequire uses the already installed bundled artifact-tool absolute runtime path.',
  '20260914T043943984729Z':'Source audit surfaced the intentional F4C display label versus underlying pathway-key distinction; the next diagnostic identified it.',
  '20260914T044001937391Z':'F4C display labels are explicitly audited against original pathway keys; all original numeric and identity fields remain checked.',
  '20260914T044319595086Z':'SciPy was unavailable; the band check uses base R qt and the independent closed-form OLS mean-band expression; no package was installed.',
  '20260914T044406478461Z':'Cairo quantizes PDF media boxes to whole points; dimension audit now records requested and actual mm and permits one device point (0.353 mm), without changing statistical thresholds.',
  '20260914T045158501427Z':'Windows default GBK decoding failed on UTF-8 manuscript text; the index builder now specifies UTF-8.'}
 failures=[]
 for r in entries:
  if r['exit_code']==0:continue
  key=Path(r['log']).stem;assert key in resolutions,('unclassified failure',key)
  target=next((Path(c).name for c in r['command'] if c.endswith(('.py','.R','.mjs'))),'')
  if 'render_docx.py'==target:target='render_word.ps1'
  later=[x for x in entries if x['exit_code']==0 and x['start_utc']>r['start_utc'] and any(Path(c).name==target for c in x['command'])]
  assert later,('no successful replacement',key,target)
  failures.append(dict(log=r['log'],exit_code=r['exit_code'],classification='RESOLVED_PRESENTATION_FAILURE',reason_and_resolution=resolutions[key],successful_replacement=later[-1]['log']))
 save('review/failed_attempts_classification.json',dict(unclassified_failures=0,failures=failures))
 save('review/execution_inventory.json',entries)
 for r in readcsv(O/'source_data/figure_source_index.csv')+readcsv(O/'source_data/full_source_table_index.csv'):
  p=O/r['path'];assert p.is_file() and p.stat().st_size==int(r['bytes']) and sha(p)==r['sha256']
 packagejson=Path('C:/Users/frede/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/@oai/artifact-tool/package.json')
 environment=load('review/artifact_environment.json')
 environment['artifact_tool']=json.loads(packagejson.read_text(encoding='utf-8'))['version']
 environment['Node']='24.19.0; actual build logs';environment['Microsoft_Word']='16.0; native COM rendering logs'
 save('review/artifact_environment.json',environment)
 m=load('review/machine_verification.json');red=load('review/red_clean_equivalence.json');s=load('review/supplement_repack.json')
 assert m['overall']=='PASS' and red['accepted_red_equals_clean'] and s['all_pages_mapped']
 final=dict(presentation_overall='PASS',time_utc=datetime.now(timezone.utc).isoformat(),
  scope='Completed targeted presentation revision using the exact current baseline; no new primary statistical analysis',
  baseline_sha256=load('review/scope.json')['baseline_archive_sha256'],
  input_manifest='PASS: '+str(m['baseline_manifest_entries'])+' exact baseline entries',
  static_source_audit='PASS',fixture_tests=f'PASS: {fixture_count}',
  machine_checks=m['check_count'],panel_field_and_geometry_checks=len(readcsv(O/'review/panel_fidelity.csv')),
  primary_numeric_changes=m['primary_numeric_changes'],red_clean_equivalence='PASS',
  actual_render_review={'PDF_pages':len(pages),'workbook_previews':len(sheets),'status':'PASS'},
  supplement={'original_pages':s['original_pages'],'all_pages_mapped':True,'reader_pages':s['reader_pdf_pages'],
              'appendix_pages':{k:len(v) for k,v in s['appendices'].items()},'reader_table_sheets':len(load('review/workbook_verification.json')['sheets']),
              'full_numbered_source_csv':len(numbered_sources(O/'supplement/full_source_tables'))},
  unavailable_results='Preserved with original NA/NE semantics and source identities; no unavailable values replaced with zero or interpreted as negatives',
  original_formal_steps='Archived unchanged; deliberately not rerun by this presentation task',
  display_exception=m['new_display_only'],unclassified_mandatory_failures=0,
  ZIP_integrity='The seal command performs CRC, complete membership and SHA-256 checks; its final overall PASS is recorded adjacent to the ZIP.',
  submission_readiness='USER_PENDING author, affiliation, correspondence, funding, CRediT, interests, repository and DOI; no submission-ready claim')
 save('review/final_verification.json',final)
 print('FINAL_PRESENTATION_VERIFICATION_PASS',len(pages),'PDF pages manually inspected;',fixture_count,'fixture tests')
if __name__=='__main__':main()
