"""Repackage every source page with explicit destinations; preserve vector figure pages."""
from pathlib import Path
import json,re,csv,shutil,io,math
import pandas as pd
from pypdf import PdfReader,PdfWriter,Transformation
import pypdfium2 as pdfium
from reportlab.pdfgen import canvas
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import Paragraph
from reportlab.lib.enums import TA_LEFT
from docx import Document
from docx.shared import Mm,Pt,RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
O=Path(__file__).resolve().parents[1];I=O/'input_snapshot'
manifest=json.loads((I/'review/SI_figure_manifest.json').read_text(encoding='utf-8'))
payload=json.loads((I/'supplementary/supplement_text_payload.json').read_text(encoding='utf-8'))
defs=json.loads((I/'supplementary/reader_tables/table_definitions.json').read_text(encoding='utf-8'))
byname={m['figure']:m for m in manifest}
def item(prefix):
 m=[v for k,v in byname.items() if k.startswith('Supplementary_Figure_'+prefix+'_')]
 assert len(m)==1,(prefix,len(m));return m[0]
def src(m,ext='pdf'):return I/Path(m['source_'+ext].replace('\\','/'))
def renum(s):
 # Longest specific strings first; substitutions are performed once against old text.
 mp={'1':'S1','2':'S2A','3':'S2B','4':'Appendix A1','5':'S3','6':'Appendix A2','7':'S4A','8':'S7A','9':'Appendix B1-B6','10':'S7B','11':'S7C','12':'Appendix B7-B9','13':'S6','14':'Appendix A3-A4','15':'S5','16':'S4B','17':'S8 and Appendix C'}
 s=re.sub(r'Supplementary Fig(?:ure)?s?\.?\s+(\d+)',lambda m:'Supplementary Fig. '+mp[m[1]],s)
 return s.replace('Platform samples','GSE210037 sample pseudobulk').replace('platform contrast','GSE210037 sample-pseudobulk contrast')
def clean_caption(s):
 s=re.sub(r'^Supplementary Figure\s+\d+\.\s*','',s)
 s=renum(s)
 return s.replace('Cohort-level estimates follow in plates B1–B4 and C5–C7.','Complete cohort-level estimates are provided in Appendix C, plates C1-C7.')
sequence=[('S1','1'),('S2A','2'),('S2B','3'),('S3','5'),('S4A','7'),('S4B','16'),('S5A','15A'),('S5B','15B'),('S5C','14'),('S6A','13A'),('S6B','13B'),('S7A','8'),('S7B','10'),('S7C','11'),('S8','17A')]
plates=[]
for new,old in sequence:
 m=item(old);pdf=O/'supplement/plates'/f'{new}.pdf'
 if not pdf.exists():shutil.copy2(src(m),pdf)
 caption=clean_caption(m['caption'])
 if new=='S5C':caption='No-cytomix assay reference. Donor-adjusted no-cytomix versus matched cytomix-control NES for all fixed programmes and epithelial families. Asterisks indicate the separate reference-family FDR < 0.05; NE denotes unavailable estimates. The reference is not a newly screened candidate. The original published-export module and IBD1/IBD2/GP20 panels are preserved in Appendix A, plate A3.'
 if new=='S4A':caption+=' All members are retained, including nonsignificant and discordant effects. External measurements informed prior selection; these are not independent target-validation tests.'
 png=pdf.with_suffix('.png')
 if not png.exists():
  d=pdfium.PdfDocument(str(pdf));d[0].render(scale=300/72).to_pil().save(png);d.close()
 plates.append({'new_id':new,'old_id':old,'pdf':str(pdf.relative_to(O)),'png':str(png.relative_to(O)),'caption':caption,'source_pdf':str(src(m).relative_to(I))})

groups=[('S1','Complete receiver Hallmark landscape'),('S2','Complete transfer and lung sensitivity'),('S3','Paired TCR repertoire support'),('S4','All reciprocity-core members across old and new models'),('S5','Complete donor responses and assay reference'),('S6','IFN-conditional estimates and patient overlap'),('S7','Additional spatial quantitative context'),('S8','All clinical summary features')]
index_paras=[('title','Supplementary information'),('body','Receiver-cell remodelling and fixed epithelial programmes in checkpoint blockade toxicity'),('body','This reader supplement retains quantitative support, negative and discordant results, and source-specific limitations. Full estimates and maps accompany it as named attachments; no evidence is accessible only through an author computer.'),('h','Reader figures')]+[('body',f'{a}   {b}') for a,b in groups]+[('h','Tables and full attachments'),('body','Supplementary_Tables.xlsx contains twelve sheets with all reader-table records. Matching CSV files are in reader_tables/. Full Source_001-Source_079 files are in full_source_tables/, with the original statistical families and numeric precision retained.'),('body','Appendix A: prior-export analysis and selection history. Appendix B: all six Oxford and three Xenium map plates. Appendix C: all four response-cohort and three survival-cohort plates. figure_map.csv maps every original page to its destination. The source-data index links the full records and coordinate-associated data.')]+[('body',f"Table {d['table']}   {d['title']}") for d in defs]
methods=[('title','Supplementary methods'),('h','Earlier published-export organoid analysis'),('body',payload['historical_organoid_methods']),('h','Previously selected ligands and gene sets'),('body',payload['selection_methods']),('h','Statistical units and unavailable results'),('body','The patient, released tissue sample or paired organoid donor is the biological replicate. Cells, spots, epithelial families and repeated tissue sections are not additional independent participants. NES, gene-level FDR, set-family FDR and donor-level P values refer to distinct analyses. NE denotes unavailable or non-estimable results and is never replaced by zero. The residual is the fixed IFN-gene-excluded set; exclusion does not establish IFN independence. Complete source-specific multiplicity definitions and all model outputs are retained.')]
# Negative-result prose is sourced from unchanged baseline Results; no model is recomputed.
base=json.loads((O/'review/baseline_paragraphs.json').read_text(encoding='utf-8'))
summary=[('title','Quantitative limits and discordance'),('h','Donors and gene-set inference'),('body','The targeted analysis estimates 25 condition-by-family models and 100 of 128 planned set comparisons. Unavailable comparisons remain explicitly unavailable in Fig. S5A. In TA cells the disease-depleted set has positive enrichment, but the paired donor test has P = 0.25 and FDR = 0.50. Stem residual induction, goblet IFN reduction and both signs of paired donor changes are retained. The same perturbation experiment informed prior nomination; complete original and count-model estimates are separated in Fig. S4 and Appendix A.'),('h','External transfer and conditional estimates'),('body','The original 75-up set is positive in the four GSE206300 families but negative and nonsignificant in GSE210037 (Fig. 4c). None of the four external SORL1 family comparisons passes FDR < 0.05 (Fig. 5c). All eight IFN-conditional associations remain nonsignificant after adjustment, with little observed IFN-score overlap in several families (Fig. S6).'),('h','Additional spatial context'),('body','Oxford comparisons retain all four fixed programmes: the four-test FDR values are 0.0667, 0.1167, 0.1167 and 0.1167; none passes FDR < 0.05. Xenium measurements are descriptive, overlap discovery donors and assay only 64 of 275 disease-depleted-set members. Quantitative results and all programmes are shown in Fig. S7; complete maps and coordinate-associated records are in Appendix B. GSE210037 is a separate whole-tissue sample-pseudobulk comparison, not a coordinate-based spatial validation.'),('h','Clinical and TCR interpretation'),('body',base[37].split('The wider literature')[0].replace('Fig. 5a','main Fig. 5a').replace('Supplementary Figure 17','Fig. S8 and Appendix C')),('body','All GENE, AXIS and SIGNATURE pooled estimates remain in Fig. S8, including wide and null intervals. Complete cohort-specific directions, intervals, endpoints and FDR values are in Appendix C and the source tables; merged estimates do not establish homogeneous cohort effects. The colon shared-clone result and depth-controlled metrics do not pass their original FDR threshold, and the nine-patient epithelial association has FDR = 0.677. Fig. 6b adds a descriptive OLS mean line and pointwise mean-response band only; it adds no new biological inference.')]

def setup(doc):
 sec=doc.sections[0];sec.page_width=Mm(210);sec.page_height=Mm(297);sec.left_margin=sec.right_margin=Mm(15);sec.top_margin=sec.bottom_margin=Mm(10)
 sec.footer_distance=Mm(5)
 for name,size in [('Normal',10.5),('Title',15),('Heading 1',11.5)]:
  s=doc.styles[name];s.font.name='Arial';s.font.size=Pt(size);s.font.color.rgb=RGBColor(0,0,0);s.paragraph_format.space_after=Pt(5)
  for border in s.element.xpath('.//w:pBdr'):border.getparent().remove(border)
 p=sec.footer.paragraphs[0];p.alignment=1;f=OxmlElement('w:fldSimple');f.set(qn('w:instr'),'PAGE');p._p.append(f)
def paragraph(doc,role,text):
 p=doc.add_paragraph(text,'Title' if role=='title' else 'Heading 1' if role=='h' else 'Normal')
 if role=='body':p.paragraph_format.keep_with_next=False
 return p
doc=Document();setup(doc)
for k,content in enumerate([index_paras,methods,summary]):
 if k:doc.add_page_break()
 for role,text in content:paragraph(doc,role,text)
for plate in plates:
 doc.add_page_break();paragraph(doc,'h','Supplementary Figure '+plate['new_id'])
 pic=doc.add_paragraph();pic.paragraph_format.space_after=Pt(4);pic.add_run().add_picture(str(O/plate['png']),width=Mm(180))
 p=doc.add_paragraph(plate['caption']);p.paragraph_format.space_after=Pt(0)
 for r in p.runs:r.font.size=Pt(9)
doc.save(O/'supplement/Reader_SI.docx')
(O/'supplement/reader_SI_source.json').write_text(json.dumps({'front_pages':[index_paras,methods,summary],'plates':plates},ensure_ascii=False,indent=2),encoding='utf-8')

# The standalone PDF places the original or redrawn vector plot directly on each page.
mm=72/25.4;style=ParagraphStyle('body',fontName='Helvetica',fontSize=10,leading=13,textColor='#000000')
def text_page(content,page_num):
 b=io.BytesIO();c=canvas.Canvas(b,pagesize=(210*mm,297*mm));y=285*mm
 for role,text in content:
  st=ParagraphStyle('p',parent=style,fontSize=15 if role=='title' else 11 if role=='h' else 9.5,leading=18 if role=='title' else 12,spaceAfter=5,fontName='Helvetica-Bold' if role in ['title','h'] else 'Helvetica')
  p=Paragraph(text.replace('&','&amp;'),st);w,h=p.wrap(180*mm,10000);assert y-h>11*mm,('text page overflow',page_num,role,y,h);p.drawOn(c,15*mm,y-h);y-=h+(7 if role!='body' else 4)
 c.setFont('Helvetica',9);c.drawCentredString(105*mm,5*mm,str(page_num));c.save();return PdfReader(b).pages[0]
def figure_page(pdf,title,caption,page_num):
 p=PdfReader(pdf).pages[0];w=float(p.mediabox.width);h=float(p.mediabox.height);scale=180*mm/w
 st=ParagraphStyle('caption',parent=style,fontSize=9,leading=11.5)
 cap=Paragraph(caption.replace('&','&amp;'),st);cw,ch=cap.wrap(180*mm,10000)
 height=max(297*mm,10*mm+22+h*scale+8+ch+15*mm)
 b=io.BytesIO();c=canvas.Canvas(b,pagesize=(210*mm,height));c.setFont('Helvetica-Bold',12);c.drawString(15*mm,height-12*mm,title)
 top=height-20*mm;bottom=top-h*scale
 cap.drawOn(c,15*mm,bottom-8-ch);c.setFont('Helvetica',9);c.drawCentredString(105*mm,5*mm,str(page_num));c.save()
 page=PdfReader(b).pages[0];page.merge_transformed_page(p,Transformation().scale(scale).translate(15*mm,bottom));return page
writer=PdfWriter()
for k,content in enumerate([index_paras,methods,summary],1):writer.add_page(text_page(content,k))
for k,plate in enumerate(plates,4):writer.add_page(figure_page(O/plate['pdf'],'Supplementary Figure '+plate['new_id'],plate['caption'],k));plate['reader_pdf_page']=k
with (O/'supplement/Reader_SI.pdf').open('wb') as f:writer.write(f)

appendix_specs={'A':['4','6','14','14D_F'],'B':['9A','9B','9C','9D','9E','9F','12A','12B','12C'],'C':['17B1','17B2','17B3','17B4','17C5','17C6','17C7']}
appendix_names={'A':'Appendix_A_history.pdf','B':'Appendix_B_spatial_atlas.pdf','C':'Appendix_C_full_cohorts.pdf'}
amap={}
for letter,ids in appendix_specs.items():
 w=PdfWriter()
 for n,old in enumerate(ids,1):
  m=item(old);caption=clean_caption(m['caption']);caption+=' Complete source records are included in the accompanying source-data files and immutable input snapshot.'
  w.add_page(figure_page(src(m),f'Appendix {letter}   Plate {letter}{n}',caption,n));amap[old]=(letter,n)
 with (O/'appendices'/appendix_names[letter]).open('wb') as f:w.write(f)

dispositions=list(csv.DictReader((O/'task/ICI_TARGETED_FINAL_REDESIGN/supplement_page_disposition.csv').open(encoding='utf-8-sig')))
assert len(manifest)==34
rows=[]
for d in dispositions:
 page=int(d['current_pdf_page']);row=dict(d)
 if page<=2:row.update(new_id='Reader methods',file='supplement/Reader_SI.pdf',page='1-3')
 elif page<=10:row.update(new_id='Tables S1-S12',file='supplement/Supplementary_Tables.xlsx',page='12 sheets')
 else:
  m=manifest[page-11];old=m['figure'].split('Supplementary_Figure_')[1].split('_')[0]
  if m['figure'].startswith('Supplementary_Figure_14D_F'):old='14D_F'
  found=[p for p in plates if p['old_id']==old]
  if old in amap:
   letter,n=amap[old];row.update(new_id=f'Appendix {letter}{n}',file='appendices/'+appendix_names[letter],page=n)
   if old=='14':row.update(new_id='S5C and Appendix A3',file='supplement/Reader_SI.pdf; appendices/Appendix_A_history.pdf',page='12; 3')
  else:
   assert len(found)==1,(page,old);p=found[0];row.update(new_id=p['new_id'],file='supplement/Reader_SI.pdf',page=p['reader_pdf_page'])
 row['complete_original_page']=f'input_snapshot/supplementary/Supplementary_documents.pdf#page={page}'
 rows.append(row)
with (O/'supplement/figure_map.csv').open('w',newline='',encoding='utf-8-sig') as f:w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
(O/'review/supplement_repack.json').write_text(json.dumps({'reader_pdf_pages':len(writer.pages),'original_pages':len(rows),'appendices':appendix_specs,'all_pages_mapped':True,'reader_plates':plates,'availability':'All attachments included locally in candidate ZIP; public repository deposit USER_PENDING'},ensure_ascii=False,indent=2),encoding='utf-8')
# Preserve exact CSV precision. Only add a separate display-label field when needed.
wb=[]
for d in defs:
 path=O/'supplement/reader_tables'/Path(d['file'].replace('\\','/')).name
 frame=pd.read_csv(path)
 for col in frame.select_dtypes('object').columns:
  frame[col]=frame[col].map(lambda x:x.replace('Platform samples','GSE210037 sample pseudobulk').replace('whole_spot_sample','GSE210037 sample pseudobulk') if isinstance(x,str) else x)
 # The original precision CSV stays in input_snapshot; Python does not re-export numeric columns here.
 wb.append({'sheet':d['table'],'title':d['title'],'columns':list(frame),'rows':frame.astype(object).where(pd.notnull(frame),None).values.tolist(),'note':d['note'],'source':f"reader_tables/{path.name}; full sources: "+', '.join(d['full_source_ids'])})
(O/'supplement/workbook_payload.json').write_text(json.dumps(wb,ensure_ascii=False,allow_nan=False),encoding='utf-8')
print('SUPPLEMENT_REPACK_PASS',len(writer.pages),'reader pages;',sum(map(len,appendix_specs.values())),'appendix pages; all 44 original pages mapped')
