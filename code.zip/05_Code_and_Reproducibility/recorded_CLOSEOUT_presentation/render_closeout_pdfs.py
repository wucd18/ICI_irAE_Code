"""Render every final document page plus full-width long-figure crops for visual QA."""
from closeout_common import W,S
from pathlib import Path
import json,math
import pypdfium2 as pdfium
from PIL import Image,ImageDraw
root=W/'review/visual_closeout';root.mkdir(exist_ok=True)
items=[]
for p in sorted((W/'review/closeout_render').glob('*/*.pdf')):items.append((p.stem,p,'document'))
items.append(('Reader_SI_vector',W/'supplement/Reader_SI.pdf','document'))
for p in sorted((S/'03_Companion_Appendices').glob('*.pdf')):items.append((p.stem,p,'document'))
for p in sorted((S/'02_Supplementary_Figures_OneFilePerFigure').glob('Supplementary_Figure_S*_combined.pdf')):items.append((p.stem,p,'long'))
records=[];contact_files=[]
for name,path,kind in items:
    dest=root/name;dest.mkdir(exist_ok=True);doc=pdfium.PdfDocument(str(path));images=[]
    for n in range(len(doc)):
        pg=doc[n];im=pg.render(scale=1.65 if kind=='long' else 1.4).to_pil().convert('RGB');file=dest/f'page_{n+1:03d}.png';im.save(file)
        records.append({'file':str(path.relative_to(S)),'page':n+1,'png':str(file.relative_to(W)),'width':im.width,'height':im.height})
        if kind=='long':
            for k,y in enumerate(range(0,im.height,1100),1):
                crop=im.crop((0,max(0,y-25),im.width,min(im.height,y+1100)));f=dest/f'crop_{k:02d}.png';crop.save(f);contact_files.append(str(f.relative_to(W)))
        else:images.append((n+1,im))
    if kind!='long':
        for start in range(0,len(images),2):
            selected=images[start:start+2];width=sum(im.width for _,im in selected)+16*(len(selected)+1);height=max(im.height for _,im in selected)+45
            sheet=Image.new('RGB',(width,height),'#dddddd');d=ImageDraw.Draw(sheet);x=16
            for n,im in selected:d.text((x,8),f'{name} | page {n}',fill='black');sheet.paste(im,(x,30));x+=im.width+16
            file=dest/f'review_{start+1:03d}-{selected[-1][0]:03d}.png';sheet.save(file);contact_files.append(str(file.relative_to(W)))
    doc.close()
(W/'review/visual_render_manifest.json').write_text(json.dumps({'status':'RENDERED_REQUIRES_VISUAL_REVIEW','pages':records,'review_images':contact_files},ensure_ascii=False,indent=2),encoding='utf-8')
print('ALL_PDF_RENDER_PASS',len(records),'pages;',len(contact_files),'review images')
