args<-commandArgs(TRUE)
stopifnot(length(args)==1)
files<-list.files(file.path(args[1],'presentation_code'),pattern='[.]R$',full.names=TRUE)
for(f in files) {parse(file=f);cat('PARSE_PASS',basename(f),'\n')}
cat('R_STATIC_PARSE_PASS',length(files),'\n')
