"""Limited prose changes against the sole VISUAL_FINAL clean manuscript."""
from closeout_common import W,S,V,refs
from docx import Document
import re,json,csv
doc=Document(V/'manuscript/manuscript_VISUAL_FINAL_CLEAN.docx')
old=[p.text for p in doc.paragraphs];new=[refs(p) for p in old]
with (W/'source_data/final_panels/F3C.csv').open(encoding='utf-8-sig') as f: rows=list(csv.DictReader(f))
sets={}
for r in rows:sets.setdefault(r['module'],set()).add(r['gene'])
# Derive the displayed proportion from the fixed memberships, not a new selection.
up=sets[next(r['module'] for r in rows if r['analysis_role']=='data_derived_disease_up_module')]
res=next(v for k,v in sets.items() if 'residual' in k.lower() or 'nonifn' in k.lower() or 'non_ifn' in k.lower())
new[134]=new[134].replace('accounting for all 84 original members.',f'accounting for all {len(up)} original members ({100*len(res)/len(up):.2f}% retained).')
new[134]=new[134].replace('Excluding curated IFN genes','The original disease-up and disease-depleted selection rule was FDR <= 0.05 and abs(log2FC) >= log2(1.25), as recorded in Source_021; the memberships were not reselected. Excluding curated IFN genes')
with (W/'source_data/final_panels/F6C.csv').open(encoding='utf-8-sig') as f: tcr=list(csv.DictReader(f))
u=[round((float(r['cliffs_delta'])+1)*int(r['n_group1'])*int(r['n_group0'])/2,8) for r in tcr]
assert len(set(u))==1
new[140]=new[140].replace('Original P values and FDR are displayed separately for each metric.',f'Original P values and FDR are displayed separately for each metric. The two metrics have different observed values and median differences but the same Mann-Whitney U statistic (U = {u[0]:g}); consequently, their original two-sided P values and BH FDR within the same nine-test family are identical.')
new[83]=new[83].replace('The original analysis scripts and statistical results remain in the unchanged source project.','The original analysis scripts are included in 05_Code_and_Reproducibility/original_V1_recorded_source/, with recovered targeted and spatial scripts in targeted_extension_recorded_source/; the original statistical results remain unchanged.')
new[83]=new[83].replace('the logs directory and Supplementary Methods','05_Code_and_Reproducibility/current_visual_rebuild_source/logs/ and Supplementary Methods').replace('RUN_VISUAL_FINAL.ps1','05_Code_and_Reproducibility/current_visual_rebuild_source/RUN_CLOSEOUT.ps1')
new[85]=new[85].replace('Public repository identifiers remain to be supplied by the authors.','The submission directory provides reader tables in 01_Journal_Upload/05_Supplementary_Tables/, complete source tables and current figure-source records in 04_Source_Data/, merged Supplementary Figures S1-S8 in 02_Supplementary_Figures_OneFilePerFigure/, and Appendices A-C in 03_Companion_Appendices/. Public repository identifiers remain to be supplied by the authors.')
manifest=list(csv.DictReader((S/'05_Code_and_Reproducibility/exact_source_recovery_manifest.csv').open(encoding='utf-8-sig')))
new[87]='The executed presentation entry is 05_Code_and_Reproducibility/current_visual_rebuild_source/RUN_CLOSEOUT.ps1; its presentation_code/ directory contains the figure, document, supplementary-figure and workbook scripts, with actual execution records in logs/. This entry reads the locked VISUAL_FINAL results and computes only the descriptive nine-patient OLS display in Fig. 6b; primary statistical models are not rerun. The original analysis source is provided in 05_Code_and_Reproducibility/original_V1_recorded_source/, and the recovered targeted and spatial source is in targeted_extension_recorded_source/. exact_source_recovery_manifest.csv records the matching source hashes. Historical entry points are retained for provenance and were not executed in this closeout. Runtime paths and software versions reflect the author machine; end-to-end portability has not been established. A permanent public repository, DOI and any code licence remain to be supplied by the authors.'
source=(V/'manuscript/manuscript_source.md').read_text(encoding='utf-8')
source=re.sub(r'(<!-- paragraph:(\d+) -->\n)(.*?)(?=\n\n<!--|\Z)',lambda m:m[1]+new[int(m[2])]+('\n' if m[3].endswith('\n') else ''),source,flags=re.S)
(W/'manuscript/manuscript_source.md').write_text(source,encoding='utf-8')
ledger=[{'paragraph':i,'before':a,'after':b,'baseline':'VISUAL_FINAL clean','reason':'closeout definition, panel reference, TCR explanation or source availability'} for i,(a,b) in enumerate(zip(old,new)) if a!=b]
(W/'review/manuscript_change_ledger.json').write_text(json.dumps(ledger,ensure_ascii=False,indent=2),encoding='utf-8')
print('LIMITED_MANUSCRIPT_SOURCE_PASS',len(ledger),'paragraphs')
