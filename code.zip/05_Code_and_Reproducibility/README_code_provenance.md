# Source provenance and current execution

Current entry: current_visual_rebuild_source/RUN_CLOSEOUT.ps1. Run -Stage All only in a new writable copy to regenerate presentation outputs from visual_input_snapshot; -Stage Finalize assembles already rendered outputs and verifies the package. This closeout executed the figure, supplement, workbook and Word-render stages with individual command logs, followed by the Finalize entry. No primary statistical entry was run.

The numerical baseline is VISUAL_FINAL 20260914T045831Z, SHA-256 7537083659facb999e7a53bbddf11abb779851d54790f4bdb46427d102c390bd. visual_input_snapshot/selected_input_manifest.json records each current input. The older input_snapshot and RUN_VISUAL_FINAL.ps1 are historical provenance and are not the current closeout inputs or entry.

Recovered source: {'original_V1': 35, 'targeted_extension': 52}. All 87 original/targeted/spatial source files match exact_source_recovery_manifest.csv. CURRENT_CODE_INDEX.csv gives actual package-relative locations and hashes. Full statistical source is included for review; do not run historical DE/GSEA/Cox/Meta/donor launchers for presentation work. The only display refit is the already authorized OLS mean and mean-response band for the same nine Fig. 6b patients; original Spearman statistics remain unchanged.

Original R 4.2.2 history and the targeted R 4.4.1 environment remain distinct. Paths are locked to the author machine; a complete raw-to-final portable reproduction is not claimed. No software was installed, public data downloaded, or scientific threshold changed in this closeout. Public repository, DOI and licence remain USER_PENDING. Files in 06_Review_and_Codex outside closeout/ are pre-closeout review evidence, including the NOT_RUN reference patch.
