"""Replay only the separately specified extensions, in a fresh run directory."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,subprocess,sys,os,json,shutil,uuid,hashlib
O=Path(__file__).resolve().parents[1];R='D:/Software/Bioinformatics/R/R-4.4.1/bin/x64/Rscript.exe'
a=argparse.ArgumentParser();a.add_argument('--stage',choices=['Fixtures','Verify','Conditional','Organoid','Both'],default='Verify');stage=a.parse_args().stage
def call(root,exe,args,env=None):
 p=subprocess.run([sys.executable,str(root/'analysis_code/run_restored.py'),exe,*map(str,args)],env=env)
 if p.returncode:raise SystemExit(p.returncode)
if stage=='Fixtures':
 env=dict(os.environ,ICI_FIXTURE_ONLY='1')
 for name in ['conditional_analysis.R','analyze_organoid.R']:call(O,R,['--vanilla',O/'analysis_code'/name,O],env)
 print('TARGETED_FIXTURES_PASS');raise SystemExit(0)
if stage=='Verify':
 for name in ['verify_conditional.py','verify_models_readonly.py']:call(O,sys.executable,['-X','utf8',O/'analysis_code'/name])
 print('TARGETED_RECORDED_RESULTS_VERIFIED');raise SystemExit(0)
run=O/'targeted_runs'/(datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'_'+uuid.uuid4().hex[:8]);run.mkdir(parents=True,exist_ok=False)
for folder in ['analysis_code','review','source_data','logs','temp','organoid_donor_extension/source_data','organoid_donor_extension/review','supplementary/original_tables']:(run/folder).mkdir(parents=True,exist_ok=True)
inputs=[]
def cp(rel):
 src=O/rel;dest=run/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dest)
 inputs.append({'source':str(src),'copy':str(dest),'size':src.stat().st_size,'sha256':hashlib.file_digest(open(src,'rb'),'sha256').hexdigest(),'role':'explicit frozen input or source code for targeted replay'})
for name in ['run_restored.py','conditional_analysis.R','analyze_organoid.R','verify_conditional.py','verify_models_readonly.py']:cp('analysis_code/'+name)
cp('review/child_environment_restore.json')
j=json.loads((run/'review/child_environment_restore.json').read_text());j['restored'].update(TEMP=str(run/'temp'),TMP=str(run/'temp'),R_USER=str(run));(run/'review/child_environment_restore.json').write_text(json.dumps(j,indent=2))
if stage in ['Conditional','Both']:
 for rel in ['review/conditional_analysis_plan_locked.json','source_data/conditional_model_input.tsv']:cp(rel)
 call(run,R,['--vanilla',run/'analysis_code/conditional_analysis.R',run])
 call(run,sys.executable,['-X','utf8',run/'analysis_code/verify_conditional.py'])
if stage in ['Organoid','Both']:
 for name in ['pseudobulk_counts.mtx','pseudobulk_metadata.tsv','pseudobulk_genes.tsv']:cp('organoid_donor_extension/source_data/'+name)
 for name in ['analysis_plan_locked.json','preflight_QC.json']:cp('organoid_donor_extension/review/'+name)
 cp('supplementary/original_tables/Table_S21_frozen_module_definitions.tsv')
 call(run,R,['--vanilla',run/'analysis_code/analyze_organoid.R',run])
 call(run,sys.executable,['-X','utf8',run/'analysis_code/verify_models_readonly.py'])
(run/'review/replay_input_manifest.json').write_text(json.dumps(inputs,indent=2))
print('TARGETED_REPLAY_PASS',str(run))
