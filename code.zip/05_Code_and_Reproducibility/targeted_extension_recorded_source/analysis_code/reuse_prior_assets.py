from pathlib import Path
import zipfile,json,hashlib,csv
O=Path(__file__).resolve().parents[1]
zpath=Path('E:/ICI_irAE_V1_Redline_Revision/20260913T153320Z_ce95c1e1/submission_candidate_V1_spatial_20260913T171205Z.zip')
allowed=('figures/','supplementary/','source_data/','spatial_extension/','xenium_extension/','presentation_code/','provenance/')
review={'review/local_findings.json','review/manuscript_change_record.json','review/baseline/paragraphs.json','review/baseline/baseline_resolution.json','review/baseline/manuscript_V1_original.docx','review/organoid_evidence_resolution.md','review/reciprocity_core_gene_evidence.tsv','review/source_map.tsv','review/ALL_PANEL_SOURCE_MAP.tsv','review/input_manifest_before.tsv','review/numerical_fidelity.tsv','review/output_verification.json','review/manuscript_numerical_claim_checks.tsv','review/changes.tsv'}
rows=[]
with zipfile.ZipFile(zpath) as z:
 for info in z.infolist():
  n=info.filename
  if info.is_dir() or not(n.startswith(allowed) or n in review):continue
  if '/figures/' not in n and (('/review/render/' in n) or ('/logs/' in n)):continue
  p=O/n
  if p.exists():raise FileExistsError(str(p))
  p.parent.mkdir(parents=True,exist_ok=True);b=z.read(n);p.write_bytes(b)
  rows.append(dict(member=n,source_zip=str(zpath),sha256=hashlib.sha256(b).hexdigest(),role='Explicitly reused unchanged V1 result/presentation or prior completed spatial extension; not a new analysis result'))
with (O/'review/reused_asset_manifest.tsv').open('w',encoding='utf-8',newline='') as f:
 w=csv.DictWriter(f,fieldnames=rows[0],delimiter='\t');w.writeheader();w.writerows(rows)
print('PRIOR_ASSETS_RECORDED',len(rows))
