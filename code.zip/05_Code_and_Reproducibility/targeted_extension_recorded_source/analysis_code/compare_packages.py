from pathlib import Path
import pandas as pd,zipfile,io,json,hashlib
O=Path(__file__).resolve().parents[1]
j=json.loads((O/'review/zip_comparison_summary.json').read_text(encoding='utf-8'))
rows=[]
with zipfile.ZipFile(j['old_zip']) as a,zipfile.ZipFile(j['new_zip']) as b:
 for n in sorted(set(a.namelist())&set(b.namelist())):
  if not(n.startswith('source_data/') and n.endswith('.tsv')):continue
  x=pd.read_csv(a.open(n),sep='\t');y=pd.read_csv(b.open(n),sep='\t')
  assert x.shape==y.shape and list(x)==list(y),n
  changed=[];num=0
  for col in x:
   if pd.api.types.is_numeric_dtype(x[col]) and pd.api.types.is_numeric_dtype(y[col]):
    assert x[col].equals(y[col]),(n,col);num+=int(x[col].notna().sum())
   elif not x[col].equals(y[col]):changed.append(col)
  rows.append(dict(source=n,rows=len(x),numeric_values_compared=num,numeric_status='IDENTICAL',changed_nonnumeric_columns=';'.join(changed)))
pd.DataFrame(rows).to_csv(O/'review/old_vs_spatial_panel_numerical_comparison.tsv',sep='\t',index=False)
report=f'''# 与 submission_candidate_V1.zip 的实际对照

对照旧包：{j['old_zip']}

对照上一轮空间修订包：{j['new_zip']}

结论：原六张主图的统计估计没有升级。{len(rows)} 张共同源表中，{sum(not r['changed_nonnumeric_columns'] for r in rows)} 张完全相同；Figure 4A 只把 7 行分类从 Original nominees 改为 Directional nominees。逐格核对的 {sum(r['numeric_values_compared'] for r in rows):,} 个非缺失数值完全一致。该数量包含源行号及其他数值字段，不等同于独立统计检验数。图形文件发生变化不代表图中统计结果改变。

上一轮实际修改了什么：

| 内容 | 修改 | 科学含义 |
|---|---|---|
| 原六图与英文稿 | 重绘、规范统计单位/方向/图号，红字记录，纠正 66 基因来源和 IBD2 的单位等 | 提高数值与解释准确性，没有新增原六图的统计估计 |
| Oxford 空间队列 | 新增 16 供者的固定程序转移与真实坐标图 | 增加外部观察，但四项 FDR 均未达 0.05，不能称显著独立复制 |
| Xenium | 新增细胞区室与组织定位 | 供者标签与发现队列重合、覆盖部分固定基因，不能增加独立验证队列数 |
| 类器官因果或干预链条 | 只做出版表与代码核查 | 没有重新拟合供者模型，尚未补足关键扰动环节 |

本轮因此另建独立的 IFN 条件分析和类器官原始计数重分析。旧包、上一轮包、原项目均保留。新估计与旧估计并列，不能因为换方法得到较小 P 值就称为独立机制验证。当前完整的新结果见本轮修订报告与源表。
'''
(O/'review/与submission_candidate_V1对照_CN.md').write_text(report,encoding='utf-8')
print('COMPARED',len(rows),'NUMERIC_VALUES',sum(r['numeric_values_compared'] for r in rows))
