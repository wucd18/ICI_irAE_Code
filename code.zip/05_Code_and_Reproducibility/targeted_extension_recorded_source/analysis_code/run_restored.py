from pathlib import Path
import os,subprocess,json,sys
from datetime import datetime,timezone
O=Path(__file__).resolve().parents[1]
env={**os.environ,**json.loads((O/'review/child_environment_restore.json').read_text(encoding='utf-8'))['restored']}
env.update(SystemDrive=str(Path(env['SystemRoot']).drive),ALLUSERSPROFILE=env['PROGRAMDATA'],OS='Windows_NT',PROCESSOR_ARCHITECTURE='AMD64')
cmd=sys.argv[1:];name=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
start=datetime.now(timezone.utc).isoformat()
p=subprocess.run(cmd,env=env,cwd=O,capture_output=True,timeout=7200)
(O/'logs'/f'{name}.stdout.txt').write_bytes(p.stdout);(O/'logs'/f'{name}.stderr.txt').write_bytes(p.stderr)
(O/'logs'/f'{name}.json').write_text(json.dumps({'command':cmd,'start_utc':start,'end_utc':datetime.now(timezone.utc).isoformat(),'exit_code':p.returncode,'env_source':'review/child_environment_restore.json','stdout':name+'.stdout.txt','stderr':name+'.stderr.txt'},indent=2),encoding='utf-8')
sys.stdout.reconfigure(encoding='utf-8');print(p.stdout.decode('utf-8',errors='replace'));print(p.stderr.decode('utf-8',errors='replace'));print('ACTUAL_EXIT_CODE',p.returncode);sys.exit(0 if p.returncode==0 else 1)
