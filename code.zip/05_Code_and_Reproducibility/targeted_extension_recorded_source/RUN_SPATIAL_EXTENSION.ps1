param([ValidateSet('Fixtures','Oxford','Xenium','Both')][string]$Stage='Fixtures')
$ErrorActionPreference='Stop'
$revisionRoot=$PSScriptRoot
$artifactPython='C:\Users\frede\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
$statPython='D:\Software\python\python.exe'
$restorer=Join-Path $revisionRoot 'presentation_code\run_restored.py'
$attempt=(Get-Date).ToUniversalTime().ToString('yyyyMMddTHHmmssZ')+'_'+[guid]::NewGuid().ToString('N').Substring(0,8)
$resultRoot=Join-Path $revisionRoot ('extension_runs\'+$attempt)
New-Item -ItemType Directory -Path $resultRoot | Out-Null
function Invoke-Checked([string]$Script,[string[]]$Arguments){
 & $artifactPython $restorer $statPython (Join-Path $revisionRoot ('presentation_code\'+$Script)) @Arguments
 if($LASTEXITCODE -ne 0){throw "Extension step $Script failed. Actual exit=$LASTEXITCODE. Historical logs and candidate outputs retained."}
}
try{
 Invoke-Checked 'analyze_spatial_frozen.py' @('--test')
 Invoke-Checked 'xenium_spatial_followthrough.py' @('--test')
 if($Stage -in @('Oxford','Both')){Invoke-Checked 'analyze_spatial_frozen.py' @('--output-root',(Join-Path $resultRoot 'spatial_extension'))}
 if($Stage -in @('Xenium','Both')){Invoke-Checked 'xenium_spatial_followthrough.py' @('--output-root',(Join-Path $resultRoot 'xenium_extension'))}
 [pscustomobject]@{stage=$Stage;status='PASS';output=$resultRoot;utc=(Get-Date).ToUniversalTime().ToString('o');notes='Separate bounded extension; no original-project analysis entry is called.'}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $resultRoot 'runner_status.json') -Encoding utf8
 Write-Output "Extension stage completed; output: $resultRoot"
 exit 0
}catch{
 $_|Out-String|Set-Content -LiteralPath (Join-Path $resultRoot 'failure.txt') -Encoding utf8
 Write-Error $_;exit 1
}
