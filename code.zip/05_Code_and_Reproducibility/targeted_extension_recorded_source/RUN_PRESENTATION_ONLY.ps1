param([ValidateSet('All','Figures','Word','Tables','Verify')][string]$Stage='All')
$ErrorActionPreference='Stop'
$revisionRoot=$PSScriptRoot
$statPython='D:\Software\python\python.exe'
$artifactPython='C:\Users\frede\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
$rscript='D:\Software\Bioinformatics\R\R-4.4.1\bin\x64\Rscript.exe'
$restorer=Join-Path $revisionRoot 'analysis_code\run_restored.py'
function Invoke-Checked([string]$Executable,[string[]]$Arguments){
 & $statPython $restorer $Executable @Arguments
 if($LASTEXITCODE -ne 0){throw "Presentation step failed; actual exit=$LASTEXITCODE; see retained logs."}
}
if($Stage -in @('All','Figures')){
 Invoke-Checked $rscript @('--vanilla',(Join-Path $revisionRoot 'presentation_code\plot_v1.R'),'E:\ICI_irAE_Original_Project',$revisionRoot)
 foreach($script in @('plot_conditional.R','plot_organoid_supplement.R','plot_spatial_extension.R','plot_xenium_extension.R')){
  Invoke-Checked $rscript @('--vanilla',(Join-Path $revisionRoot ('presentation_code\'+$script)),$revisionRoot)
 }
 Invoke-Checked $artifactPython @('-X','utf8',(Join-Path $revisionRoot 'presentation_code\render_figure_pdfs.py'))
}
if($Stage -in @('All','Word')){
 Invoke-Checked $artifactPython @('-X','utf8',(Join-Path $revisionRoot 'presentation_code\edit_docx.py'),'--test')
 Invoke-Checked $artifactPython @('-X','utf8',(Join-Path $revisionRoot 'presentation_code\edit_docx.py'))
 Invoke-Checked 'C:\Users\frede\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\powershell\pwsh.exe' @('-NoProfile','-File',(Join-Path $revisionRoot 'presentation_code\render_word.ps1'))
 Invoke-Checked $artifactPython @('-X','utf8',(Join-Path $revisionRoot 'presentation_code\render_final_word_pages.py'))
}
if($Stage -in @('All','Tables','Verify')){
 Invoke-Checked $artifactPython @('-X','utf8',(Join-Path $revisionRoot 'presentation_code\prepare_new_release.py'))
 Invoke-Checked $artifactPython @('-X','utf8',(Join-Path $revisionRoot 'presentation_code\verify_outputs.py'))
}
Write-Output 'PRESENTATION_ONLY_EXIT 0. Rendering and automated checks do not replace visual review.'
exit 0
