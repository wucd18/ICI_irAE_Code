"""Prepare the presentation supplement and review records; never refit a model."""
from pathlib import Path
import shutil,json,re,sys,hashlib,math
import pandas as pd
from datetime import datetime,timezone
O=Path(__file__).resolve().parents[1];S=Path(r'E:\ICI_irAE_Original_Project')
sys.stdout.reconfigure(encoding='utf-8')
def rd(p):return pd.read_csv(p,sep='\t',float_precision='round_trip')
def st(n):return rd(next((S/'tables_for_article').glob(f'Table_S{n}_*')))
def save(d,p):d.to_csv(p,sep='\t',index=False,na_rep='NA')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    arc=O/'supplementary/original_tables';dst=O/'supplementary/tables'
    arc.mkdir(exist_ok=True);dst.mkdir(exist_ok=True)
    ledger=[];index=[]
    for f in sorted((S/'tables_for_article').glob('*.tsv')):
        shutil.copy2(f,arc/f.name)
        d=rd(f);notes='Original V1 numerical results retained'
        if f.name.startswith('Table_1_'):
            sm=rd(O/'spatial_extension/source_data/sample_manifest.tsv')
            pat=sm.drop_duplicates('patient').condition.value_counts()
            extra={'cohort':'GSE189184 + adult reference A1/A2 in GSE158328','context':'colon','condition':'ICI colitis; healthy; UC','assays':'Visium; released H&E and coordinates','evaluable_samples':f'{len(sm)} sections from {sm.patient.nunique()} donors ({pat["ICI colitis"]} ICI, {pat["Healthy"]} healthy, {pat["UC"]} UC)','control_design':'ICI versus healthy at donor level; UC descriptive only','role_in_study':'additional frozen-module transfer and tissue distribution','key_constraint':'Whole-tissue scores; small healthy group, sex/batch/composition imbalance; none of four module tests passes FDR<0.05'}
            d=pd.concat([d,pd.DataFrame([extra])],ignore_index=True)
            if (O/'xenium_extension/review/analysis_summary.json').exists():
                xs=json.loads((O/'xenium_extension/review/analysis_summary.json').read_text())
                d=pd.concat([d,pd.DataFrame([{'cohort':'JCI202488 / Figshare 27327813 / Dataset 2 5K','context':'colon','condition':'ICI colitis; healthy; UC','assays':'Xenium targeted single-cell spatial RNA','evaluable_samples':f'{xs["included_cells"]} source-QC cells; {xs["patients"]} donor labels','control_design':'descriptive patient and annotated-compartment estimates only','role_in_study':'spatial follow-through of original V1 programmes and nominated genes','key_constraint':'Overlaps V1 discovery donors; targeted partial module coverage; no independent validation or new hypothesis test'}])],ignore_index=True)
            notes='Original cohorts retained; additional spatial cohorts documented with explicit biological units and overlap'
        if f.name.startswith('Table_S21_'):
            old=d.selection_rule.copy()
            d['selection_rule']=old.str.replace('abs(log2FC)>=0.5','abs(log2FC)>=log2(1.25)',regex=False)
            for i in d.index[old.ne(d.selection_rule)]:
                ledger.append({'table':f.name,'record_key':f'{d.at[i,"module"]}|{d.at[i,"gene"]}','column':'selection_rule','old':old[i],'new':d.at[i,'selection_rule'],'category':'B','reason_CN':'原配置与保存passes_effect_gate逐基因核对；只修正文档阈值，成员与统计值不变'})
            notes='Selection-rule text corrected from original configuration and saved flags; members unchanged'
        if f.name.startswith(('Table_2_','Table_S59_')):
            ren={'organoid_function_rescue':'original_directional_module_gate','legacy_module_decoupling_gate':'original_restricted_module_gate'}
            d=d.rename(columns=ren)
            d['candidate_level']=d.candidate_level.str.replace('downstream repair-core gene','downstream epithelial reciprocity-core gene',regex=False)
            d['interpretation_limit']='Existing decision retained; expression associations do not establish intervention benefit, harm or safety'
            d['organoid_input_status']='NEEDS_SPECIFIC_EVIDENCE for exact publisher model/export correspondence'
            d['missing_count_explanation']=d.candidate_level.apply(lambda s:'No direct perturbation for this downstream gene; blank pathway counts are not zero' if 'gene' in s else 'No imputed pathway or clinical values')
            ledger.append({'table':f.name,'record_key':'all; SORL1','column':'labels and interpretation','old':'function_rescue / repair-core / unexplained blank counts','new':'directional gate / epithelial reciprocity core / explicit not-applicable explanation','category':'A','reason_CN':'保留原决策和全部原特征；避免将转录门控当成功能验证，SORL1空缺不补0'})
            notes='Original decisions retained with revised presentation labels and explicit applicability limits; original machine-readable table in original_tables'
        if f.name.startswith('Table_S54_'):
            old=d.interpretation.iloc[0];d['interpretation']='shared inflammatory pressure coexists with context-dependent receiver-cell remodelling; organs and source studies are confounded'
            ledger.append({'table':f.name,'record_key':'analysis','column':'interpretation','old':old,'new':d.interpretation.iloc[0],'category':'A','reason_CN':'未隔离器官与来源，避免organ-specific机制表述'})
        if f.name.startswith(('Table_S62_','Table_S63_')):
            # These two documentary inventories are generated below; old versions stay in the archive.
            continue
        save(d,dst/f.name)
        index.append({'table':re.match(r'(Table_(?:S)?\d+)_',f.name).group(1),'file':f.name,'scope':notes})
    sh=rd(O/'review/organoid_sheet_audit.tsv')
    sh['revision_interpretation']=sh.sheet.map({'A_TA_DEGs':'Complete extraction confirmed; exact generating model/export correspondence unresolved','B_Stem_DEGs':'Duplicate of Goblet export; excluded by original V1 code','C_Goblet_DEGs':'Duplicate of Stem export; excluded by original V1 code','D_Colonocyte_DEGs':'Complete extraction confirmed; exact generating model/export correspondence unresolved'})
    f='Table_S51_organoid_input_applicability.tsv';save(sh,dst/f)
    index.append({'table':'Table_S51','file':f,'scope':'New documentary input-applicability table fills the missing S51 slot; no new statistical analysis'})
    scripts=[]
    for p in [O/'RUN_PRESENTATION_ONLY.ps1',*sorted((O/'presentation_code').glob('*.py')),*sorted((O/'presentation_code').glob('*.R')),*sorted((O/'presentation_code').glob('*.ps1'))]:
        scripts.append({'file':str(p.relative_to(O)),'bytes':p.stat().st_size,'sha256':sha(p),'scope':'Isolated revision and separately authorized bounded extensions; original project scripts unchanged; entrypoints distinguish presentation from analysis'})
    f='Table_S62_reproducibility_script_inventory.tsv';save(pd.DataFrame(scripts),dst/f);index.append({'table':'Table_S62','file':f,'scope':'Current presentation code inventory; original statistical inventory preserved in archive'})
    f='Table_S63_final_artifact_manifest.tsv';index.append({'table':'Table_S63','file':f,'scope':'Current candidate artifact hashes; generated at packaging; no self/ZIP hash recursion'})
    extensions=[(64,'spatial_extension/source_data/sample_manifest.tsv','new_spatial_sample_manifest'),(65,'spatial_extension/source_data/patient_scores.tsv','new_spatial_patient_scores'),(66,'spatial_extension/source_data/frozen_transfer_results.tsv','new_spatial_frozen_transfer'),(67,'spatial_extension/source_data/module_coverage.tsv','new_spatial_module_coverage')]
    if (O/'xenium_extension/review/analysis_summary.json').exists():
        extensions += [(68,'xenium_extension/source_data/patient_compartment_manifest.tsv','xenium_patient_compartments'),(69,'xenium_extension/source_data/patient_compartment_scores.tsv','xenium_patient_programme_scores'),(70,'xenium_extension/source_data/patient_gene_expression.tsv','xenium_nominated_gene_distribution'),(71,'xenium_extension/source_data/module_coverage.tsv','xenium_targeted_panel_coverage')]
    for n,src,label in extensions:
        f=f'Table_S{n}_{label}.tsv';shutil.copy2(O/src,dst/f)
        index.append({'table':f'Table_S{n}','file':f,'scope':'New spatial extension; source '+src+'; original V1 statistics unchanged'})
    index=pd.DataFrame(index);index['_order']=index.table.str.extract(r'(\d+)$',expand=False).astype(int)+(index.table.str.contains('_S').astype(int)*100)
    save(index.sort_values('_order').drop(columns='_order'),O/'supplementary/table_index.tsv')
    save(pd.DataFrame(ledger),O/'review/table_changes_CN.tsv')
    # Critical numerical manuscript claims; comparison formatting is explicit and tied to original rows.
    pars={x['id']:x['revised'] for x in json.loads((O/'review/manuscript_change_record.json').read_text(encoding='utf-8'))['paragraphs']}
    claims=[]
    def claim(pid,label,value,fmt,source,needle=None):
        token=format(value,fmt);found=(needle or token) in pars[f'V1P{pid:03d}']
        claims.append({'paragraph':f'V1P{pid:03d}','claim':label,'source_value':value,'display_value':token,'source':source,'status':'PASS' if found else 'FAIL','scope':'source-to-text check at stated display precision'})
    findings=json.loads((O/'review/local_findings.json').read_text(encoding='utf-8'))
    claim(17,'colon spots',findings['spatial_colon_spots'],',d','spatial_pseudobulk_metadata: colon n_spots sum')
    h=st(54).iloc[0]
    for pid in [8,23]:claim(pid,'Hallmark rho',h.spearman_rho,'.4f','Table S54');claim(pid,'Hallmark P',h.p,'.3f','Table S54')
    sizes=st(21).groupby('module').gene.nunique()
    for m,n in sizes.items():
        if m in ['ICI_COLITIS_EPITHELIAL_UP_STRICT','ICI_COLITIS_EPITHELIAL_UP_NON_IFN','ICI_COLITIS_EPITHELIAL_LOSS_STRICT','CURATED_IFN_VISIBILITY']:claim(26,m,int(n),'d','Table S21 distinct members')
    tn=rd(S/'02_results/GSE313368_irAE_module_GSEA_all.tsv.gz')
    tn=tn[tn.perturbation.eq('TNFSF12')&tn.celltype.eq('Transit_Amplifying')]
    for m in ['ICI_COLITIS_EPITHELIAL_LOSS_STRICT','ICI_COLITIS_EPITHELIAL_UP_NON_IFN','CURATED_IFN_VISIBILITY']:
        row=tn[tn.module.eq(m)].iloc[0];claim(30,m+' NES',row.NES,'.3f','original GSEA: TNFSF12 / TA')
    row=tn[tn.module.eq('ICI_COLITIS_EPITHELIAL_LOSS_STRICT')].iloc[0]
    for key in ['pval','padj','screen_padj']:claim(30,'loss '+key,row[key],'.4f','original GSEA: TNFSF12 / TA / disease-depleted')
    claim(30,'IBD2 across-celltype median',findings['IBD2_across_celltype_median'],'.2f','celltype_module_effects: TNFSF12 / IBD2 / perturbation_vs_cytomix')
    for key in ['core_gene_count','core_members_padj_le_0_05']:claim(32,key,findings[key],'d','reciprocity_core_gene_evidence')
    hall=st(47);hall=hall[hall.perturbation.eq('TNFSF12')]
    for path,fmt in [('HALLMARK_IL2_STAT5_SIGNALING','.4f'),('HALLMARK_INFLAMMATORY_RESPONSE','.4f'),('HALLMARK_IL6_JAK_STAT3_SIGNALING','.4f'),('HALLMARK_INTERFERON_ALPHA_RESPONSE','.5f')]:
        row=hall[hall.pathway.eq(path)].iloc[0];claim(31,path+' NES',row.NES,'.2f','Table S47');claim(31,path+' FDR',row.padj,fmt,'Table S47')
    sor=st(43);sor=sor[sor.gene.eq('SORL1')].iloc[0]
    for col,fmt in [('organoid_log2FC','.3f'),('organoid_fdr','.3f'),('independent_median_logFC','.3f'),('spatial_logFC','.3f')]:claim(36,'SORL1 '+col,sor[col],fmt,'Table S43')
    g=st(35);g=g[g.analysis.eq('colon_CPI_colitis_vs_HC_patient_level')]
    for m,fmts in [('expanded_cell_fraction_ge2',('.3f','.3f')),('normalized_clonality',('.4f','.5f')),('cross_cd4_cd8_cell_fraction',('.3f','.4f'))]:
        row=g[g.metric.eq(m)].iloc[0]
        for col,fmt in [('median_group1',fmts[0]),('median_group0',fmts[1]),('p','.4f'),('fdr_within_analysis','.4f')]:claim(38,m+' '+col,row[col],fmt,'Table S35')
    cr=st(37);row=cr[cr.tcr_metric.eq('cross_cd4_cd8_cell_fraction')&cr.epithelial_module.eq('ICI_COLITIS_EPITHELIAL_LOSS_STRICT')].iloc[0]
    for col in ['spearman_rho','p','fdr']:claim(39,'TCR '+col,row[col],'.3f','Table S37')
    a=st(56);a=a[a.dataset.eq('GSE206300')]
    for m,fmts in [('CURATED_IFN_VISIBILITY',('.3f','.3f')),('ICI_COLITIS_EPITHELIAL_LOSS_STRICT',('.2f','.2f'))]:
        b=a[a.module.eq(m)]
        claim(28,m+' AUC min',b.auc_disease_higher.min(),fmts[0],'Table S56')
        claim(28,m+' AUC max',b.auc_disease_higher.max(),fmts[1],'Table S56')
    a=st(56);a=a[a.dataset.eq('GSE210037')&a.module.isin(sizes.index)]
    claim(28,'Platform AUC min',a.auc_disease_higher.min(),'.3f','Table S56')
    claim(28,'Platform AUC max',a.auc_disease_higher.max(),'.3f','Table S56')
    save(pd.DataFrame(claims),O/'review/manuscript_numerical_claim_checks.tsv')
    # Do not mistake read-only citation lookup for a pinned source-code download.
    srcdir=O/'review/organoid_public_sources';srcdir.mkdir(exist_ok=True)
    p=srcdir/'source_manifest.json';failed=srcdir/'source_manifest.failed_download_attempt.json'
    if p.exists() and not failed.exists():shutil.copy2(p,failed)
    source_records=[{'url':'https://www.nature.com/articles/s41467-025-68247-6','mirror':'https://pmc.ncbi.nlm.nih.gov/articles/PMC12891662/','access_date_utc':'2026-09-13','access_method':'web browser tool; successful Methods read earlier in this task; subsequent requests intermittently blocked','role':'source Methods','commit':None,'downloaded_file_sha256':None},
     {'url':'https://raw.githubusercontent.com/Genentech/secretome_dictionary/3c80f66552d9c3ea344ba02304eb588b717e9ed8/Capeling_Figure_4_Code.Rmd','access_date_utc':'2026-09-13','access_method':'Actual HTTPS download after restoring child environment; local file inspected','role':'illustrative public DE code; exact publisher-export correspondence unresolved','commit':'3c80f66552d9c3ea344ba02304eb588b717e9ed8','downloaded_file_sha256':sha(O/'new_data/Capeling_Figure_4_Code_pinned.Rmd'),'local_path':'new_data/Capeling_Figure_4_Code_pinned.Rmd'}]
    p.write_text(json.dumps(source_records,indent=2),encoding='utf-8')
    if not all(c['status']=='PASS' for c in claims):
        print(pd.DataFrame(claims).query("status == 'FAIL'").to_string(index=False));sys.exit(1)
    print(f'Prepared {len(index)} numbered tables; {len(claims)} critical numerical claims PASS. Original tables archived unchanged.')
if __name__=='__main__':main()
