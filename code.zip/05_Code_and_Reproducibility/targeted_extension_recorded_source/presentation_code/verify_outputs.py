"""Verify the paired DOCX and saved figure data; no statistical fitting."""
from pathlib import Path
from zipfile import ZipFile
from lxml import etree as E
from PIL import Image
import pandas as pd,numpy as np
import json,hashlib,math,re,subprocess,sys
from datetime import datetime,timezone
O=Path(__file__).resolve().parents[1];S=Path(r'E:\ICI_irAE_Original_Project')
sys.stdout.reconfigure(encoding='utf-8')
NS={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
Q=lambda x:'{'+NS['w']+'}'+x
checks=[]
def check(name,ok,detail=''):
    checks.append({'check':name,'status':'PASS' if bool(ok) else 'FAIL','detail':str(detail)})
def sha(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
    return h.hexdigest()
def rd(p):return pd.read_csv(p,sep='\t',low_memory=False,float_precision='round_trip')
def panel(k):return rd(O/'source_data/panel_sources'/f'{k}.tsv')
def txt(e):return ''.join(e.xpath('.//w:t/text()',namespaces=NS))
def eq(a,b):
    if pd.isna(a) or pd.isna(b):return bool(pd.isna(a) and pd.isna(b))
    return math.isclose(float(a),float(b),rel_tol=2e-12,abs_tol=1e-300)
def main():
    (O/'review/render').mkdir(exist_ok=True)
    zips={k:ZipFile(S/'manuscript.docx' if k=='original' else O/'manuscript'/f'manuscript_V1_revised_{k}.docx') for k in ['original','RED','CLEAN']}
    xml={k:E.fromstring(z.read('word/document.xml')) for k,z in zips.items()}
    for k in ['RED','CLEAN']:
        check(f'{k}_zip_integrity',zips[k].testzip() is None)
        check(f'{k}_all_other_package_parts_unchanged',set(zips[k].namelist())==set(zips['original'].namelist()) and all(zips[k].read(n)==zips['original'].read(n) for n in zips[k].namelist() if n!='word/document.xml'))
        for tag in ['instrText','fldChar','bookmarkStart','bookmarkEnd','footnoteReference','commentRangeStart','commentRangeEnd','ins','del','tbl']:
            a=xml['original'].xpath('.//w:'+tag,namespaces=NS);b=xml[k].xpath('.//w:'+tag,namespaces=NS)
            check(k+'_'+tag+'_preserved',[E.tostring(e,method='c14n') for e in a]==[E.tostring(e,method='c14n') for e in b],f'{len(a)} original / {len(b)} revised')
    red=xml['RED'];deleted=red.xpath('.//w:r[@w:rsidR="A11D0001"]',namespaces=NS);added=red.xpath('.//w:r[@w:rsidR="A11A0001"]',namespaces=NS)
    check('real_red_font',len(added)>0 and len(deleted)>0 and all(e.xpath('./w:rPr/w:color/@w:val',namespaces=NS)==['FF0000'] for e in added+deleted),f'{len(deleted)} deletion runs / {len(added)} addition runs')
    check('red_deleted_text_has_strikethrough',all(e.xpath('./w:rPr/w:strike/@w:val',namespaces=NS)==['true'] for e in deleted))
    check('clean_has_no_revision_markers',not xml['CLEAN'].xpath('.//w:r[starts-with(@w:rsidR,"A11")]',namespaces=NS))
    check('clean_has_no_added_red_color',len(xml['CLEAN'].xpath('.//w:color[@w:val="FF0000"]',namespaces=NS))==len(xml['original'].xpath('.//w:color[@w:val="FF0000"]',namespaces=NS)))
    for e in deleted:e.getparent().remove(e)
    for part in ['body']:
        check('accepted_red_equals_clean_entire_'+part,txt(red.find(Q(part)))==txt(xml['CLEAN'].find(Q(part))))
    records=json.loads((O/'review/manuscript_change_record.json').read_text(encoding='utf-8'))['paragraphs']
    ps={k:tree.xpath('//w:body/w:p',namespaces=NS) for k,tree in xml.items()}
    for i,row in enumerate(records):
        check(row['id']+'_desired_text',txt(ps['CLEAN'][i])==row['revised'])
        if row['original']==row['revised']:
            baseline_index=int(row['id'].replace('V1P',''))-1
            check(row['id']+'_unchanged_format',[E.tostring(ps[k][i],method='c14n') for k in ['RED','CLEAN']]==[E.tostring(ps['original'][baseline_index],method='c14n')]*2)
    # Every unchanged original estimate and missing value in every panel file.
    cache={};values=[];unmapped=[]
    for f in sorted((O/'source_data/panel_sources').glob('*.tsv')):
        d=rd(f)
        if '.source_file' not in d:
            unmapped.append(f.stem);continue
        for src,b in d.groupby('.source_file'):
            if src not in cache:cache[src]=rd(S/src)
            orig=cache[src]
            if f.stem=='F4C_DONOR':
                selected=orig[orig.ligand.eq('TNFSF12') & orig.module.eq('ICI_COLITIS_EPITHELIAL_LOSS_STRICT')]
                wide=selected.pivot(index=['celltype','donor'],columns='treatment',values='raw_mean_rank')
                for _,r in b.iterrows():
                    a=wide.loc[(r.celltype,r.donor)]
                    check('F4C_DONOR_'+r.celltype+'_'+r.donor,eq(r.Control,a.Control) and eq(r.Treatment,a.Treatment) and eq(r.change,a.Treatment-a.Control))
                values.append({'panel':f.stem,'source_file':src,'rows':len(b),'numeric_cells_checked':3*len(b),'mismatched_columns':'','status':'PASS'})
                continue
            idx=b['.source_row'].astype(int).to_numpy()-1
            check(f.stem+'_row_keys',np.all(idx>=0) and np.all(idx<len(orig)))
            old=orig.iloc[idx].reset_index(drop=True);b=b.reset_index(drop=True)
            n=0;bad=[]
            for col in old.columns.intersection(b.columns):
                if pd.api.types.is_numeric_dtype(old[col]) and not pd.api.types.is_bool_dtype(old[col]):
                    ok=[eq(a,v) for a,v in zip(old[col],b[col])];n+=len(ok)
                    if not all(ok):bad.append(col)
            if f.stem=='F6A':
                ok=[eq(orig.iloc[int(row['.source_row'])-1][row['metric']],row['value']) for _,row in b.iterrows()]
                n+=len(ok)
                if not all(ok):bad.append('pivoted value')
            values.append({'panel':f.stem,'source_file':src,'rows':len(b),'numeric_cells_checked':n,'mismatched_columns':';'.join(bad),'status':'FAIL' if bad else 'PASS'})
    nums=pd.DataFrame(values);nums.to_csv(O/'review/numerical_fidelity.tsv',sep='\t',index=False)
    check('all_panel_original_numeric_values',nums.status.eq('PASS').all(),f'{nums.numeric_cells_checked.sum()} cells; missing values checked without zero substitution')
    ge=panel('SF7_effects');gchecks=[]
    for _,r in ge.iterrows():
        raw=cache[r['.source_file']].iloc[int(r['.source_row'])-1]
        cols=('organoid_log2FC','organoid_fdr') if r.context=='Organoid TA' else ('spatial_logFC','spatial_fdr') if r.context=='Platform samples' else ('logFC','FDR')
        gchecks.append({'gene':r.gene,'context':r.context,'source':r['.source_file'],'source_row':r['.source_row'],'effect_equal':eq(r.effect,raw[cols[0]]),'FDR_equal':eq(r.q,raw[cols[1]])})
    pd.DataFrame(gchecks).to_csv(O/'review/complete_core_numeric_checks.tsv',sep='\t',index=False)
    check('complete_core_effects_and_FDR_equal_source',all(r['effect_equal'] and r['FDR_equal'] for r in gchecks),len(gchecks))
    defs=rd(next((S/'tables_for_article').glob('Table_S38_*')))
    check('complete_core_membership_not_selected_by_outcome',set(ge.gene)==set(defs.gene) and not ge.duplicated(['gene','context']).any())
    # Explicit checks for derived presentation values and their keys.
    sizes=panel('F3C_sizes');mem=panel('F3C_members');counts=mem.drop_duplicates(['module','gene']).groupby('module').size()
    check('module_sizes_from_saved_members',all(row.n_genes==counts[row.module] for row in sizes.itertuples()))
    for k in ['F3A','SF2']:
        d=panel(k);check(k+'_orientation',np.allclose(d.oriented_NES,np.where(d.expected_direction_in_irAE.eq('down'),-d.NES,d.NES),equal_nan=True))
    d=panel('F4A');check('F4A_display_sign',np.allclose(d.display_suppression,-d.ici_up_non_ifn_median,equal_nan=True))
    d=panel('SF6');check('SF6_display_sign',np.allclose(d.depletion,-d.independent_median_logFC) and np.allclose(d.platform_depletion,-d.spatial_logFC))
    fam=panel('F5C_family');summ=panel('F5C_summary').iloc[0];disp=panel('F5C_display')
    expected={row.celltype:(row.logFC,row.FDR) for row in fam.itertuples()}
    expected.update({'Organoid TA':(summ.organoid_log2FC,summ.organoid_fdr),'Platform samples':(summ.spatial_logFC,summ.spatial_fdr)})
    ns=panel('F5C_DONOR').iloc[0];expected['Organoid TA donor model']=(ns.log2FoldChange,ns.padj)
    check('SORL1_display_family_specific_FDR',all(eq(row.estimate,expected[row.context][0]) and eq(row.q,expected[row.context][1]) for row in disp.itertuples()))
    # Rewrite the supplementary evidence export only, with the exact verified epithelial rows.
    fam.to_csv(O/'source_data/SORL1_family_estimates.tsv',sep='\t',index=False,na_rep='NA')
    check('SORL1_median_saved',eq(fam.logFC.median(),summ.independent_median_logFC))
    check('validation_denominators_match_original',rd(O/'review/validation_denominators.tsv').matches_original.all())
    check('all_fig3_AUC_intervals_valid',((panel('F3B').bootstrap_auc_ci_low<=panel('F3B').auc_disease_higher)&(panel('F3B').auc_disease_higher<=panel('F3B').bootstrap_auc_ci_high)).all())
    # Provenance graph for aggregate display records.
    keys=[]
    for row in sizes.itertuples():
        b=mem[mem.module.eq(row.module)]
        keys.append({'panel':'F3C_sizes','display_key':row.module,'input_panel':'F3C_members','input_key':';'.join((b['.source_file']+':'+b['.source_row'].astype(str)).tolist()),'operation':'distinct gene count'})
    for row in disp.itertuples():
        inpanel='F5C_family' if row.context in set(fam.celltype) else 'F5C_DONOR' if row.context=='Organoid TA donor model' else 'F5C_summary'
        b=fam[fam.celltype.eq(row.context)] if inpanel=='F5C_family' else panel(inpanel)
        keys.append({'panel':'F5C_display','display_key':row.context,'input_panel':inpanel,'input_key':';'.join((b['.source_file']+':'+b['.source_row'].astype(str)).tolist()),'operation':'logFC and its own gene-specific FDR'})
    pd.DataFrame(keys).to_csv(O/'review/aggregate_record_keys.tsv',sep='\t',index=False)
    check('all_aggregate_panels_have_mapping',set(unmapped)<={'F3C_sizes','F5C_display'})
    # Actual file validation: fully decode raster outputs and ask Poppler to parse PDFs.
    dims=rd(O/'review/ALL_figure_dimensions.tsv');formatrows=[]
    pop=Path(r'C:\Users\frede\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\poppler\Library\bin\pdfinfo.exe')
    for row in dims.itertuples():
        base=O/row.base_path
        for ext in ['.tiff','_preview.png']:
            p=Path(str(base)+ext)
            with Image.open(p) as im:
                im.load();size=im.size;dpi=im.info.get('dpi',(0,0))
                target=600 if ext=='.tiff' else 200
                good=all(abs(a-b)<= (0 if ext=='.tiff' else 1) for a,b in zip(size,(round(row.width_in*target),round(row.height_in*target))))
                if ext=='.tiff':good=good and all(abs(x-600)<.1 for x in dpi)
                check(row.figure+ext+'_decoded_dimensions',good,f'{size}, dpi={dpi}')
                formatrows.append({'file':str(p.relative_to(O)),'width_px':size[0],'height_px':size[1],'dpi_x':dpi[0],'dpi_y':dpi[1],'status':'PASS' if good else 'FAIL'})
        proc=subprocess.run([str(pop),str(base)+'.pdf'],capture_output=True)
        (O/'review/render'/(row.figure+'_pdfinfo.raw.txt')).write_bytes(proc.stdout+b'\n'+proc.stderr)
        check(row.figure+'_PDF_parsed',proc.returncode==0 and bool(re.search(rb'Pages:\s+1\b',proc.stdout)),f'exit={proc.returncode}; original output bytes retained')
    pd.DataFrame(formatrows).to_csv(O/'review/figure_format_verification.tsv',sep='\t',index=False)
    check('six_main_all_supplementary',len(dims)==31 and dims.figure.str.startswith('Figure_').sum()==6)
    before=rd(O/'review/input_manifest_before.tsv');after=[]
    for row in before.itertuples():
        p=Path(row.path);h=sha(p);after.append({'path':str(p),'size_before':row.size,'size_after':p.stat().st_size,'sha256_before':row.sha256_before,'sha256_after':h,'status':'PASS' if h==row.sha256_before and row.size==p.stat().st_size else 'FAIL'})
    pd.DataFrame(after).to_csv(O/'review/input_hash_comparison.tsv',sep='\t',index=False)
    check('source_inputs_unchanged',all(r['status']=='PASS' for r in after),len(after))
    more=[]
    known={str(Path(p)).lower() for p in before.path}
    for src in cache:
        p=S/src
        if str(p).lower() not in known:more.append({'path':str(p),'size':p.stat().st_size,'sha256':sha(p),'recording_scope':'post-read supplementary inventory; no pre-use hash available; no writes performed'})
    pd.DataFrame(more,columns=['path','size','sha256','recording_scope']).to_csv(O/'review/additional_read_inputs.tsv',sep='\t',index=False)
    result={'performed_utc':datetime.now(timezone.utc).isoformat(),'scope':'structural, table-value and artifact-format checks only; not scientific validation or visual Word review','overall':'PASS' if all(c['status']=='PASS' for c in checks) else 'FAIL','checks':checks,'numeric_cells_checked':int(nums.numeric_cells_checked.sum()),'source_files_pre_post_compared':len(after),'red_added_runs':len(added),'red_deleted_runs':len(deleted)}
    (O/'review/output_verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    pd.DataFrame(checks).to_csv(O/'review/output_verification.tsv',sep='\t',index=False)
    print(json.dumps({k:v for k,v in result.items() if k!='checks'},ensure_ascii=False))
    if result['overall']!='PASS':
        print(pd.DataFrame(checks).query("status == 'FAIL'").to_string(index=False));sys.exit(1)
if __name__=='__main__':main()
