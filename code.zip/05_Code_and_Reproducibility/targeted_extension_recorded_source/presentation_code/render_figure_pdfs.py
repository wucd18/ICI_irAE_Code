from pathlib import Path
import subprocess,json
from lxml import etree as E
import pandas as pd
O=Path(__file__).resolve().parents[1];bin=Path(r'C:\Users\frede\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\poppler\Library\bin')
records=[]
for p in sorted([*(O/'figures').glob('*.pdf'),*(O/'supplementary').glob('*.pdf'),*(O/'spatial_extension/figures').glob('*.pdf'),*(O/'xenium_extension/figures').glob('*.pdf')]):
    dest=O/'review/render'/(p.stem+'_from_PDF')
    a=subprocess.run([str(bin/'pdftoppm.exe'),'-r','120','-singlefile','-png',str(p),str(dest)],capture_output=True,text=True)
    assert a.returncode==0,(p,a.stderr)
    records.append({'figure':p.stem,'PDF_render_exit_code':a.returncode,'rendered_png':str(dest)+'.png','automatic_text_bounds':'NOT_CHECKED; pdftotext unavailable','status':'RENDER_PASS; VISUAL_REVIEW_SEPARATE'})
pd.DataFrame(records).to_csv(O/'review/PDF_render_checks.tsv',sep='\t',index=False)
print(json.dumps(records))
