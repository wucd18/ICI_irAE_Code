from pathlib import Path
import subprocess,hashlib,json
from pypdf import PdfReader
O=Path(__file__).resolve().parents[1]
exe=Path(r'C:\Users\frede\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\poppler\Library\bin\pdftoppm.exe')
records=[]
previous=json.loads((O/"review/word_page_manifest_reviewed_before_caption.json").read_text()) if (O/"review/word_page_manifest_reviewed_before_caption.json").exists() else []
reviewed={(z["docx"],z["page"]):z["sha256"] for z in previous}
for tag in ['CLEAN','RED']:
 folder=O/'review/render'/tag;pdf=folder/f'manuscript_V1_revised_{tag}.pdf'
 q=subprocess.run([str(exe),'-r','110','-png',str(pdf),str(folder/'release-page')],capture_output=True,text=True)
 assert q.returncode==0,(q.returncode,q.stderr)
 pages=PdfReader(pdf).pages
 for i,page in enumerate(pages,1):
  p=folder/f'release-page-{i:02d}.png';assert p.exists()
  digest=hashlib.sha256(p.read_bytes()).hexdigest();old=folder/f'final-page-{i:02d}.png'
  same=reviewed.get((tag,i))==digest if reviewed else old.exists() and hashlib.sha256(old.read_bytes()).hexdigest()==digest
  records.append({'docx':tag,'page':i,'png':str(p),'sha256':digest,'identical_to_previously_visually_reviewed_page':same,'render_exit':q.returncode,'characters':len(page.extract_text())})
(O/'review/final_word_page_manifest.json').write_text(json.dumps(records,indent=2));print(json.dumps({'pages':len(records),'unchanged_pixels':sum(r['identical_to_previously_visually_reviewed_page'] for r in records),'changed_pages':[(r['docx'],r['page']) for r in records if not r['identical_to_previously_visually_reviewed_page']]}))
