"""Minimal OOXML run edits from the unique V1 Word; visual redline, not Track Changes."""
from pathlib import Path
from zipfile import ZipFile
from lxml import etree as E
from copy import deepcopy
import json,re,sys,difflib,csv
import pandas as pd
O=Path(__file__).resolve().parents[1]; S=Path(r'E:\ICI_irAE_Original_Project')
W='http://schemas.openxmlformats.org/wordprocessingml/2006/main';NS={'w':W};Q=lambda x:'{'+W+'}'+x
def text(p):return ''.join(p.xpath('.//w:t/text()',namespaces=NS))
def newrun(template,s,kind=''):
    r=E.Element(Q('r'),attrib=dict(template.attrib))
    rp=template.find(Q('rPr'))
    if rp is not None:r.append(deepcopy(rp))
    if kind:
        r.set(Q('rsidR'),'A11D0001' if kind=='del' else 'A11A0001')
        rp=r.find(Q('rPr'))
        if rp is None:rp=E.SubElement(r,Q('rPr'))
        for c in list(rp):
            if c.tag==Q('color') or (kind=='del' and c.tag==Q('strike')):rp.remove(c)
        E.SubElement(rp,Q('color')).set(Q('val'),'FF0000')
        if kind=='del':E.SubElement(rp,Q('strike')).set(Q('val'),'true')
    t=E.SubElement(r,Q('t'));t.set('{http://www.w3.org/XML/1998/namespace}space','preserve');t.text=s
    return r
def splice(p,a,b,insert,red):
    runs=[];offset=0
    for r in p.xpath('.//w:r',namespaces=NS):
        s=''.join(r.xpath('./w:t/text()',namespaces=NS))
        if s:runs.append((r,offset,offset+len(s),s));offset+=len(s)
    if a==b:
        if not runs and a==0:
            p.append(newrun(E.Element(Q('r')),insert,'add' if red else ''))
            return
        # Prefer the preceding textual run at an insertion boundary.
        candidates=[v for v in runs if v[1]<a<=v[2]] or [v for v in runs if v[1]<=a<v[2]]
        if not candidates:raise ValueError('No insertion anchor')
        r,st,en,s=candidates[-1];k=a-st
        if any(c.tag not in {Q('rPr'),Q('t')} for c in r):raise ValueError('Complex insertion run')
        repl=[newrun(r,s[:k]),newrun(r,insert,'add' if red else ''),newrun(r,s[k:])]
        parent=r.getparent();idx=parent.index(r);parent.remove(r)
        for x in reversed(repl):
            if text(x):parent.insert(idx,x)
        return
    selected=[v for v in runs if v[1]<b and v[2]>a]
    if not selected:raise ValueError('Missing replacement range')
    for k,(r,st,en,s) in enumerate(selected):
        if any(c.tag not in {Q('rPr'),Q('t')} for c in r):raise ValueError('Edit touches a complex run')
        lo=max(a-st,0);hi=min(b-st,len(s));repl=[]
        if lo:repl.append(newrun(r,s[:lo]))
        if red:repl.append(newrun(r,s[lo:hi],'del'))
        if k==len(selected)-1 and insert:repl.append(newrun(r,insert,'add' if red else ''))
        if hi<len(s):repl.append(newrun(r,s[hi:]))
        parent=r.getparent();idx=parent.index(r);parent.remove(r)
        for x in reversed(repl):parent.insert(idx,x)
def diffops(old,new):
    tok=lambda s:re.findall(r'\w+|\s+|[^\w\s]',s)
    a=tok(old);b=tok(new);offset=[0]
    for s in a:offset.append(offset[-1]+len(s))
    return [(offset[i],offset[j],''.join(b[k:l])) for op,i,j,k,l in difflib.SequenceMatcher(None,a,b,autojunk=False).get_opcodes() if op!='equal']
def accepted(p):
    c=deepcopy(p)
    for r in c.xpath('.//w:r',namespaces=NS):
        if r.get(Q('rsidR'),'').startswith('A11D'):r.getparent().remove(r)
    return text(c)
def fixture_tests():
    empty=E.Element(Q('p'));splice(empty,0,0,'New reference',True)
    assert accepted(empty)=='New reference'
    p=E.fromstring(f'<w:p xmlns:w="{W}"><w:bookmarkStart w:id="0" w:name="anchor"/><w:r><w:rPr><w:i/></w:rPr><w:t>Alpha 12 beta </w:t></w:r><w:r><w:rPr><w:vertAlign w:val="superscript"/></w:rPr><w:t>ref</w:t></w:r><w:bookmarkEnd w:id="0"/></w:p>')
    old=text(p);new='Alpha 13 updated beta ref'
    rr=deepcopy(p);cc=deepcopy(p)
    for a,b,s in reversed(diffops(old,new)):splice(rr,a,b,s,True);splice(cc,a,b,s,False)
    assert accepted(rr)==text(cc)==new
    assert len(rr.xpath('.//w:bookmarkStart',namespaces=NS))==1
    assert len(rr.xpath('.//w:vertAlign',namespaces=NS))==1
    assert len(rr.xpath('.//w:i',namespaces=NS))>=1
    assert all(r.find(Q('rPr')).find(Q('color')).get(Q('val'))=='FF0000' for r in rr.xpath('.//w:r',namespaces=NS) if r.get(Q('rsidR'),'').startswith('A11'))
    print('PASS: word/phrase replacement, red deletions, accepted-text equivalence, italic, superscript and bookmark fixtures.')
def main():
    sys.stdout.reconfigure(encoding='utf-8')
    if '--test' in sys.argv:fixture_tests();return
    base=S/'manuscript.docx'
    with ZipFile(base) as z:parts={i.filename:(i,z.read(i.filename)) for i in z.infolist()}
    xml=E.fromstring(parts['word/document.xml'][1]);pars=xml.xpath('//w:body/w:p',namespaces=NS)
    orig={f'V1P{i+1:03d}':text(p) for i,p in enumerate(pars)};desired=dict(orig);ledger=[]
    findings=json.loads((O/'review/local_findings.json').read_text(encoding='utf-8'))
    def replace(pid,old,new,reason,source,cat='A'):
        pid=f'V1P{pid:03d}';assert desired[pid].count(old)==1,(pid,old)
        desired[pid]=desired[pid].replace(old,new)
        ledger.append({'id':pid,'old_text':old,'new_text':new,'category':cat,'reason_CN':reason,'source':source,'numerical_change':bool(re.findall(r'\d+(?:\.\d+)?',old)!=re.findall(r'\d+(?:\.\d+)?',new))})
    def append(pid,s,reason,source):
        key=f'V1P{pid:03d}';desired[key]+=s;ledger.append({'id':key,'old_text':'','new_text':s,'category':'A','reason_CN':reason,'source':source,'numerical_change':bool(re.search(r'\d',s))})
    def st(n):return pd.read_csv(next((S/'tables_for_article').glob(f'Table_S{n}_*')),sep='\t')
    q=next(d for d in findings['TNFSF12_gsea'] if d['module']=='ICI_COLITIS_EPITHELIAL_LOSS_STRICT')
    replace(2,'receiver-cell dysfunction','receiver-cell remodelling','避免将转录程序称为实测功能障碍','V1 transcriptomic study design')
    for p in [8,9]:replace(p,'tissue-receiver dysfunction','receiver-cell remodelling','统一受体侧转录术语','V1 patient-level pathway results')
    replace(8,'apparent epithelial restoration signals','apparent transcriptional-restoration signals','准确限定转录层证据','V1 programme analysis')
    replace(8,'identified TNFSF12 as an apparent transcriptional-restoration perturbation','suggested an apparent TNFSF12 transcriptional-restoration signal without screen-adjusted FDR support for the disease-depleted set','方向提名与FDR分开','02_results/GSE313368_irAE_module_GSEA_all.tsv.gz')
    replace(8,'Its response defined a 66-gene epithelial reciprocity core and suppressed one disease-associated inflammatory subset.','Its positive enrichment leading edge defined a 66-gene epithelial reciprocity core; a separate TNFSF12-down signature showed reciprocal enrichment in disease.','按真实leading edge来源命名；避免将炎症抑制归因于core','00_scripts/run_icb_efficacy_guardrail.R:383-394; Table_S49')
    rho=st(54).iloc[0].spearman_rho
    replace(8,'rho=-0.014',f'rho={rho:.4f}','摘要与Results统一按原保存rho四位小数展示','Table_S54','B')
    spot=re.search(r'comprising ([\d,]+) spots',orig['V1P017']).group(1)
    replace(17,spot,format(findings['spatial_colon_spots'],','),'从15个结肠样本n_spots确定性求和纠正总数','02_results/GSE210037_spatial_pseudobulk_metadata.tsv','B')
    replace(17,'under a locked analysis plan','under a documented analysis plan','本地未提供可核实时间戳预注册证据','Table_S2 + source code; no verified preregistration chronology')
    replace(18,'passed audit','were retained after the table-integrity audit','哈希与完整提取验证不等于统计适用性已通过','review/organoid_sheet_audit.tsv')
    replace(26,'an orthogonal reference','a reference','去除IFN成员不代表统计独立','00_scripts/derive_and_validate_irAE_modules.R')
    append(26,' Gene-set subtraction does not establish statistical independence from interferon signalling.','区分集合去交集和统计独立','Table_S21 frozen definitions')
    replace(30,'Seven ligands first met the transcriptional-restoration requirement by shifting the disease-depleted epithelial module toward the control direction across eligible epithelial contexts. A stricter favourable-module gate then required multicell-type improvement of the atlas IBD2 differentiation/metabolic program, preservation of the predefined IFN-visibility program, and non-aggravation of the non-IFN disease residual, atlas-derived gene program 20 (GP20), and IBD1','Seven ligands met the initial directional requirement for the disease-depleted epithelial module together with the atlas IBD2 criterion. The stricter module gate then required absence of strong suppression of the predefined IFN-visibility programme or atlas-derived gene programme 20 (GP20), and absence of strong aggravation of the non-IFN disease residual or IBD1','忠实描述实际门控顺序；不把未检出强下降称为功能保留','00_scripts/screen_GSE313368_irAE_rescue.R')
    replace(30,'(Fig. 4a)','(Fig. 4a-c)','同步新增连续效应panel','presentation_code/plot_v1.R')
    replace(30,'(NES=1.335)',f"(NES={q['NES']:.3f}; nominal P={q['pval']:.4f}, within-contrast FDR={q['padj']:.4f}, screen-adjusted FDR={q['screen_padj']:.4f})",'保留NES并补足原始P和两种FDR；不新增0.10阈值','GSE313368_irAE_module_GSEA_all.tsv.gz: TNFSF12 / Transit_Amplifying / ICI_COLITIS_EPITHELIAL_LOSS_STRICT')
    replace(30,"median donor-level Cohen's d","median of four published cell-type Cohen's d estimates",'2.58为跨细胞类型中位数，非本研究供者估计','02_results/GSE313368_celltype_module_effects.tsv.gz','B')
    append(30,' The directional nomination did not require screen-adjusted significance, and the disease-depleted set did not meet FDR<0.05. Absence of detected suppression of the curated IFN set does not establish preserved immune function.','不得把提名门槛和功能保留混为一谈','00_scripts/screen_GSE313368_irAE_rescue.R')
    replace(31,'Fig. 4b','Fig. 4d','同步图号','presentation_code/plot_v1.R')
    replace(32,'Twenty-five genes downregulated by TNFSF12, including CXCL2, LCN2 and IFITM3, were increased in disease','The 25-gene TNFSF12-down set, including CXCL2, LCN2 and IFITM3, was enriched in disease','集合GSEA不等于每个基因单独显著','Table_S49 + Table_S25')
    replace(32,'as genes induced by TNFSF12 but depleted in the discovery disease state','as the positive leading-edge subset of the frozen disease-depleted epithelial module in the TNFSF12 transit-amplifying-cell GSEA','按实际代码纠正集合定义','00_scripts/run_icb_efficacy_guardrail.R:383-394')
    replace(32,'a more stringent 66-gene','a 66-gene','leading edge不是更严格的单基因显著性筛选','00_scripts/run_icb_efficacy_guardrail.R:383-394')
    replace(32,'The reproducible biological object supported by the data is the downstream epithelial reciprocity core, not the TNFSF12 response as a whole.','This transfer supports the reproducibility of the frozen core as an epithelial transcriptional pattern, while its perturbational interpretation remains conditional on the published organoid estimates.','区分可独立核验的转移和来源尚未闭合的扰动解释','Table_S49; review/organoid_evidence_resolution.md')
    replace(32,'Fig. 4c','Fig. 4e','同步图号','presentation_code/plot_v1.R')
    append(32,f" All {findings['core_gene_count']} members had positive published TNFSF12 log2 fold changes, but only {findings['core_members_padj_le_0_05']} met gene-level FDR<0.05. The discovery-cohort reciprocity check was not counted as independent validation.",'说明leading edge成员单基因支持程度；分开自检和外部验证','review/reciprocity_core_gene_evidence.tsv; Table_S49')
    replace(34,'(Fig. 5b)','(Table S59)','原门控矩阵移至完整底表保留','Figure_5 revised panels')
    append(35,' Figure 5a,b displays all original GENE, AXIS and SIGNATURE meta-estimates in separate groups, rather than choosing a different worst feature for each ligand. Axis-level significance is not attributed to the ligand gene.','统一展示全部原特征；披露展示类别变化','Table_S25; Table_S27; Table_S29; original make_manuscript_figures.R')
    append(36,' None of the four family-specific SORL1 comparisons met FDR<0.05; the cross-family median is a descriptive effect summary, not a pooled significance test. These same tissue results informed downstream ranking and are not a new independent target validation.','保留SORL1讨论并明确原家族FDR和筛选后证据边界','source_data/SORL1_family_estimates.tsv; Table_S43')
    append(39,' This TCR analysis used the raw mean within-sample expression rank: a higher score indicates higher relative expression of the disease-depleted programme, not greater injury. No fitted trend or confidence band is shown.','核对原始表达秩方向并去除旧图新增拟合','00_scripts/analyze_TCR_evidence.py:305-325')
    replace(42,'receiver-side dysfunction','receiver-cell remodelling','避免未测量功能结论','Study measurement scope')
    append(49,' The organoid enrichment estimates are conditional on the exported gene background. Exact correspondence between the publisher tables and the donor adjustment described in the source Methods remains insufficiently documented; this limits a definitive interpretation of the disease-perturbation link.','限定准确的类器官证据缺口，不推倒其余研究','review/organoid_evidence_resolution.md')
    replace(53,'No new participants were enrolled, and no new institutional approval was required for this secondary analysis of publicly available data.','No new participants were enrolled. Institutional requirements for this secondary analysis of public data should be confirmed by the submitting group.','未提供本单位伦理判定，不编造无需批准的法律事实','USER_PENDING institutional confirmation')
    replace(56,'Source URLs, access dates, file sizes and SHA-256 hashes are recorded in Table S10.','Available source URLs, local timestamps, file sizes and SHA-256 hashes are recorded in Table S10; entries marked local_or_unmapped do not establish the original download URL or access date.','下载清单中存在local_or_unmapped，不能冒称所有来源已完整','Table_S10')
    replace(60,'at least one FDR-significant compartment result supporting the difference','at least one FDR-significant compartment result in each organ, without requiring its direction to agree with that organ median','准确描述原分类而不使用后续版本规则','00_scripts/analyze_cross_organ_receiver_programs.py:73-88')
    replace(62,'The effect-size and false-discovery criteria were fixed in the discovery analysis.','The saved discovery flags implement FDR<=0.05 and |log2 fold change|>=log2(1.25). The frozen members match these flags; the 0.5 value in the original module-table description was a documentation error.','原配置及逐基因标记一致，仅纠正文档','project_config.R; patient_level_pseudobulk_DE_all.tsv.gz; Table_S21','B')
    replace(67,'Associations between TCR metrics and epithelial module scores used Spearman correlation','Associations between TCR metrics and raw mean within-sample epithelial expression-rank scores used Spearman correlation','区分TCR原始秩与AUC反向评分','00_scripts/analyze_TCR_evidence.py')
    replace(70,'Published donor-aggregated IBD1, IBD2 and gene-program effect sizes provided orthogonal context.','Published IBD1, IBD2 and gene-program cell-type effect sizes provided separate context; each estimate was calculated by the source authors from donor/well summaries.','已发表供者聚合结果与本研究跨细胞类型汇总分开','MOESM14; Capeling et al. Methods')
    replace(70,'The initial transcriptional-restoration requirement was concordant movement of the disease-depleted module toward the control direction across eligible epithelial contexts. Seven ligands met this criterion. A stricter favourable-module gate additionally required multicell-type improvement of the atlas IBD2 differentiation/metabolic program, preservation of the curated IFN-visibility program, and non-aggravation of the non-IFN disease residual, atlas-derived gene program 20 (GP20), and IBD1.','The original directional gate combined positive disease-depleted-module NES in every evaluable cell type with four available IBD2 cell-type effects, at least two positive effects and a positive median. The stricter gate excluded median IFN NES or GP20 effect below -1 and non-IFN residual NES or IBD1 effect above 1. These were descriptive selection rules and did not require screen-adjusted FDR significance.','按原代码完整描述门槛，不修改任何阈值','00_scripts/screen_GSE313368_irAE_rescue.R')
    append(70,' GSEA used all retained finite published log2FoldChange/lfcSE values with positive lfcSE after the original minimum-1000-gene eligibility check; it did not apply the later signature padj filter. This ratio is a supplied effect-to-uncertainty ranking score and is not assumed to be the unshrunken Wald statistic. The public example uses ashr shrinkage and removes rows with missing padj, but does not uniquely establish the exact export and model used for every published sheet. Within-contrast padj and BH screen_padj across perturbations within each cell type and module are reported separately.','一次定点核查限定输入背景、排序量与校正族','original screen script; public Capeling_Figure_4_Code.Rmd; review/organoid_evidence_resolution.md')
    replace(72,'TNFSF12-up and TNFSF12-down signatures were defined from significant organoid differential-expression results.','TNFSF12-up and TNFSF12-down signatures retained genes with publisher padj<=0.10, ranked by signed log2FoldChange/lfcSE and capped at 75 per direction; the saved sets contain 75 up and 25 down genes. This signature filter was applied after the separate programme GSEA input construction.','准确披露后续签名筛选，不混淆GSEA背景','00_scripts/run_icb_efficacy_guardrail.R:357-393')
    replace(72,'the intersection of genes induced by TNFSF12 in organoids and genes depleted in discovery ICI-colitis epithelium','the saved positive leading edge of the frozen disease-depleted epithelial module after TNFSF12 perturbation in transit-amplifying cells','修复错误的66基因选择说明','Table_S25; GSE313368_irAE_module_GSEA_all.tsv.gz')
    replace(78,'All analysis scripts, fixed inputs, intermediate results, manuscript-facing tables and figures are included in the project package.','The original analysis scripts and statistical results remain in the unchanged source project. The accompanying revision package contains independent presentation code, panel source data, revised tables, figures and provenance records.','区分原分析项目和本次展示包','RUN_PRESENTATION_ONLY.ps1')
    replace(78,'R 4.2.2 was used for differential expression, enrichment, survival analysis and figure generation.','The original environment record reports R 4.2.2 for the statistical analysis. This presentation revision used R 4.4.1 for figure generation and did not rerun the statistical models.','分开历史统计环境与当前绘图环境','original logs/R_sessionInfo.txt; current presentation_R_sessionInfo.txt')
    replace(78,'The root README fixes the execution order.','RUN_PRESENTATION_ONLY.ps1 specifies the revision execution order.','不引用旧全量入口','RUN_PRESENTATION_ONLY.ps1')
    replace(82,'All scripts required to reproduce the processed results, tables and figures are provided in the accompanying project package. The root README specifies the execution order, and the logs directory contains the environment record and run-level provenance.','Independent code for generating the revised figures and documents from existing results is provided with RUN_PRESENTATION_ONLY.ps1 and execution logs. Original statistical code and results remain in the source project. A permanent public repository and DOI have not yet been specified.','如实描述本轮可复现范围及仓库待填','revision package; USER_PENDING repository')
    append(123,' The workflow spans the page width; dashed TCR and lung branches indicate supportive and source-confounded evidence. The cohort panel keeps donors/patients, cells/nuclei, samples/spots and ligand conditions as distinct units.','更新Figure1布局与单位','plot_v1.R F1')
    replace(125,'Dots denote','Asterisks denote','原标记与图例一致','plot_v1.R F2A')
    replace(125,'Labels show the number of FDR-concordant cell types among four eligible populations.','Points show original NES for each eligible immune population; shapes indicate the original FDR threshold, and labels state the expected disease direction.','用逐细胞类型原始NES代替混淆方向的汇总条形图','Table_S57')
    replace(127,'dots denote','asterisks denote','图例同步','plot_v1.R F3A')
    append(127,' Family order is identical in a and b, with platform samples separated by a rule. Only the disease-depleted NES and score are reversed for disease orientation.','解释方向转换和平台分离','Table_S22; Table_S56')
    replace(129,orig['V1P129'],'a, Saved median disease-depleted-module NES versus negative median non-IFN residual NES across evaluable perturbations; the original nominated ligands are labelled. b, TNFSF12 module NES, with open or filled points indicating screen-adjusted FDR. c, Published TNFSF12 IBD1, IBD2 and GP20 effects in separate Cohen\'s d units, with publisher FDR. Each point in b and c is a cell-type estimate, not an individual donor, and no donor error bars are inferred. d, All originally tested TNFSF12 off-target Hallmark NES values; asterisks indicate original Hallmark FDR<0.05. e, Raw disease NES for the frozen 75-gene up set, 25-gene down set and 66-gene leading-edge epithelial reciprocity core. Discovery self-check, the four families within GSE206300 and GSE210037 platform transfer are separated. Asterisks denote FDR<0.05; NE denotes a missing estimate, distinct from a nonsignificant estimate. The core is a transcriptional construct. Gene-level organoid enrichment is conditional on the exported background and the source-model provenance limitation described in Methods.','完整对应五个连续效应/数值panel，保留疾病—扰动连接','plot_v1.R F4; original source tables')
    replace(131,orig['V1P131'],'a, All original response meta-estimates and 95% confidence intervals, grouped as GENE, AXIS or SIGNATURE. b, Original OS meta-estimates and 95% confidence intervals on a log hazard-ratio axis. Filled points denote the original meta-analysis FDR<0.05. Features are not selected by significance or by the worst effect for each candidate; complete cohort-specific and endpoint results remain in the supplementary tables. c, Original SORL1 log2 fold changes and family-specific FDR values for organoid, independent epithelial and platform contexts. No interval is fabricated for these estimates. d, Endpoint-specific patient coverage; lack of an evaluable endpoint is not evidence of safety. The original candidate decisions remain in Table S59. Clinical expression associations do not establish intervention benefit, harm or safety, and SORL1 remains an exploratory downstream marker.','保留完整原特征，分开GENE AXIS SIGNATURE和家族FDR','Table_S27; Table_S29; Table_S43; original DE; plot_v1.R F5')
    replace(133,'epithelial disease-depleted score','raw mean expression rank of the disease-depleted epithelial programme','原始秩方向准确标注','Table_S36; original TCR source')
    append(133,' Higher raw rank means higher relative programme expression. The scatter uses the original rho, P and FDR without a fitted line or confidence band; all group metrics are dimensionless and use separate y-axis ranges.','去除新增模型图层并说明单位','plot_v1.R F6')
    # Final editorial layer: consolidate changes against the original DOCX,
    # keeping source qualifications where they affect interpretation.
    edits={
      8: [('Human organoid screening suggested an apparent TNFSF12 transcriptional-restoration signal without screen-adjusted FDR support for the disease-depleted set.', 'Projection into human organoid perturbations linked the frozen ICI programme to a TNFSF12 response with opposing epithelial and inflammatory components. Enrichment of the disease-depleted set was directional and did not meet screen-adjusted FDR<0.05.'), ('Its positive enrichment leading edge defined a 66-gene epithelial reciprocity core; a separate TNFSF12-down signature showed reciprocal enrichment in disease.', 'The positive enrichment leading edge defined a 66-gene epithelial reciprocity core that transferred across independent disease contexts; a separate TNFSF12-down signature was enriched in disease.'), ('TNFSF12/Fn14 therefore failed the systemic-advancement criteria used in this framework.', 'These accompanying responses limit the translational interpretation of the favourable epithelial direction.')],
      18: [('were retained after the table-integrity audit','were used for projection of the frozen ICI modules')],
      29: [('A human organoid screen identifies a reproducible TNFSF12-linked epithelial reciprocity core but not a simple ligand rescue','Human organoid perturbation separates a transferable epithelial programme from the broader TNFSF12 response')],
      31: [('The initially favourable profile did not survive the expanded off-target audit.', 'TNFSF12 also altered programmes outside the restricted epithelial modules, revealing a mixed transcriptional response.')],
      32: [('This transfer supports the reproducibility of the frozen core as an epithelial transcriptional pattern, while its perturbational interpretation remains conditional on the published organoid estimates.', 'The disease-associated epithelial pattern therefore recurred after the core was fixed, whereas the broad TNFSF12-up response did not consistently reverse disease. This distinguishes the transferable downstream programme from the upstream perturbation as a whole.'), ('The discovery-cohort reciprocity check was not counted as independent validation.', 'The discovery-cohort reciprocity check was not counted as independent validation. Gene-level effects across the complete core are shown separately from set-level enrichment (Supplementary Fig. 7).')],
      35: [(' Figure 5a,b displays all original GENE, AXIS and SIGNATURE meta-estimates in separate groups, rather than choosing a different worst feature for each ligand. Axis-level significance is not attributed to the ligand gene.', ' Figure 5a,b separates ligand/receptor genes, ligand-receptor axes and perturbation signatures across the complete feature set; their associations describe distinct biological measurements.')],
      39: [(' No fitted trend or confidence band is shown.', '')],
      49: [(' The organoid enrichment estimates are conditional on the exported gene background. Exact correspondence between the publisher tables and the donor adjustment described in the source Methods remains insufficiently documented; this limits a definitive interpretation of the disease-perturbation link.', ' Organoid enrichment is conditional on the released effect estimates and their exported gene background. We did not independently refit the source donor models; the public example does not fully resolve the correspondence to each published DE sheet. This uncertainty concerns the strength of the perturbational inference, rather than the separately estimated external tissue transfer.')],
      62: [('The frozen members match these flags; the 0.5 value in the original module-table description was a documentation error.', 'Module membership was frozen from the discovery results and was not reselected during external transfer.')],
      123: [(' The workflow spans the page width;', ' In the workflow,')],
      129: [('Gene-level organoid enrichment is conditional on the exported background and the source-model provenance limitation described in Methods.', 'Gene-level effects for all core members are provided in Supplementary Fig. 7; set enrichment is not a test that every member is individually significant.')],
    }
    for pid,pairs in edits.items():
        key=f'V1P{pid:03d}'
        for old,new in pairs:
            assert desired[key].count(old)==1,(key,old)
            desired[key]=desired[key].replace(old,new)
        ledger=[row for row in ledger if row['id']!=key]
        ledger.append({'id':key,'old_text':orig[key],'new_text':desired[key],'category':'A/B','reason_CN':'保留已核实观察和必要限制，恢复疾病—扰动论证；合并最终词句差异，移除重复审计语气','source':'original V1 results; original DOCX; source audit; Supplementary Figure 7','numerical_change':bool(re.findall(r'\d+(?:\.\d+)?',orig[key])!=re.findall(r'\d+(?:\.\d+)?',desired[key]))})

    # Add the completed spatial extension using its locked, machine-readable results.
    sx=O/'spatial_extension';stats=pd.read_csv(sx/'source_data/frozen_transfer_results.tsv',sep='\t')
    smeta=pd.read_csv(sx/'source_data/sample_manifest.tsv',sep='\t');sqc=pd.read_csv(sx/'source_data/section_QC.tsv',sep='\t')
    sn=smeta.groupby('condition').patient.nunique();ifn=stats[stats.module.eq('CURATED_IFN_VISIBILITY')].iloc[0]
    non=stats[stats.module.eq('ICI_COLITIS_EPITHELIAL_UP_NON_IFN')].iloc[0];loss=stats[stats.module.eq('ICI_COLITIS_EPITHELIAL_LOSS_STRICT')].iloc[0]
    append(28,f" An additional Oxford spatial cohort [31] contributed {len(smeta)} sections from {smeta.patient.nunique()} donors ({sn['ICI colitis']} ICI-colitis, {sn['Healthy']} healthy and {sn['UC']} UC donors), with {sqc.kept_tissue_spots.sum():,} retained tissue spots. After summing counts within each donor, all four frozen programmes shifted in the expected disease direction. The IFN-visibility score had a median oriented difference of {ifn.median_difference:.4f} (P={ifn.P:.4f}, FDR={ifn.FDR_new_four_module_family:.4f}); the non-IFN residual and disease-depleted scores differed by {non.median_difference:.4f} and {loss.median_difference:.4f}, respectively (both FDR={loss.FDR_new_four_module_family:.4f}). None of the four comparisons met FDR<0.05. These results provide directional support in additional tissue samples, with limited precision (Supplementary Fig. 8; Tables S64-S67). Registered coordinate maps show within-section distributions of the frozen programmes (Supplementary Fig. 9A-F); they do not by themselves identify epithelial-specific states.",'新增实际完成的新队列结果；保留未过FDR结果，不用spot充当供者','spatial_extension/source_data/frozen_transfer_results.tsv; sample_manifest.tsv; section_QC.tsv')
    append(49,' The additional Oxford spatial cohort was directionally concordant but did not meet the four-test FDR threshold. Its small healthy-control group, sex and source-batch imbalance, and whole-tissue cell-composition differences limit the strength of this replication. Registered maps locate transcriptomic scores in tissue but do not resolve epithelial state without independent region annotations.','新增队列实际边界；不将方向一致写作显著验证','spatial_extension/review/analysis_summary.json')
    append(65,' Separately, GSE189184 and the two adult reference sections A1/A2 from GSE158328 were combined according to the original Oxford publication [31] and its patient table. A1/A2 belong to one healthy donor (TIP 346), and B8/B9 to one UC donor (GI 6967). We retained released tissue-labelled spots with positive counts and summed counts across all sections from the same donor before scoring. Frozen module genes were matched through the released symbol aliases to unique Ensembl identifiers in the common feature universe; no genes were reselected. The V1 within-sample mean expression-rank definition was retained, with 1 minus the raw rank for the disease-depleted programme. The primary ICI-colitis versus healthy comparison used the original minimum of three donors per group and two-sided Mann-Whitney tests, with BH correction across the four prespecified module tests in this new cohort. No AUC bootstrap or new differential-expression model was run. UC donors provide separate descriptive context. Spot scores were overlaid on registered H&E images using the released coordinates and scale factors, without spot-level hypothesis tests or module-defined epithelial regions. Additional source histology exclusions and independent region annotations were not available in the downloaded release.','新增分析限定方法及真实单位；沿用冻结定义，公开参考版本对应','spatial_extension/review/analysis_plan_locked.json; gene_mapping_amendment.json')
    append(80,' The additional spatial matrices, coordinates and images are available under GSE189184 and GSE158328; the source patient mapping is provided in Gupta et al. [31], Supplementary Table 1. The candidate package includes accession/member paths, input hashes, frozen gene mappings, patient and spot scores, and the separate extension code.','新增来源与源数据声明','spatial_extension/review/input_manifest_before.tsv')
    append(82,' RUN_SPATIAL_EXTENSION.ps1 separately regenerates the bounded frozen-programme transfer from the downloaded public matrices; the presentation-only entry does not trigger that analysis.','区分呈现与已授权新队列分析入口','RUN_SPATIAL_EXTENSION.ps1')
    append(123,f" The additional spatial extension comprises {len(smeta)} sections from {smeta.patient.nunique()} donors; its patient-level comparisons and registered tissue maps are shown in Supplementary Figures 8 and 9A-F.",'图1纳入新增队列并明确补图位置','spatial_extension/source_data/sample_manifest.tsv')
    append(120,'31. Gupta, T.; Antanaviciute, A.; Hyun-Jung Lee, C.; et al. Tracking in situ checkpoint inhibitor-bound target T cells in patients with checkpoint-induced colitis. Cancer Cell 2024, 42, 797-814.e15. doi:10.1016/j.ccell.2024.04.010.','在原参考文献末尾空段新增准确来源；原30条及其域保留','publisher PDF; DOI 10.1016/j.ccell.2024.04.010')
    xs=json.loads((O/'xenium_extension/review/analysis_summary.json').read_text())
    append(123,f" The separate Xenium measurement includes {xs['included_cells']:,} cells from {xs['patients']} overlapping donor labels (Supplementary Figures 10-12); these donors are not added to the independent validation count.",'图1与Xenium实际患者/细胞单位及补图一致','xenium_extension/review/analysis_summary.json')
    xg=pd.read_csv(O/'xenium_extension/source_data/patient_gene_expression.tsv',sep='\t')
    xcv=pd.read_csv(O/'xenium_extension/source_data/module_coverage.tsv',sep='\t').set_index('module')
    sor=xg[xg.gene.eq('SORL1')&xg.compartment.eq('IEC')].groupby('condition').mean_molecules_per_cell.median()
    loss=xcv.loc['ICI_COLITIS_EPITHELIAL_LOSS_STRICT']
    append(36,f" Targeted single-cell spatial profiling provided a complementary tissue measurement [32]. SORL1 transcripts were observed in annotated epithelium; the patient-median mean abundance was {sor['HC']:.4f} molecules per segmented epithelial cell in healthy controls and {sor['ICI']:.4f} in ICI colitis (Supplementary Fig. 10). The assayed disease-depleted programme also shifted in the expected direction within the annotated epithelial compartment, and registered cell maps placed these measurements in tissue (Supplementary Figs. 11-12; Tables S68-S71). These are descriptive spatial follow-through results: the ICI and healthy donor labels overlap the discovery cohort, and only {int(loss.available)} of {int(loss.requested)} frozen disease-depleted genes were present in the targeted panel. They add cellular localization, not an independent efficacy or causal test.",'以新实测分子和作者细胞注释补上定位证据；保留患者重合与靶向覆盖限制','xenium_extension/source_data/patient_gene_expression.tsv; patient_compartment_scores.tsv; module_coverage.tsv')
    append(65,f" Targeted Xenium data from Dataset 2 of Mennillo et al. [32] were analysed separately using the released raw_counts layer, cell centroids and published compartment annotations. The retained object contributed {xs['included_cells']:,} patient-assigned cells from {xs['patients']} donor labels; {xs['excluded_cells']} unassigned cells were excluded. Counts were summed by patient and compartment before applying the unchanged mean-rank definitions to all assayed members. Gene-level summaries report observed molecules per segmented cell and fractions with at least one molecule; cells were not treated as independent patients. The targeted panel provides partial module coverage, and overlapping HS donor labels preclude counting this object as independent validation. Only descriptive patient estimates and cell-coordinate displays were generated, without new hypothesis tests or inferred cell regions.",'新增定位分析方法；明确源注释、原始层及患者单位','xenium_extension/review/analysis_plan_locked.json; analysis_summary.json')
    append(80,' The targeted Xenium annotated object is publicly available at Figshare (doi:10.6084/m9.figshare.27327813), with raw spatial data under GSE282123 [32]. The downloaded metadata, byte-range acquisition records, filtered count-layer hash and patient/compartment source keys are retained with the extension.','补充准确空间数据来源','new_data/figshare27327813.json; xenium5k_metadata/counts_acquisition.json')
    reference32='32. Mennillo, E.; Lotstein, M. L.; Lee, G.; et al. Single-cell spatial transcriptomics of formalin-fixed, paraffin-embedded biopsies reveals colitis-associated cell networks. J Clin Invest 2026. doi:10.1172/JCI202488.'
    from integrate_new_science import revise_existing
    new_insertions,new_captions=revise_existing(O,desired,ledger,replace,append)
    # Edits avoid all existing bibliography field results.
    red=deepcopy(xml);clean=deepcopy(xml);changes=[]
    for tree,mode in [(red,True),(clean,False)]:
        ps=tree.xpath('//w:body/w:p',namespaces=NS)
        for i,p in enumerate(ps):
            pid=f'V1P{i+1:03d}';old=orig[pid];new=desired[pid]
            if old==new:continue
            for a,b,s in reversed(diffops(old,new)):splice(p,a,b,s,mode)
            assert (accepted(p) if mode else text(p))==new,pid
        # The newly occupied reference paragraph inherits V1 bibliography typography.
        p=ps[119]
        reference=ps[118]
        for oldpr in list(p.findall(Q('pPr'))):p.remove(oldpr)
        if reference.find(Q('pPr')) is not None:p.insert(0,deepcopy(reference.find(Q('pPr'))))
        for run in p.xpath('./w:r[w:t]',namespaces=NS):
            rp=run.find(Q('rPr'))
            if rp is None:rp=E.SubElement(run,Q('rPr'));run.insert(0,rp)
            for tag in ['rFonts','sz','szCs']:
                for node in list(rp.findall(Q(tag))):rp.remove(node)
            f=E.SubElement(rp,Q('rFonts'))
            for key in ['ascii','hAnsi','cs']:f.set(Q(key),'Times New Roman')
            E.SubElement(rp,Q('sz')).set(Q('val'),'22')
            E.SubElement(rp,Q('szCs')).set(Q('val'),'22')
    # Insert the new spatial reference after reference 31 without touching old reference fields.
    for tree,mode in [(red,True),(clean,False)]:
        body=tree.find(Q('body'));anchor=body.findall(Q('p'))[119];p=E.Element(Q('p'))
        if anchor.find(Q('pPr')) is not None:p.append(deepcopy(anchor.find(Q('pPr'))))
        p.append(newrun(anchor.xpath('./w:r[w:t]',namespaces=NS)[0],reference32,'add' if mode else ''))
        body.insert(body.index(anchor)+1,p)
    items=list(orig.items());at=next(i for i,(k,v) in enumerate(items) if k=='V1P120')+1;items.insert(at,('V1ADD_REF32',''));orig=dict(items);desired['V1ADD_REF32']=reference32
    ledger.append({'id':'V1ADD_REF32','old_text':'','new_text':reference32,'category':'A','reason_CN':'新增空间定位原论文参考文献；原引文域未改动','source':'https://www.jci.org/articles/view/202488','numerical_change':False})
    # New scientific paragraphs inherit the corresponding original paragraph style.
    for key,anchor_key,value in new_insertions:
        for tree,mode in [(red,True),(clean,False)]:
            body=tree.find(Q('body'))
            anchors=[p for p in body.findall(Q('p')) if (accepted(p) if mode else text(p))==desired[anchor_key]]
            assert len(anchors)==1,(key,anchor_key)
            anchor=anchors[0];p=E.Element(Q('p'))
            if anchor.find(Q('pPr')) is not None:p.append(deepcopy(anchor.find(Q('pPr'))))
            template=anchor.xpath('.//w:r[w:t]',namespaces=NS)[-1]
            p.append(newrun(template,value,'add' if mode else ''))
            body.insert(body.index(anchor)+1,p)
        items=list(orig.items());at=next(i for i,(k,v) in enumerate(items) if k==anchor_key)+1;items.insert(at,(key,''));orig=dict(items);desired[key]=value
        ledger.append({'id':key,'old_text':'','new_text':value,'category':'A' if 'REF33' in key else 'C','reason_CN':'新增实际定点分析及必要方法/文献；原Word结构和引文保留','source':'conditional and organoid source tables; locked plans','numerical_change':True})
    added_caption={
      'V1ADD_SF7_TITLE':'Supplementary Figure 7. Gene-level effects across the complete epithelial reciprocity core.',
      'V1ADD_SF7_LEGEND':'a,b, All members of the frozen TNFSF12 positive leading-edge core, displayed alphabetically across two panels. Colour indicates the original gene-specific log2 fold change. The organoid contrast is TNFSF12 versus matched cytomix control; tissue contrasts are ICI colitis versus the respective control. The four epithelial families are from the single independent GSE206300 cohort, while platform samples are from GSE210037. Asterisks denote FDR<0.05 within the corresponding source analysis; grey NE cells denote missing estimates. The columns are distinct statistical contexts and do not represent individual donors or a pooled test. No genes were selected by their external effect or significance. Complete estimates and source-row keys accompany the figure.'}
    added_caption.update({
      'V1ADD_SF10_TITLE':'Supplementary Figure 10. Spatial distribution of the nominated genes across annotated compartments.',
      'V1ADD_SF10_LEGEND':'a-c, SORL1, TNFSF12 and TNFRSF12A molecules per segmented cell, summed and averaged within each patient and published compartment. Each point is a patient; healthy, ICI-colitis and UC samples remain separate. All available patient-compartment estimates are displayed. Counts are observed targeted-panel measurements; segmentation and cell-subtype composition can affect their values. No cell-level or disease-comparison significance test is shown. Donor labels overlap the original discovery cohort. Source data and record keys are provided in Table S70.',
      'V1ADD_SF11_TITLE':'Supplementary Figure 11. Frozen programmes within spatially annotated epithelium.',
      'V1ADD_SF11_LEGEND':'a-d, Frozen IFN-visibility, disease-up, non-IFN residual and disease-depleted programmes scored after count aggregation in the published epithelial compartment of each patient. Points represent patients and horizontal bars indicate medians. Each panel states the assayed fraction of the frozen gene set. Higher score indicates the prespecified disease direction; the disease-depleted score is one minus the raw mean panel-gene rank. No missing genes were imputed and no new membership was selected. These targeted, partially covered measurements in overlapping discovery donors are descriptive, not independent full-module validation (Tables S68-S71).',
      'V1ADD_SF12_TITLE':'Supplementary Figure 12. Cell-level spatial follow-through of SORL1 and frozen programmes.',
      'V1ADD_SF12_LEGEND':'Plates A-C display every assigned healthy, ICI-colitis and UC patient, respectively. Columns show published cell compartments, log1p observed SORL1 molecules, and raw mean expression ranks for the assayed members of the non-IFN residual and disease-depleted programmes. Each measurement uses a fixed colour scale across all patients. Display tiles remove the largest empty vertical coordinate strip when it exceeds 10% of the patient coordinate range. Every assigned cell is retained; no expression value is used to define a tile. Native within-tile geometry is preserved, with separate view extents; tiles are layout units, not biological regions or replicates. Bounds and complete cell-to-tile keys accompany the source data. Higher raw rank indicates higher expression, including for the disease-depleted set. Cell locations do not represent independent patients or a causal test. Complete values, original cell keys and annotations are in xenium_extension/source_data/cell_coordinates_scores.tsv.gz.',
      'V1ADD_SF8_TITLE':'Supplementary Figure 8. Frozen-programme transfer in the additional Oxford spatial cohort.',
      'V1ADD_SF8_LEGEND':'a-d, Patient-level disease-oriented mean expression ranks for IFN visibility, disease-up, non-IFN residual and disease-depleted programmes. Each point is one donor after summing counts across eligible tissue spots and repeated sections; horizontal bars indicate medians. Healthy controls, ICI-colitis and UC donors are displayed separately. P values compare ICI-colitis with healthy controls using two-sided Mann-Whitney tests, and FDR is BH-adjusted across these four prespecified comparisons. None meets FDR<0.05. Higher score denotes the expected disease direction; the disease-depleted score is 1 minus its raw mean expression rank. UC is descriptive context. No spot-level inference or new bootstrap interval is shown. Tables S64-S67 provide mappings, complete patient scores, comparisons and module coverage.',
      'V1ADD_SF9_TITLE':'Supplementary Figure 9. Registered tissue maps of the frozen programmes across all additional spatial sections.',
      'V1ADD_SF9_LEGEND':'Plates A-F display every included section in accession/section order, three sections per plate. Columns show the released H&E image followed by IFN-visibility, non-IFN residual and disease-depleted raw expression-rank scores at their released coordinates. Higher raw rank means higher relative programme expression, including in the disease-depleted column. Each module uses one colour scale across all sections; sections do not share a common physical zoom. Coordinates are native image pixels transformed by the released low-resolution scale factor. These are tissue-distribution maps, not independently annotated epithelial regions or donor-replicated local tests. A1/A2 are one healthy donor and B8/B9 one UC donor. Complete spot values, source image/matrix paths, barcode keys and sample metadata are supplied in spatial_extension/source_data.'})
    added_caption.update(new_captions)
    added_caption=dict(sorted(added_caption.items(),key=lambda item:(int(re.search(r'SF(\d+)',item[0]).group(1)),0 if item[0].endswith('_TITLE') else 1)))
    for tree,mode in [(red,True),(clean,False)]:
        body=tree.find(Q('body'));sect=body.find(Q('sectPr'))
        template=body.findall(Q('p'))[-1]
        template_run=next(r for r in template.xpath('.//w:r[w:t]',namespaces=NS) if r.find('./'+Q('rPr')+'/'+Q('b')) is None)
        for key,value in added_caption.items():
            p=E.Element(Q('p'))
            if template.find(Q('pPr')) is not None:p.append(deepcopy(template.find(Q('pPr'))))
            nr=newrun(template_run,value,'add' if mode else '')
            if key.endswith('_TITLE'):
                pp=p.find(Q('pPr'))
                if pp is None:pp=E.SubElement(p,Q('pPr'));p.insert(0,pp)
                E.SubElement(pp,Q('keepNext'))
                rp=nr.find(Q('rPr'))
                if rp is None:rp=E.SubElement(nr,Q('rPr'));nr.insert(0,rp)
                E.SubElement(rp,Q('b'))
            p.append(nr)
            if sect is not None:body.insert(body.index(sect),p)
            else:body.append(p)
    for key,value in added_caption.items():
        orig[key]='';desired[key]=value
        ledger.append({'id':key,'old_text':'','new_text':value,'category':'A','reason_CN':'新增完整核心基因效应图图注；新增文字全红，干净版一致','source':'Supplementary Figure 7; Table S38; Table S43; independent family DE','numerical_change':False})
    for tag,tree in [('RED',red),('CLEAN',clean)]:
        dest=O/'manuscript'/f'manuscript_V1_revised_{tag}.docx'
        with ZipFile(dest,'w') as z:
            for name,(info,b) in parts.items():z.writestr(info,E.tostring(tree,encoding='UTF-8',xml_declaration=True,standalone=True) if name=='word/document.xml' else b)
    pd.DataFrame(ledger).to_csv(O/'review/changes.tsv',sep='\t',index=False)
    (O/'review/manuscript_change_record.json').write_text(json.dumps({'baseline':str(base),'paragraphs':[{'id':pid,'original':orig[pid],'revised':desired[pid]} for pid in orig],'changes':ledger},ensure_ascii=False,indent=2),encoding='utf-8')
    (O/'review/manuscript_CLEAN_extracted.txt').write_text('\n\n'.join(f'{pid} {desired[pid]}' for pid in orig),encoding='utf-8')
    print(f'Created paired visual-redline and clean Word documents; {len(ledger)} change records; {sum(orig[k]!=desired[k] for k in orig)} revised paragraphs.')
if __name__=='__main__':main()
