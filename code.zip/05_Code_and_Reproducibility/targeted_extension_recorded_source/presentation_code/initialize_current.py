from pathlib import Path
import shutil,json,csv,hashlib
from datetime import datetime,timezone
O=Path(__file__).resolve().parents[1]
P=Path('E:/ICI_irAE_V1_Redline_Revision/20260913T151145Z_68fe8bf1')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
 return h.hexdigest()
assets=[]
for name in ['edit_docx.py','plot_v1.R','static_smoke.R','verify_outputs.py','prepare_package.py','render_figure_pdfs.py']:
 p=P/'presentation_code'/name;shutil.copy2(p,O/'presentation_code'/name);assets.append({'source':str(p),'sha256':sha(p),'role':'versioned presentation source, original DOCX remains canonical'})
for name in ['local_findings.json','organoid_sheet_audit.tsv','organoid_comparison_audit.tsv','reciprocity_core_gene_evidence.tsv','validation_denominators.tsv','aggregate_record_keys.tsv','organoid_evidence_resolution.md','SCIENTIFIC_UPGRADE_PLAN_CN.md']:
 p=P/'review'/name;shutil.copy2(p,O/'review'/name);assets.append({'source':str(p),'sha256':sha(p),'role':'previous read-only audit evidence, not newly executed'})
rows=list(csv.DictReader((P/'review/input_manifest_before.tsv').open(encoding='utf-8-sig'),delimiter='\t'))
known={str(Path(r['path'])).lower() for r in rows}
for p in Path('E:/ICI_irAE_Original_Project/tables_for_article').glob('*.tsv'):
 if str(p).lower() not in known:
  row={k:'' for k in rows[0]};row.update(path=str(p),size=p.stat().st_size);rows.append(row)
for r in rows:
 p=Path(r['path']);r['sha256_before']=sha(p);r['size']=p.stat().st_size
with (O/'review/input_manifest_before.tsv').open('w',encoding='utf-8',newline='') as f:
 w=csv.DictWriter(f,fieldnames=rows[0],delimiter='\t');w.writeheader();w.writerows(rows)
(O/'review/reused_assets.json').write_text(json.dumps({'utc':datetime.now(timezone.utc).isoformat(),'assets':assets},ensure_ascii=False,indent=2),encoding='utf-8')
runner=(P/'RUN_PRESENTATION_ONLY.ps1').read_text(encoding='utf-8')
fix='''# Restore validated Windows defaults for this process only; never alter the registry.
$restore = Get-Content -LiteralPath (Join-Path $revisionRoot 'review/child_environment_restore.json') -Raw | ConvertFrom-Json
foreach ($prop in $restore.restored.PSObject.Properties) {[Environment]::SetEnvironmentVariable($prop.Name,[string]$prop.Value,'Process')}
$env:SystemDrive=([IO.Path]::GetPathRoot($env:SystemRoot)).TrimEnd('\\')
$env:ALLUSERSPROFILE=$env:PROGRAMDATA
$env:OS='Windows_NT'
$env:PROCESSOR_ARCHITECTURE='AMD64'
'''
runner=runner.replace("$revisionRoot=$PSScriptRoot", "$revisionRoot=$PSScriptRoot\n"+fix)
# Old failures remain in old logs, not as tolerated failures in the current runner.
a=runner.index(" if($code -ne 0 -and $KnownFailure")
b=runner.index(' $inputHash=@()',a)
runner=runner[:a]+runner[b:]
(O/'RUN_PRESENTATION_ONLY.ps1').write_text(runner,encoding='utf-8')
p=O/'presentation_code/spatial_inventory.py';p.write_text(p.read_text().replace("line.startswith('!Sample_supplementary_file = ')","line.startswith('!Sample_supplementary_file') and ' = ' in line"),encoding='utf-8')
print('Initialized current source-only revision with fresh pre-use original hashes and child environment fix.')
