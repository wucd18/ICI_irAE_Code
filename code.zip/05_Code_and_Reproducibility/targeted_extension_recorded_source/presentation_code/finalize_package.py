"""Package a reviewed V1 candidate. Integrity PASS is not scientific release."""
from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,zipfile,sys,shutil,io
import pandas as pd
O=Path(__file__).resolve().parents[1]
R=O/'review'
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(4*1024**2),b''):h.update(b)
 return h.hexdigest()
def rd(p):return pd.read_csv(p,sep='\t',float_precision='round_trip')
def js(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def put(p,data):Path(p).write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
def save(df,p):df.to_csv(p,sep='\t',index=False)
def fixture():
 b=io.BytesIO()
 with zipfile.ZipFile(b,'w',zipfile.ZIP_DEFLATED) as z:z.writestr('folder/test.txt','unchanged value\n')
 with zipfile.ZipFile(b) as z:assert z.testzip() is None and z.read('folder/test.txt')==b'unchanged value\n'
 print('PASS: ZIP CRC and byte-roundtrip fixture')
if '--test' in sys.argv:fixture();raise SystemExit(0)
fixture()
now=datetime.now(timezone.utc).isoformat()
base=js(R/'output_verification.json');ext=js(R/'extension_verification.json')
assert base['overall']=='PASS' and ext['status']=='PASS'
qa=js(R/'visual_QA_signed.json')
assert qa['status']=='PASS'
for row in qa['reviewed_files']:assert sha(O/row['path'])==row['sha256'],f"Visual QA stale: {row['path']}"
# Recheck original inputs at final delivery, not merely file presence.
original=rd(R/'input_manifest_before.tsv');hrows=[]
for z in original.itertuples():
 actual=sha(z.path);expected=getattr(z,'sha256_before',z.sha256)
 hrows.append({'path':z.path,'size':Path(z.path).stat().st_size,'sha256_before':expected,'sha256_after':actual,'status':'PASS' if actual==expected else 'FAIL'})
save(pd.DataFrame(hrows),R/'original_inputs_final_hash_check.tsv')
assert all(z['status']=='PASS' for z in hrows)
sp=O/'spatial_extension';xn=O/'xenium_extension'
ss=js(sp/'review/analysis_summary.json');xs=js(xn/'review/analysis_summary.json')
patients=rd(sp/'source_data/patient_scores.tsv');sm=rd(sp/'source_data/sample_manifest.tsv');sq=rd(sp/'source_data/section_QC.tsv');tests=rd(sp/'source_data/frozen_transfer_results.tsv')
xg=rd(xn/'source_data/patient_gene_expression.tsv');xcv=rd(xn/'source_data/module_coverage.tsv')
# Independent checks of new manuscript numbers, in their actual paragraphs.
para={z['id']:z['revised'] for z in js(R/'manuscript_change_record.json')['paragraphs']}
claims=[]
def claim(pid,name,value,fmt,source):
 expected=format(value,fmt);ok=expected in para[pid]
 claims.append({'paragraph':pid,'claim':name,'source_value':value,'formatted_text':expected,'source':source,'status':'PASS' if ok else 'FAIL'})
for name,value in [('sections',len(sm)),('donors',sm.patient.nunique()),('ICI donors',patients.loc[patients.condition.eq('ICI colitis'),'patient'].nunique()),('healthy donors',patients.loc[patients.condition.eq('Healthy'),'patient'].nunique()),('UC donors',patients.loc[patients.condition.eq('UC'),'patient'].nunique())]:
 claim('V1P028',name,int(value),'d','spatial sample_manifest + patient_scores')
claim('V1P028','retained tissue spots',int(sq.kept_tissue_spots.sum()),',d','spatial section_QC')
for z in tests.itertuples():
 if z.module in ['CURATED_IFN_VISIBILITY','ICI_COLITIS_EPITHELIAL_UP_NON_IFN','ICI_COLITIS_EPITHELIAL_LOSS_STRICT']:
  claim('V1P028',z.module+' median difference',z.median_difference,'.4f','spatial frozen_transfer_results')
  claim('V1P028',z.module+' FDR',z.FDR_new_four_module_family,'.4f','spatial frozen_transfer_results')
for group,value in xg[xg.gene.eq('SORL1')&xg.compartment.eq('IEC')].groupby('condition').mean_molecules_per_cell.median().items():
 if group in ['HC','ICI']:claim('V1P036','SORL1 '+group+' patient median molecules/cell',value,'.4f','xenium patient_gene_expression / IEC / SORL1')
loss=xcv[xcv.module.eq('ICI_COLITIS_EPITHELIAL_LOSS_STRICT')].iloc[0]
for key in ['available','requested']:claim('V1P036','targeted disease-depleted '+key,int(loss[key]),'d','xenium module_coverage')
for key,fmt in [('included_cells',',d'),('patients','d'),('excluded_cells','d')]:claim('V1P065',key,xs[key],fmt,'xenium analysis_summary and cell source keys')
save(pd.DataFrame(claims),R/'new_manuscript_numerical_claim_checks.tsv')
assert all(z['status']=='PASS' for z in claims)
assert (tests.FDR_new_four_module_family>=.05).all() and xs['independent_new_cohorts']==0
# Complete source maps, including the two new Figure 1 count summaries.
maps=rd(R/'source_map.tsv').to_dict('records')
for z in maps:
 try:z['file']=Path(z['file']).relative_to(O).as_posix()
 except ValueError:pass
 if z['panel']=='F1A_cohort_inputs':z['panel']='F1b cohort landscape | source file ID F1A_cohort_inputs'
for n,src,unit,key in [
 ('F1C_new_spatial_counts','spatial_extension/source_data/sample_manifest.tsv; spatial_extension/source_data/section_QC.tsv','donors / sections / tissue spots, separately','patient; GSM; retained spot count'),
 ('F1C_xenium_counts','xenium_extension/review/analysis_summary.json','overlapping donor labels / assigned cells','patient; included_cells')]:
 maps.append({'panel':n,'file':'source_data/'+n+'.tsv','original_source':src,'record_key':key,'unit':unit,'transformation':'Deterministic counts from released metadata; no new inference'})
for prefix in ['spatial_extension','xenium_extension']:
 m=rd(O/prefix/'review/panel_source_map.tsv')
 for row in m.to_dict('records'):
  files=row.get('sources',row.get('source',''))
  maps.append({'panel':row['figure']+' | '+row.get('panel',row.get('sections','')),'file':'; '.join(prefix+'/source_data/'+q.strip() for q in files.split(';')),'original_source':'GSE189184 + GSE158328 / Gupta Table S1' if prefix=='spatial_extension' else 'Figshare 27327813 file 59547515 / released raw_counts and annotations','record_key':row.get('record_key',row.get('key','')),'unit':row.get('unit',row.get('statistical_unit','')),'transformation':'Presentation of frozen saved extension results; no statistical refit'})
maps.append({'panel':'Supplementary_Figure_12A-C | coordinate tile layout','file':'xenium_extension/source_data/spatial_view_bounds.tsv; xenium_extension/source_data/spatial_view_cell_keys.tsv.gz','original_source':'xenium_extension/source_data/cell_coordinates_scores.tsv.gz','record_key':'cell_key; patient|view_tile','unit':'coordinate view only; all assigned cells retained','transformation':'Largest empty y-coordinate gap >10% of patient range; no expression-based selection; within-tile geometry preserved'})
save(pd.DataFrame(maps),R/'ALL_PANEL_SOURCE_MAP.tsv')
# Collect actual child exit codes; retain every unsuccessful historical attempt.
execution=[]
for f in (O/'logs').rglob('*.json'):
 try:d=js(f)
 except (ValueError,UnicodeError):continue
 if not isinstance(d,dict) or 'exit_code' not in d:continue
 cmd=d.get('command') or [d.get('executable','')]+d.get('arguments',[])
 if isinstance(cmd,list):cmd=' '.join(str(v) for v in cmd)
 execution.append({'record':f.relative_to(O).as_posix(),'command':cmd,'start_utc':d.get('start_utc',''),'end_utc':d.get('end_utc',''),'exit_code':d['exit_code']})
execution.sort(key=lambda z:z['start_utc'])
save(pd.DataFrame(execution),R/'ACTUAL_EXECUTION_INVENTORY.tsv')
mandatory=[]
for script in ['plot_v1.R','plot_spatial_extension.R','plot_xenium_extension.R','verify_outputs.py','verify_extensions.py','render_word.ps1','render_final_word_pages.py','render_figure_pdfs.py','static_smoke.R','analyze_spatial_frozen.py','xenium_spatial_followthrough.py']:
 rows=[z for z in execution if script in z['command'] and '--test' not in z['command'] and '--preflight' not in z['command']]
 assert rows,f'Missing execution evidence: {script}'
 row=rows[-1];mandatory.append({'step':script,**row})
 assert row['exit_code']==0,f"Latest mandatory step failed: {row}"
save(pd.DataFrame(mandatory),R/'LATEST_MANDATORY_EXECUTION.tsv')
# Small acquisition/provenance files accompany the package; large source data stay local.
prov=O/'provenance';prov.mkdir(exist_ok=True)
selected=[]
for f in (O/'new_data').glob('*.json'):selected.append(f)
selected += [O/'new_data/Capeling_Figure_4_Code_pinned.Rmd',O/'new_data/Gupta_Table_S1_publisher.xlsx']
for name in ['source_manifest.json','counts_acquisition.json','inventory.json','QC_count_difference_audit.json']:
 selected.append(O/'new_data/xenium5k_metadata'/name)
prows=[]
for f in selected:
 if not f.exists():continue
 rel=f.relative_to(O/'new_data');target=prov/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,target)
 prows.append({'local_input':str(f),'package_copy':target.relative_to(O).as_posix(),'size':f.stat().st_size,'sha256':sha(f),'role':'Public source acquisition, patient metadata or pinned generation-code evidence'})
save(pd.DataFrame(prows),prov/'included_provenance_manifest.tsv')
allnew=[]
for f in (O/'new_data').rglob('*'):
 if f.is_file() and 'byte_ranges' not in f.parts:
  allnew.append({'path':str(f),'bytes':f.stat().st_size,'sha256':sha(f),'scope':'Acquired source or eligibility-review file; inclusion in analysis determined by separate locked plans, not by download alone'})
save(pd.DataFrame(allnew),R/'new_acquired_file_manifest.tsv')
raw=O/'new_data/xenium5k_metadata/released_raw_counts.npz'
assert sha(raw)==xs['source_raw_npz_sha256']
controls=patients[patients.condition.eq('Healthy')].patient.nunique()
sor=xg[xg.gene.eq('SORL1')&xg.compartment.eq('IEC')].groupby('condition').mean_molecules_per_cell.median()
ifn=tests[tests.module.eq('CURATED_IFN_VISIBILITY')].iloc[0]
new_report=f"""# 本轮实际补强结果

本轮以第一版 Word 和已有统计为基底，保留临床问题、组织受体研究空缺、固定 ICI 程序、疾病—类器官扰动连接、肿瘤关联、TCR 与完整讨论。六张主图顺序保持 4 类器官、5 肿瘤、6 TCR。没有运行原项目 RUN_ALL、reproduce_manuscript 或任何等价总入口。

## 已经增加的科学证据

Oxford 独立空间队列已真实下载并完成固定程序转移：{len(sm)} 切片、{sm.patient.nunique()} 供者、{int(sq.kept_tissue_spots.sum()):,} 个组织 spot。原论文 Table S1 将 A1/A2 归为同一健康供者，将 B8/B9 归为同一 UC 供者；患者汇总后是 7 ICI、{controls} 健康、6 UC。四个原固定程序均向预期疾病方向变化。IFN 差值 {ifn.median_difference:.4f}，P={ifn.P:.4f}，四检验 BH FDR={ifn.FDR_new_four_module_family:.4f}；其余三项 FDR 约 0.1167。没有一项达到 FDR<0.05。该结果增加方向性与组织分布资料，未完成显著独立复制。所有 18 切片均展示；UC 是单列的描述性背景。

为补充细胞定位，另取得 Mennillo 等公开 Xenium Dataset 2 的已发布 raw_counts、原细胞注释及坐标，按患者与已标注细胞区室汇总。{xs['included_cells']:,} 个已分配细胞来自 {xs['patients']} 个供者标签，排除 {xs['excluded_cells']} 个未分配细胞。SORL1 在作者标注的上皮中被实际测得；上皮内每细胞分子数的患者中位数为健康 {sor['HC']:.4f}、ICI {sor['ICI']:.4f}。原疾病减少程序在上皮中的可检测部分也呈疾病方向变化。新增补图 10–12 提供所有患者点、区室及组织位置。

这个定位层与第一版发现患者标签重合，不能当作新增独立队列。靶向芯片仅覆盖 IFN 113/224、up 40/84、non-IFN 38/80、loss 64/275；未补零、重选基因或改写成完整模块验证。只做患者描述性估计，没有以细胞为重复单位计算显著性。它补上细胞定位，不证明 TNFSF12 干预有效、安全或 SORL1 因果作用。

## 没有用替换数据来追逐显著性

资格核查发生在表达结果解读之前。GSE207884 是小鼠 DSS/ECP/anti-PD1 研究，不能作为独立人类上皮验证。GSE190564 的已发布巨大差异表尚未唯一对应到所需患者级模型与目标比较，未用细胞级 P 值升级患者证据。Utrecht 类固醇反应论文的公开 Source Data 为已有签名与临床摘要，不能承载本项目冻结 ICI 基因程序；Zenodo 仍返回远端 504，但没有把它当成本机运行错误。免疫/T 细胞专用数据亦未替换上皮任务。

## 类器官定点核查的最终界限

66 基因实际来自原保存的正向 leading edge，66 个 LFC 均为正，但只有 2 个单基因 FDR<=0.05。IBD2 约 2.58 是四个细胞类型效应的中位数，不是供者中位数。TNFSF12 TA 的 disease-depleted NES=1.33496391828164，screen FDR=0.093808266003729；方向提名与显著性分开。原 NES/P/FDR、模块、阈值与模型未变。

已取得并固定原作者 Figure 4 代码提交 3c80f66552d9c3ea344ba02304eb588b717e9ed8。Methods 的供者调整描述与示例 ~pert_new 设计、padj 非缺失导出的对应仍未唯一解决。未据文件名 DEGs、收缩估计或行数判定整个输入无效；也未将能运行视为适用性证明。受影响的是原 40 个条件×细胞类型 GSEA 的最终推断强度，尤其疾病—TNFSF12 连接；已发表 IBD 效应与独立疾病转移另列。最小依赖是确切出版表的设计、对照/池与导出记录，不自动要求 FASTQ、完整对象或全量重建。

科学状态为 PARTIAL_NEW_EVIDENCE / QUALIFIED：已经加入实际空间与细胞定位数据，但没有完成更强的独立机制或干预验证，不能保证恢复某个期刊档次。

## 技术错误已解决

进程级恢复缺失的 Windows 标准环境变量后，curl/HTTPS 数据读取、R --vanilla 绘图、Word COM 导出均已有真实退出码 0。未更改系统注册表或升级统计包。Xenium 第一次绘图另暴露 True/False 字符串被 R 当行名索引的问题；已显式解码并加入缺失/唯一键检查及小样本测试。后续 5 张图完整运行退出 0。所有历史失败日志保留，不把旧失败改写为成功。

Word 已通过真实 Word PDF 导出和逐页图像检查；最终 CLEAN 25 页、RED 26 页。可视红字采用 FF0000 与红色删除线，不冒称原生修订追踪。接受红字修改后的文本与 CLEAN 完全一致，原未修改 OOXML 部件及引用结构按记录核对。正文里原有的作者与基金等占位信息保留 USER_PENDING。
"""
(R/'SCIENTIFIC_UPGRADE_PLAN_CN.md').write_text(new_report,encoding='utf-8')
ledger=f"""# 中文修改账本

本账本与 changes.tsv、table_changes_CN.tsv、ALL_PANEL_SOURCE_MAP.tsv 共同构成逐项记录。每一项 Word 变化保存原文、新文、分类、中文理由及底表来源；每项 B 类表格纠错保存旧值、新值与受影响单元格。

1. A 类：六主图保持第一版顺序。Figure 1 顶部全宽框与边缘连接箭头，TCR/肺用虚线旁支，统计单位分开。Figure 2 保留原 Hallmark/NES/FDR、原描述性分类及肺免疫方向。Figure 3 保留第一版成员、外部转移和原 AUC 区间并统一家族顺序。Figure 4 连续效应、原数值热图、NES 与发表 IBD 效应分单位。Figure 5 显示全部原 GENE/AXIS/SIGNATURE 特征和原模型，未按显著性选图。Figure 6 保留患者点、原 rho/P/FDR，改清 raw rank 方向。
2. B 类：原文件不动，仅在新目录纠正已证实的标签、方法说明、数量/分母表述与原表阈值文字。66 基因选择依据、IBD2 统计单位、screen FDR、SORL1 跨家族中位效应与最小 FDR 的区别均写清。未把缺失 NES/P/效应补成 0。已正确的独立验证分母保留。
3. C 类受控新增：依据用户随后明确提出的换方案/换数据补强请求，单独完成 Oxford 固定程序患者转移和 Xenium 患者区室/坐标描述性分析。原项目的 DE/GSEA/Cox/Meta/bootstrap/IFN 条件分析没有重跑；原结果没有替换。新增分析计划、输入哈希、软件和退出码单独记录。
4. 新增补图 7 展示全部核心基因；8 为 Oxford 全患者结果；9A–F 展示全部切片；10 为三个原提名基因的患者区室测量；11 为原程序在 Xenium 上皮区室中的部分覆盖结果；12A–C 展示全部患者的坐标数据。新增表 S64–S71；原表原样副本保存在 supplementary/original_tables。
5. 图形视窗修正：补图 10/11 轴标题缩短以免遮挡标签；补图 12 的大坐标空白仅作展示拆分。依据最大空白 y 间隔切开，全部细胞仍出现一次；不按表达值圈区，不改变患者估计或任何统计阈值。view_bounds 与 cell_keys 记录完整对应。
6. Word 保留原第一版文档格式和原未改文字。新增/替换使用真实 FF0000；删除文字保留 FF0000 删除线；两版接受文本完全一致。新增参考文献 31、32 和补图正文也标红。修正新增参考文献字体、补图标题/正文粗体和标题分页问题。新增段落自然扩页；未重建全文、删除原域或静默接受原修订。
7. 数值检查：原图源表 {base['numeric_cells_checked']:,} 个数值单元格逐源行一致；原关键正文数字检查与本次新增 {len(claims)} 个正文数字检查通过。新增分析/图件检查 {ext['checks']} 项通过。技术 PASS 不代表生物假设达到显著性。
8. 未解决事项：类器官出版表与实际设计/导出对应为 NEEDS_SPECIFIC_EVIDENCE；作者、单位、通讯、基金、CRediT、竞争利益、公开代码 DOI 与期刊格式为 USER_PENDING。临床表达关联不写作干预效果或安全试验。
"""
(R/'修改账本_CN.md').write_text(ledger,encoding='utf-8')
components=[
 {'component':'科学','status':'PARTIAL_NEW_EVIDENCE / QUALIFIED','evidence':'新增空间/细胞定位已执行；Oxford 四项均未过 FDR；Xenium 供者重叠/部分覆盖；类器官生成对应未完全解决'},
 {'component':'数值','status':'PASS','evidence':f"{base['numeric_cells_checked']} original cells; {ext['checks']} extension checks; {len(claims)} new text claims"},
 {'component':'红字','status':'PASS','evidence':'FF0000 adds/deletes; red strike; accepted text equals CLEAN; preserved original structure'},
 {'component':'排版','status':'PASS','evidence':'Word 25 CLEAN + 26 RED pages visually reviewed; 25 final figure PDFs rendered and reviewed at stated dimensions'},
 {'component':'运行','status':'PASS_CURRENT_MANDATORY_STEPS','evidence':'Actual latest required exits are 0; historical failed attempts retained'},
 {'component':'作者信息','status':'USER_PENDING','evidence':'Authors, affiliations, correspondence, funding, CRediT, competing interests, repository DOI and journal format'},
 {'component':'投稿放行','status':'NOT_RELEASED','evidence':'Candidate for author/scientific review; not all scientific evidence approved'}]
save(pd.DataFrame(components),R/'FINAL_COMPONENT_STATUS.tsv')
put(R/'FINAL_COMPONENT_STATUS.json',{'utc':now,'components':components,'original_inputs_unchanged':len(hrows),'new_scientific_hypotheses_all_passed':False})
readme=f"""# 第一版修订与实际空间补强候选包

本包已完成英文 Word 修订、六主图及对应补图、患者/空间数据补充分析和输出验证。科学状态为有条件候选：新增定位证据已落地，独立显著复制与类器官输入生成对应仍有限制。作者及期刊信息待补，不标为最终可投稿。

- manuscript/manuscript_V1_revised_RED.docx：可视红字修改稿；删除文字为红色删除线，非原生修订追踪。
- manuscript/manuscript_V1_revised_CLEAN.docx：接受全部本轮修改后的对应候选。
- figures：6 张主图。supplementary：原 7 张补图。spatial_extension/figures：7 张 Oxford 图。xenium_extension/figures：5 张细胞定位图。共 25 张 PDF、600 dpi TIFF 和 PNG 预览。
- supplementary/tables：主表 1/2 与连续 S1–S71；original_tables 保存原表不变副本。
- review/ALL_PANEL_SOURCE_MAP.tsv：每 panel 的源表、单位、记录键与变换；三处 source_data 目录含实际绘图数据。
- review/修改账本_CN.md、SCIENTIFIC_UPGRADE_PLAN_CN.md、organoid_evidence_resolution.md：修改依据、科学增量与类器官定点核查。
- review/FINAL_COMPONENT_STATUS.tsv、original_inputs_final_hash_check.tsv、output_verification.json、extension_verification.json、visual_QA_signed.json：分项验证与逐页/图件记录。
- logs：真实执行记录，包含历史失败；LATEST_MANDATORY_EXECUTION.tsv 指向当前完成步骤的真实退出码。

RUN_PRESENTATION_ONLY.ps1 默认只读取现有结果重绘和改稿，不调用统计总入口。RUN_SPATIAL_EXTENSION.ps1 是单独的新数据入口，默认只跑小样本测试，显式 Oxford/Xenium 阶段写新的 extension_runs 唯一目录。原项目统计结果、数据和代码从未覆盖。

源数据继续位于原项目及本轮 new_data，未复制大型目录、完整空间对象或 python_env 到 ZIP。压缩包带患者/spot/细胞坐标源表、汇总矩阵、原始数据下载地址/成员/字节范围哈希及独立代码；重做新增统计需要对应的原始输入路径。恢复运行依赖当前机器已存在的 R/Word/Python；包内没有声称自带完整统计环境。

实际 Word PDF 位于 review/render/CLEAN 和 RED。逐页 PNG 留在本机同目录；压缩包保留逐页图像哈希及审阅记录，避免重复膨胀。所有最终图的 PNG 预览仍在包内。

Table S63 对包内文件逐一给出 SHA-256（不自引用，也不对 ZIP 递归求哈希）。ZIP CRC 与逐文件哈希验证结果另存为压缩包旁的 candidate_zip_verification.json；这是物理包完整性通过，不代表全部科学主张通过。
"""
(O/'README_交付说明_CN.md').write_text(readme,encoding='utf-8')
# Human-readable supplementary captions for the earlier six plots, whose V1
# manuscript contained citations but no separate supplementary-legend section.
captions=[
 ('1','Complete receiver Hallmark landscape. Original NES and compartment-specific FDR for all released Hallmark tests; rows retain the saved descriptive order. Grey NE denotes a missing estimate, distinct from a nonsignificant estimate. Source: SF1 panel table.'),
 ('2','Complete frozen-module transfer. All saved discovery, primary transfer, sensitivity and platform contrasts are retained. Disease-depleted directions are reversed for display. Asterisks require saved concordant FDR significance; discovery rows are self-checks, not independent cohorts. Source: SF2 panel table.'),
 ('3','Source-confounded lung sensitivity. Original NES and FDR are displayed for released BALF immune populations; brackets state expected disease direction. These comparisons do not provide epithelial functional validation. Source: SF3 panel table.'),
 ('4','Complete candidate off-target estimates. All originally tested candidate-by-cell-type Hallmark values are retained. Asterisks indicate original FDR; grey NE denotes missing estimates. No pathway or candidate was selected here to improve significance. Source: SF4 panel table.'),
 ('5','Paired heart-repertoire overlap. Each point represents one donor comparison; lines connect the same donor across adjacent-normal and tumour comparators. Values are original Morisita-Horn abundance overlap estimates. No new model or confidence band was fitted. Source: SF5 panel table.'),
 ('6','Downstream reciprocity-core ranking. Original independent epithelial median logFC and platform logFC are displayed with signs reversed to show depletion; size is original organoid log2FC. Nominations and all estimates remain as originally saved. The display is not an independent target-validation test. Source: SF6 panel table.')]
captext='# Supplementary figure legends\n\n'+'\n\n'.join('Supplementary Figure '+n+'. '+s for n,s in captions)
for i in range(7,13):
 for tail in ['TITLE','LEGEND']:
  key=f'V1ADD_SF{i}_{tail}'
  if key in para:captext+='\n\n'+para[key]
(O/'supplementary/Supplementary_figure_legends.md').write_text(captext+'\n',encoding='utf-8')
# Candidate content is explicitly selected; no source directory or environment copy.
files=[]
for folder in ['manuscript','figures','supplementary','source_data','presentation_code','logs','environment','provenance']:
 for f in (O/folder).rglob('*'):
  if f.is_file() and '__pycache__' not in f.parts and not f.name.startswith('~$'):files.append(f)
for folder in ['spatial_extension','xenium_extension']:
 for part in ['source_data','review','figures']:
  files.extend(f for f in (O/folder/part).rglob('*') if f.is_file())
for f in R.rglob('*'):
 if not f.is_file():continue
 if 'render' in f.relative_to(R).parts and f.suffix.lower() not in ['.pdf','.txt']:continue
 files.append(f)
files.extend([O/'RUN_PRESENTATION_ONLY.ps1',O/'RUN_SPATIAL_EXTENSION.ps1',O/'README_交付说明_CN.md'])
manifest=O/'supplementary/tables/Table_S63_final_artifact_manifest.tsv'
skip={manifest,R/'candidate_zip_verification.json'}
# The parent shell is still writing this packaging step's stdout. Completed
# historical logs are included; the current receipt stays beside the ZIP.
inflight={f.parent for f in (O/'logs').rglob('package_candidate.stdout.txt') if not (f.parent/'package_candidate.json').exists()}
files=[f for f in files if not any(d==f.parent or d in f.parents for d in inflight)]
files=sorted(set(f for f in files if f not in skip and f.suffix.lower() not in ['.zip','.pyc']),key=lambda p:p.relative_to(O).as_posix())
inventory=[{'path':f.relative_to(O).as_posix(),'bytes':f.stat().st_size,'sha256':sha(f)} for f in files]
save(pd.DataFrame(inventory),manifest);files.append(manifest)
stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
zip_path=O/f'submission_candidate_V1_spatial_{stamp}.zip'
assert not zip_path.exists()
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for f in files:z.write(f,f.relative_to(O).as_posix())
with zipfile.ZipFile(zip_path) as z:
 assert z.testzip() is None
 assert len(z.namelist())==len(files)==len(set(z.namelist()))
 for row in inventory:assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256'],row['path']
 assert z.read(manifest.relative_to(O).as_posix())==manifest.read_bytes()
result={'utc':datetime.now(timezone.utc).isoformat(),'status':'PACKAGE_INTEGRITY_PASS','zip':str(zip_path),'bytes':zip_path.stat().st_size,'sha256':sha(zip_path),'entries':len(files),'CRC_test':'PASS','entry_SHA256_verification':'PASS','science':'PARTIAL_NEW_EVIDENCE / QUALIFIED','submission_release':'NOT_RELEASED','author_information':'USER_PENDING','source_original_hashes_unchanged':len(hrows),'candidate_documents':{f.name:sha(f) for f in (O/'manuscript').glob('*.docx')}}
put(R/'candidate_zip_verification.json',result)
(O/(zip_path.name+'.sha256')).write_text(result['sha256']+'  '+zip_path.name+'\n',encoding='ascii')
print(json.dumps(result,ensure_ascii=False,indent=2))
