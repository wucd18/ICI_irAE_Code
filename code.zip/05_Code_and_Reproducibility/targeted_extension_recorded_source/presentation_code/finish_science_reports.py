"""Generate traceable release reports from completed estimates, never fit models."""
from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,shutil,re,ast
import pandas as pd
O=Path(__file__).resolve().parents[1];P=Path('E:/ICI_irAE_V1_Redline_Revision/20260913T153320Z_ce95c1e1')
def js(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def rd(p):return pd.read_csv(p,sep='\t',float_precision='round_trip')
def sha(p):
 with open(p,'rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def put(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')
E=O/'organoid_donor_extension';z=js(E/'review/analysis_complete.json');R=Path(z['output']);v=js(E/'review/numerical_verification.json');c=js(O/'review/conditional_verification.json');out=js(O/'review/output_verification.json')
g=rd(R/'module_GSEA.tsv');d=rd(R/'donor_paired_effects.tsv');s=rd(E/'source_data/SORL1_donor_gene_effects.tsv');p=js(E/'review/analysis_plan_locked.json')
ta=g[g.ligand.eq('TNFSF12')&g.celltype.eq('Transit_Amplifying')&g.module.eq('ICI_COLITIS_EPITHELIAL_LOSS_STRICT')].iloc[0]
pa=d[d.ligand.eq('TNFSF12')&d.celltype.eq('Transit_Amplifying')&d.module.eq(ta.module)].iloc[0];so=s[s.celltype.eq('Transit_Amplifying')].iloc[0]
# Finish the original vs newly-used input hash checks; large source is read, never copied.
inputs=js(O/'review/conditional_analysis_plan_locked.json')['inputs']+[dict(path=p['source']['file'],size=p['source']['size'],sha256=p['source']['sha256'])]
checks=[]
for x in inputs:
 f=Path(x['path']);h=sha(f);checks.append({'path':str(f),'bytes_before':x['size'],'bytes_after':f.stat().st_size,'sha256_before':x['sha256'],'sha256_after':h,'status':'PASS' if h==x['sha256'] and f.stat().st_size==x['size'] else 'FAIL'})
pd.DataFrame(checks).to_csv(O/'review/new_inputs_pre_post_hash_check.tsv',sep='\t',index=False);assert all(x['status']=='PASS' for x in checks)
# Preserve inherited audit evidence and name its historical scope accurately.
hist=O/'review/prior_release_checks/organoid_evidence_resolution_before_count_analysis.md'
if not hist.exists():shutil.copy2(O/'review/organoid_evidence_resolution.md',hist)
auditcopies=[]
for n in ['organoid_sheet_audit.tsv','organoid_comparison_audit.tsv']:
 src=P/'review'/n;dst=O/'review'/n;shutil.copy2(src,dst);auditcopies.append({'source':str(src),'copy':str(dst),'sha256':sha(src),'scope':'Inherited single-point worksheet audit; not claimed as new re-audit'})
put(O/'review/inherited_organoid_audit_manifest.json',auditcopies)
audit=f'''# 类器官定点核查与本轮计数分析

原工作表审计保存在 prior_release_checks/organoid_evidence_resolution_before_count_analysis.md；逐表、逐比较记录见本目录两个 organoid_*_audit.tsv。本次没有把旧审计重新冒充为新审计。

本轮已按用户后续授权完成 C 类定点重分析。原 TA/Colonocyte 出版表的模型与导出过程仍未唯一对应，相关旧结果继续标为 export-based。新结果直接使用完整发布 RNA counts，供者、控制、基因背景与模型均可追溯，支持明确限定的转录效应解释。它不是新独立类器官队列，也不回溯证明旧表每个统计值。

来源：[GSE313368 完整发布对象]({p['source']['url']})，{p['source']['size']:,} 字节，SHA-256 `{p['source']['sha256']}`；[正式论文](https://www.nature.com/articles/s41467-025-68247-6)；Genentech/secretome_dictionary 提交 `3c80f66552d9c3ea344ba02304eb588b717e9ed8`（固定源码在 provenance/Capeling_Figure_4_Code_pinned.Rmd）。

|核查项|已确认事实|处理|
|---|---|---|
|旧工作表|MOESM10 A_TA_DEGs / D_Colonocyte_DEGs 为旧基因效应输入；B_Stem_DEGs / C_Goblet_DEGs 重复且原版已排除|不改变旧统计，重复表不作为两个独立家族|
|原统计背景|旧 GSEA 使用有限 LFC/正 SE，非后续签名 padj 过滤；公开示例包含 ashr 收缩与删除缺失 padj|旧 LFC/SE 明确为外部效应/不确定性分数，不当成未收缩 Wald 统计量|
|新统计输入|RNA counts {js(E/'review/preflight_QC.json')['released_genes']:,} 基因 × {js(E/'review/preflight_QC.json')['released_cells']:,} 细胞；全部 nCount/nFeature 与源 metadata 一致，gzip CRC 通过|流式读原对象，不加载/复制全环境；每个保留细胞有源列键|
|细胞注释|按固定原作者代码合并成熟/未成熟 Colonocyte 和 Goblet 注释|四家族来自同三位供者，不能称四个独立队列|
|配体与对照|TNFSF12、原六个其他方向提名；No_Cytomix 单列实验参照；同 donor/pool/family 的 Sato cytomix-only 孔为控制|先匹配池，再在供者内汇总；每臂每池 ≥20 细胞；三个配对供者才估计|
|背景与模型|条件盲总计数 ≥10；DESeq2 ~ donor + treatment；不收缩 LFC、不自动替换离群值；保留缺失|GSEA 用有限未收缩 Wald 统计量，不按 P/FDR 预筛；全部基因结果均输出|
|集合检验|固定 V1 基因集，fgseaSimple 10,000 permutations，种子 20260826|主 TNFSF12 16、其余原提名 96、参照 16 项分别 BH，缺失保留计划分母|
|实际可估计范围|{z['models_completed']} 个模型、{z['estimated_GSEA_tests']}/{z['planned_GSEA_tests']} 项集合检验；其余不够三个配对供者|全范围保留，不按显著性挑图|
|66 基因|实际原代码读取正 leading edge；不是显著基因交集|冻结不重选；新 TA 模型 {v['core_TA_positive']}/66 正效应，{v['core_TA_gene_FDR05']} 个单基因 FDR<0.05|
|IBD2 2.58|四个已发表细胞类型 Cohen d 的中位数 2.5778224281|不是供者中位数；原效应和出版方 FDR 在补图14b，量纲与 NES 分开|

可作出的判断：TA 的固定 ICI disease-depleted 集合在供者调整模型中正向富集，且三位供者的相对表达秩均增加；SORL1 的单基因效应与其方向一致。不能作出的判断：功能修复、SORL1 因果作用、药理安全性、独立扰动复制或对全部79配体重新校正的筛选成功。

Stem/Goblet 的供者平均秩变化与集合 NES 不必同向；两者估计对象不同，已同时展示。三供者精确符号翻转的最小双侧 P 为0.25，所有此类 FDR 均未达0.05。fgsea 的排序并列警告及包构建版本警告保留在真实 stderr，不以无警告或无统计限制宣称放行。

首轮 No_Cytomix 名称解析错误导致参照未估计，尽管 R 返回0；已判为语义失败并保留。修复后重新在独立结果子目录执行，全部参照可估计，112个原主/次级计划结果不变。最终结果目录：`{R.relative_to(O).as_posix()}`。
'''
(O/'review/organoid_evidence_resolution.md').write_text(audit,encoding='utf-8')
# Complete supplementary captions remain synchronized with the accepted Word text.
capt=O/'supplementary/Supplementary_figure_legends.md';old=capt.read_text(encoding='utf-8').split('Supplementary Figure 7.')[0]
para=js(O/'review/manuscript_change_record.json')['paragraphs']
new='\n\n'.join(x['revised'] for x in para if re.match(r'V1ADD_SF(?:[7-9]|1[0-6])_(?:TITLE|LEGEND)$',x['id']))
capt.write_text(old+new+'\n',encoding='utf-8')
# Executed process log inventory retains failures and real exit codes.
logs=[]
for f in sorted((O/'logs').glob('*.json')):
 try:j=js(f)
 except Exception:continue
 if isinstance(j,dict) and 'command' in j:
  logs.append({'record':str(f.relative_to(O)),'start_utc':j.get('start_utc'),'end_utc':j.get('end_utc'),'exit_code':j.get('exit_code'),'command':json.dumps(j['command'],ensure_ascii=False),'classification':'EXECUTED_SUCCESS' if j.get('exit_code')==0 else 'RETAINED_FAILED_ATTEMPT; inspect subsequent fixed step','stdout':j.get('stdout'),'stderr':j.get('stderr')})
pd.DataFrame(logs).to_csv(O/'review/executed_commands.tsv',sep='\t',index=False)
scriptrows=[]
for folder in ['analysis_code','presentation_code']:
 for f in sorted((O/folder).glob('*')):
  if f.suffix in ['.py','.R','.ps1']:
   if f.suffix=='.py':ast.parse(f.read_text(encoding='utf-8-sig'))
   scriptrows.append({'file':str(f.relative_to(O)),'sha256':sha(f),'size':f.stat().st_size,'role':'analysis' if folder=='analysis_code' else 'presentation / provenance / validation'})
for f in O.glob('RUN_*.ps1'):scriptrows.append({'file':f.name,'sha256':sha(f),'size':f.stat().st_size,'role':'separate checked entry'})
pd.DataFrame(scriptrows).to_csv(O/'supplementary/tables/Table_S62_reproducibility_script_inventory.tsv',sep='\t',index=False)
put(O/'review/python_static_check.json',{'status':'PASS','scripts':len(scriptrows),'scope':'Python AST parse; runtime logs separately recorded'})
report=f'''# 本轮实际改变了什么

此前空间候选包与 submission_candidate_V1.zip 的共同核心数值一致：40份共同 panel 源表中39份完全相同，1份仅7处类别标签变化；14,048个非缺失数值单元（包括数值ID，并非14,048项检验）无差异。此前主要完成呈现、解释纠错及空间扩展，未解决类器官推断来源缺口。本轮增加了真正的新模型结果。

|证据环节|本轮结果|科学意义与边界|
|---|---|---|
|患者 ICI 程序 → 配体扰动|完整发布 counts 的三供者配对模型：TA disease-depleted NES={ta.NES:.6f}，主检验族 FDR={ta.FDR_predeclared_family:.8f}|补强可追溯的疾病—扰动转录连接；不与旧 screen FDR直接比较优劣|
|真实供者一致性|TA三位供者均正向，平均秩变化={pa.mean_paired_rank_change:.6f}|不是虚构供者点；精确双侧检验未显著，供者数只有3|
|固定程序 → 下游基因|SORL1 log2FC={so.log2FoldChange:.6f}，单基因FDR={so.padj:.6f}；冻结66基因中{v['core_TA_positive']}正向、{v['core_TA_gene_FDR05']}个FDR<0.05|基因层与集合层分别支持；未证明SORL1因果作用|
|IFN之外的组织关联|外部8病例/5对照；8项条件检验无FDR<0.05；3家族无IFN范围重叠|这部分证据没有提高；保留不确定性，不能声称统计独立|
|空间测量|Oxford16供者方向一致但未过FDR；Xenium9供者标签与发现队列重叠|保留定位与外部方向信息，不包装成独立机制验证|
|肿瘤关联、心脏/结肠与TCR|全部原模型和估计保留|没有改阈值、换候选、重选核心或用AXIS显著性替换GENE|

改动类型：A类完成六主图布局、真实效应展示、英文学术表述及方法说明；B类保留已核实的计数、单位、标签修复，详见中文逐项修改账本.tsv；C类按本轮后续明确授权，完成供者计数模型及IFN条件分析，模型计划在新结果计算前记录。没有运行旧全量入口，没有用IBD程序替换ICI程序，没有按显著性换数据集或调参。

主图顺序保持1设计、2组织受体、3冻结转移、4类器官、5肿瘤、6TCR。主图4b/c现在展示新模型和真实供者，原b/c移至补图14a/b；主图5c并列SORL1新旧估计。共6张主图及25张补图图版，PDF/600dpi TIFF/PNG齐全。连续补表S1–S79、每panel源表和记录键、完整25个基因模型与全部不可估计比较一并提供。

红字Word直接以原第一版DOCX编辑；357个新增红字run、293个删除红字run，删除线为实际字体属性。接受可视修改后的全文与干净版一致，其余DOCX部件、域、书签、引用与原格式检查通过。这是可视红字修改，不是Word原生修订追踪。

技术错误处理：子进程缺失Windows环境变量，通过单个子进程环境恢复解决；完整类器官对象已下载且前后哈希相同；R模型与R图件均实际运行成功；Word COM已真实生成28页干净版、29页红字版及逐页PNG。历史失败日志、参照名称语义失败和之后成功退出码同时保留。最终视觉复核另见visual_QA_signed.json，不以文件存在代替成功。

评价：科学证据链得到有限且实质的增强，主要是已冻结ICI程序到可追溯供者扰动再到SORL1的转录连接。尚未形成独立扰动复制、功能恢复或安全性证据，因此不保证期刊档次，也不宣称全部科学证据放行。

作者、单位、通讯、基金、CRediT、利益冲突、永久仓库/DOI及未指定期刊格式为USER_PENDING。它们不作为科学错误，也未编造。
'''
(O/'review/本轮科学证据与修改说明_CN.md').write_text(report,encoding='utf-8')
(O/'README_交付说明_CN.md').write_text('本包为基于原始第一版的定点重分析与红字修订候选，科学状态为QUALIFIED，不是全部证据已放行。\n\n请先读 review/本轮科学证据与修改说明_CN.md。核心成稿在 manuscript；六主图在 figures；补图分布于 supplementary、spatial_extension/figures、xenium_extension/figures。统一源表索引为 supplementary/source_index.tsv，panel映射为 review/ALL_PANEL_SOURCE_MAP.tsv。\n\nRUN_PRESENTATION_ONLY.ps1 仅呈现/验证；RUN_TARGETED_ANALYSIS.ps1 -Stage Verify 复核已算结果，-Stage Fixtures 跑小数据检查，-Stage Conditional/Organoid/Both 从明确版本化的输入在新 targeted_runs/唯一ID 下重新计算。计数读取与下载脚本在 analysis_code，运行日志保留在 logs。原项目与原数据路径仍为只读来源；未把大型源对象、下载分块或Python/R环境塞入ZIP。完整类器官下载对象在本输出目录new_data内，源地址、哈希与提取QC均已提供；迁移机器须按记录补齐所需原始输入。\n\nRUN_SPATIAL_EXTENSION.ps1为此前空间扩展的独立入口，代码与已完成结果明确继承并记录来源，不是本轮新增独立机制证据。逐页PDF和PNG位于review/render。文件修改后必须重新渲染和复核，旧视觉签名不可继续当作新文件已审阅。\n',encoding='utf-8')
print('REPORTS_AND_INPUT_HASHES_PASS')
