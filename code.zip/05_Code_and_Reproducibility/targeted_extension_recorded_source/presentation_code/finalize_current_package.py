"""Verify and seal this targeted V1 candidate. Never fit models or alter input data."""
from pathlib import Path
from datetime import datetime, timezone
import ast
import hashlib
import json
import re
import shutil
import zipfile
import xml.etree.ElementTree as ET
import pandas as pd

O = Path(__file__).resolve().parents[1]
stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
def js(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def rd(p): return pd.read_csv(p, sep='\t', float_precision='round_trip')
def sha(p):
    with p.open('rb') as f: return hashlib.file_digest(f, 'sha256').hexdigest()
def put(p, value): p.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')
def one(frame):
    assert len(frame) == 1, f'Ambiguous record count: {len(frame)}'
    return frame.iloc[0]

out = js(O/'review/output_verification.json')
cv = js(O/'review/conditional_verification.json')
E = O/'organoid_donor_extension'
completion = js(E/'review/analysis_complete.json')
nv = js(E/'review/numerical_verification.json')
rv = js(E/'review/read_only_model_verification.json')
assert out['overall'] == cv['status'] == completion['status'] == nv['status'] == rv['status'] == 'PASS'
R = Path(completion['output'])
assert R.resolve().is_relative_to((E/'results').resolve())

# A prior visual review cannot be transferred to changed documents or images.
visual = js(O/'review/visual_QA_signed.json')
assert visual['status'] == 'PASS'
for item in visual['files']:
    assert sha(O/item['path']) == item['sha256'], f'Stale visual review: {item["path"]}'
wordlogs = js(O/'logs/word_render_records.json')
assert all(x['exit_code'] == 0 for x in wordlogs)
assert sum(x['pages'] for x in wordlogs) == sum(visual['word_pages'].values())

# Check NEW narrative numbers against final model tables and actual clean DOCX.
with zipfile.ZipFile(O/'manuscript/manuscript_V1_revised_CLEAN.docx') as z:
    root = ET.fromstring(z.read('word/document.xml'))
W = '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
body = '\n'.join(''.join(p.itertext()) for p in root.iter(W+'p'))
g = rd(R/'module_GSEA.tsv')
d = rd(R/'donor_paired_effects.tsv')
s = rd(E/'source_data/SORL1_donor_gene_effects.tsv')
c = rd(O/'source_data/conditional_results.tsv')
core = rd(E/'source_data/frozen_core_donor_gene_effects.tsv')
module = 'ICI_COLITIS_EPITHELIAL_LOSS_STRICT'
ta = one(g[g.ligand.eq('TNFSF12') & g.celltype.eq('Transit_Amplifying') & g.module.eq(module)])
paired = one(d[d.ligand.eq('TNFSF12') & d.celltype.eq('Transit_Amplifying') & d.module.eq(module)])
sorl1 = one(s[s.celltype.eq('Transit_Amplifying') & s.gene.eq('SORL1')])
external = c[c.role.eq('independent_primary')]
claims = []
def claim(name, token, raw, source):
    assert token in body, f'New manuscript value not found: {name}: {token}'
    claims.append({'claim': name, 'rendered_token': token, 'raw_value': raw, 'source': source, 'status': 'PASS'})
claim('TA fixed depleted NES', f'NES={ta.NES:.3f}', ta.NES, str(R/'module_GSEA.tsv'))
claim('TA primary family FDR', f'FDR={ta.FDR_predeclared_family:.5f}', ta.FDR_predeclared_family, str(R/'module_GSEA.tsv'))
claim('TA donor rank change', f'mean paired change={paired.mean_paired_rank_change:.5f}', paired.mean_paired_rank_change, str(R/'donor_paired_effects.tsv'))
claim('TA donor direction count', f'all {int(paired.n_positive)} donors', paired.n_positive, str(R/'donor_paired_effects.tsv'))
claim('SORL1 TA log2FC', f'{sorl1.log2FoldChange:.3f}', sorl1.log2FoldChange, str(E/'source_data/SORL1_donor_gene_effects.tsv'))
claim('SORL1 TA gene FDR', f'{sorl1.padj:.4f}', sorl1.padj, str(E/'source_data/SORL1_donor_gene_effects.tsv'))
claim('External IFN conditional FDR range', f'{external.fdr.min():.3f}-{external.fdr.max():.3f}', f'{external.fdr.min()}-{external.fdr.max()}', 'source_data/conditional_results.tsv')
ta_core = core[core.celltype.eq('Transit_Amplifying')]
assert ta_core.gene.nunique() == len(ta_core)
assert int((ta_core.log2FoldChange > 0).sum()) == nv['core_TA_positive']
assert int((ta_core.padj < .05).sum()) == nv['core_TA_gene_FDR05']
assert int((external.fdr < .05).sum()) == cv['primary_FDR05']
pd.DataFrame(claims).to_csv(O/'review/new_manuscript_numeric_claims.tsv', sep='\t', index=False)

# Continuous supplements and resolvable, non-empty source keys.
index = rd(O/'supplementary/table_index.tsv')
sup = index[index.table.str.match(r'^Table_S\d+$')]
numbers = sorted(int(x.split('_S')[1]) for x in sup.table)
assert numbers == list(range(1, max(numbers)+1)) and sup.table.is_unique
assert index.file.is_unique
for f in index.file: assert (O/'supplementary/tables'/f).is_file(), f
actual_tables = list((O/'supplementary/tables').glob('Table_S*.tsv'))
assert len(actual_tables) == len(sup), 'Unindexed or duplicate supplemental table'
panel = rd(O/'review/ALL_PANEL_SOURCE_MAP.tsv')
assert panel[['panel', 'file', 'record_key', 'unit']].notna().all().all()
for names in panel.file:
    for name in names.split(';'):
        p = Path(name.strip())
        if not p.is_absolute(): p = O/p
        assert p.is_file(), f'Missing panel source: {p}'
sources = rd(O/'supplementary/source_index.tsv')
for _, item in sources.iterrows():
    assert sha(O/item['path']) == item.sha256, f'Source index drift: {item["path"]}'
original = rd(O/'review/input_hash_comparison.tsv')
new = rd(O/'review/new_inputs_pre_post_hash_check.tsv')
assert original.status.eq('PASS').all() and new.status.eq('PASS').all()
for _, item in original.iterrows():
    assert sha(Path(item.path)) == item.sha256_before, f'Original changed: {item.path}'

# Portable extraction provenance; the 10.8 GB immutable source stays outside ZIP.
extract = O/'new_data/organoid_extracted/parse_summary.json'
assert extract.is_file()
shutil.copy2(extract, E/'review/released_object_parse_summary.json')
plan = js(E/'review/analysis_plan_locked.json')
put(E/'review/released_object_location.json', {'source': plan['source'], 'included_in_zip': False,
    'reason': 'Immutable large released object is retained locally; processed inputs and all final estimates are included.'})

# Record successful mandatory executions while retaining all failed attempts.
logs = []
for f in sorted((O/'logs').glob('*.json')):
    j = js(f)
    if isinstance(j, dict) and 'command' in j:
        logs.append({'record': str(f.relative_to(O)), **j})
required = ['conditional_analysis.R', 'analyze_organoid.R', 'plot_v1.R', 'plot_conditional.R',
            'plot_organoid_supplement.R', 'edit_docx.py', 'render_word.ps1', 'render_figure_pdfs.py',
            'render_final_word_pages.py', 'verify_outputs.py', 'verify_conditional.py', 'verify_models_readonly.py']
executions = {}
for script in required:
    hits = [x for x in logs if any(Path(arg).name == script for arg in x['command']) and x['exit_code'] == 0]
    assert hits, f'No actual successful execution: {script}'
    executions[script] = [x['record'] for x in hits]
pd.DataFrame([{'record': x['record'], 'start_utc': x.get('start_utc'), 'end_utc': x.get('end_utc'),
    'exit_code': x['exit_code'], 'command': json.dumps(x['command'], ensure_ascii=False),
    'classification': 'EXECUTED_SUCCESS' if x['exit_code'] == 0 else 'RETAINED_FAILED_ATTEMPT',
    'stdout': x.get('stdout'), 'stderr': x.get('stderr')} for x in logs]).to_csv(O/'review/executed_commands.tsv', sep='\t', index=False)
scripts = []
for folder in ['analysis_code', 'presentation_code']:
    for f in sorted((O/folder).glob('*')):
        if f.suffix in ['.py', '.R', '.ps1']:
            if f.suffix == '.py': ast.parse(f.read_text(encoding='utf-8-sig'))
            scripts.append({'file': str(f.relative_to(O)), 'sha256': sha(f), 'size': f.stat().st_size, 'role': folder})
for f in O.glob('RUN_*.ps1'):
    scripts.append({'file': f.name, 'sha256': sha(f), 'size': f.stat().st_size, 'role': 'isolated entry'})
pd.DataFrame(scripts).to_csv(O/'supplementary/tables/Table_S62_reproducibility_script_inventory.tsv', sep='\t', index=False)
put(O/'review/python_static_check.json', {'status': 'PASS', 'scripts': len(scripts), 'scope': 'Python AST; actual runtime checks separately logged'})
status = {'created_utc': datetime.now(timezone.utc).isoformat(), 'science': 'QUALIFIED',
    'science_limits': ['Same three organoid donors, not independent perturbation replication',
        'Fixed prior nominees; primary BH family is not a new full secretome screen',
        'External IFN-adjusted associations did not meet FDR; limited covariate overlap',
        'Old published export-to-model mapping remains qualified; new raw-count models explicitly separate',
        'Transcriptional response does not establish functional restoration, SORL1 causality or safety'],
    'numerical': 'PASS', 'redline': 'PASS', 'layout': 'PASS', 'runtime': 'PASS',
    'authors': 'USER_PENDING', 'submission_ready': False,
    'user_pending': ['Authors', 'Affiliations', 'Correspondence', 'Funding', 'CRediT', 'Competing interests', 'Repository/DOI', 'Journal format'],
    'word_pages': visual['word_pages'], 'figure_plates': visual['figure_plates'], 'supplementary_tables': len(sup),
    'panel_numeric_cells_checked': out['numeric_cells_checked'], 'original_inputs_unchanged': len(original),
    'gene_rows_independently_checked': rv['gene_rows_checked'], 'donor_scores_checked': rv['donor_scores'],
    'mandatory_execution_records': executions, 'canonical_organoid_results': str(R.relative_to(O)),
    'runtime_scope': 'Actual component executions, targeted Fixtures/Verify and presentation Verify. Fresh-run model modes of new entry are not claimed rerun.',
    'historical_failures': 'Retained; first No_Cytomix semantic failure is not equated with success merely because exit was zero.'}
put(O/'review/final_status.json', status)

# Select explicit output trees; no source project/environment/raw-object copy.
allowed = {'analysis_code', 'presentation_code', 'figures', 'manuscript', 'logs', 'provenance',
           'review', 'source_data', 'supplementary', 'spatial_extension', 'xenium_extension', 'organoid_donor_extension'}
excluded_meta = {'artifact_manifest.tsv', 'review/package_verification.json',
                 'supplementary/tables/Table_S63_final_artifact_manifest.tsv'}
def selected(p):
    rel = p.relative_to(O)
    if not p.is_file() or '__pycache__' in rel.parts or p.suffix in {'.pyc', '.zip'}: return False
    if rel.as_posix() in excluded_meta: return False
    if len(rel.parts) == 1: return p.name.startswith('RUN_') or p.name == 'README_交付说明_CN.md'
    if rel.parts[0] not in allowed: return False
    if rel.parts[:2] == ('organoid_donor_extension', 'results') and rel.parts[2] != R.name: return False
    return True
files = sorted((p for p in O.rglob('*') if selected(p)), key=lambda p: p.relative_to(O).as_posix())
manifest = [{'path': p.relative_to(O).as_posix(), 'bytes': p.stat().st_size, 'sha256': sha(p)} for p in files]
manifest_note = ('Manifest excludes its own two copies, ZIP, post-archive verification and wrapper log completed after sealing. '
                 'All excluded items are identified explicitly; archive entries including manifests are independently verified after writing.')
(O/'review/artifact_manifest_scope.txt').write_text(manifest_note+'\n', encoding='utf-8')
scopefile = O/'review/artifact_manifest_scope.txt'
if scopefile not in files:
    files.append(scopefile)
    manifest.append({'path': scopefile.relative_to(O).as_posix(), 'bytes': scopefile.stat().st_size, 'sha256': sha(scopefile)})
manifest.sort(key=lambda x: x['path'])
mf = pd.DataFrame(manifest)
mf.to_csv(O/'artifact_manifest.tsv', sep='\t', index=False)
mf.to_csv(O/'supplementary/tables/Table_S63_final_artifact_manifest.tsv', sep='\t', index=False)
files += [O/'artifact_manifest.tsv', O/'supplementary/tables/Table_S63_final_artifact_manifest.tsv']
expected = {p.relative_to(O).as_posix(): {'sha256': sha(p), 'bytes': p.stat().st_size} for p in files}
target = O/f'submission_candidate_V1_targeted_{stamp}.zip'
assert not target.exists()
with zipfile.ZipFile(target, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6, allowZip64=True) as z:
    for p in files: z.write(p, p.relative_to(O).as_posix())
with zipfile.ZipFile(target) as z:
    assert len(z.namelist()) == len(set(z.namelist()))
    assert set(z.namelist()) == set(expected)
    assert z.testzip() is None
    for name, item in expected.items():
        with z.open(name) as stream: actual = hashlib.file_digest(stream, 'sha256').hexdigest()
        assert actual == item['sha256'] and z.getinfo(name).file_size == item['bytes'], name
        assert sha(O/name) == item['sha256'], f'Changed while archiving: {name}'
archive_sha = sha(target)
target.with_suffix('.zip.sha256').write_text(archive_sha+'  '+target.name+'\n', encoding='ascii')
verification = {'package_integrity': 'PASS', 'science': status['science'], 'submission_ready': False,
    'zip': str(target), 'bytes': target.stat().st_size, 'sha256': archive_sha, 'entries': len(expected),
    'verification': 'Full ZIP CRC, unique member set, every entry SHA-256 and size, and live-file hashes checked',
    'completed_utc': datetime.now(timezone.utc).isoformat(), 'state': status,
    'scope_exclusions': manifest_note, 'exit_code': 0}
put(O/'review/package_verification.json', verification)
print(json.dumps({k: verification[k] for k in ['package_integrity', 'science', 'zip', 'bytes', 'sha256', 'entries']}, ensure_ascii=False))
