"""Assemble existing estimates and their provenance; no model fitting."""
from pathlib import Path
import json,hashlib,shutil,re
import pandas as pd
from pypdf import PdfReader
from PIL import Image
O=Path(__file__).resolve().parents[1]
def rd(p):return pd.read_csv(p,sep='\t',float_precision='round_trip')
def save(d,p):d.to_csv(p,sep='\t',index=False,na_rep='NA')
def sha(p):return hashlib.file_digest(open(p,'rb'),'sha256').hexdigest()
R=Path(json.loads((O/'organoid_donor_extension/review/analysis_complete.json').read_text())['output'])
T=O/'supplementary/tables';idx=rd(O/'supplementary/table_index.tsv');idx=idx[~idx.table.str.match(r'Table_S7[2-9]$')]
spec=[(72,'IFN_conditional_models',O/'source_data/conditional_results.tsv','All external models and separately identified discovery self-checks'),
 (73,'IFN_leave_patient_out',O/'source_data/conditional_leave_patient_out.tsv','Every leave-one-patient-out coefficient; patient scores and overlap linked in supplementary/source_index.tsv'),
 (74,'organoid_matched_pool_eligibility',O/'organoid_donor_extension/source_data/matched_pool_eligibility.tsv','Every matched pool and cell threshold decision'),
 (75,'organoid_model_inventory',R/'model_inventory.tsv','All planned donor models and reasons for non-estimability'),
 (76,'organoid_complete_frozen_GSEA',R/'module_GSEA.tsv','All 128 planned tests, fixed primary/secondary/reference BH families'),
 (77,'organoid_donor_programme_scores',R/'donor_module_scores.tsv','All 600 donor scores; donor rather than cell is replicate'),
 (78,'organoid_paired_donor_effects',R/'donor_paired_effects.tsv','All 100 exact donor-level tests with every paired change'),
 (79,'organoid_frozen_core_gene_effects',O/'organoid_donor_extension/source_data/frozen_core_donor_gene_effects.tsv','Every original core member in all four TNFSF12 donor models')]
for n,label,src,scope in spec:
 name=f'Table_S{n}_{label}.tsv';shutil.copy2(src,T/name)
 if n==73:
  pieces=[]
  for kind,rel in [('leave_one_patient_out','source_data/conditional_leave_patient_out.tsv'),('model_input_score','source_data/conditional_model_input.tsv'),('overlap_leverage_diagnostic','source_data/conditional_patient_diagnostics.tsv')]:
   part=rd(O/rel);part.insert(0,'record_type',kind);part.insert(1,'source_file',rel);part.insert(2,'source_row',range(1,len(part)+1));pieces.append(part)
  save(pd.concat(pieces,ignore_index=True,sort=False),T/name)
  scope='All leave-one-patient-out coefficients, patient scores and diagnostics; record_type identifies schemas; blank fields belong to another record type, not imputed measurements'
 idx=pd.concat([idx,pd.DataFrame([{'table':f'Table_S{n}','file':name,'scope':scope}])],ignore_index=True)
save(idx,O/'supplementary/table_index.tsv')
assert sorted(int(s[7:]) for s in idx.table if s.startswith('Table_S'))==list(range(1,80))
# Preserve the inherited interpretation before adding current-model status.
p=T/'Table_2_final_candidate_decisions.tsv';d=rd(p);old=O/'review/prior_release_checks/Table_2_before_new_model_notes.tsv'
if not old.exists():shutil.copy2(p,old)
d['organoid_input_status']='New count-based models verified; original publisher model/export correspondence remains qualified'
d['new_analysis_scope']='Targeted sensitivity in the same three donors; fixed V1 nominations and gene sets; no new therapeutic decision rule'
d['new_analysis_source']='Tables S74-S79; complete gene tables in organoid_donor_extension/results'
save(d,p)
# Actual PDF dimensions govern the export verification, not filename assumptions.
rows=[]
for folder in ['figures','supplementary','spatial_extension/figures','xenium_extension/figures']:
 for p in sorted((O/folder).glob('*.pdf')):
  pdf=PdfReader(p);assert len(pdf.pages)==1
  b=pdf.pages[0].mediabox
  with Image.open(p.with_suffix('.tiff')) as im:
   dpi=im.info['dpi'];assert all(abs(v-600)<.1 for v in dpi)
   w,h=im.width/600,im.height/600
  assert abs(w-float(b.width)/72)<1/72 and abs(h-float(b.height)/72)<1/72
  rows.append({'figure':p.stem,'base_path':p.with_suffix('').relative_to(O).as_posix(),'width_in':w,'height_in':h,'tiff_dpi':600})
save(pd.DataFrame(rows),O/'review/ALL_figure_dimensions.tsv')
S=Path('E:/ICI_irAE_Original_Project');scores=rd(next((S/'tables_for_article').glob('Table_S55_*')));perf=rd(next((S/'tables_for_article').glob('Table_S56_*')))
den=[]
for z in perf.itertuples():
 d=scores[scores.dataset.eq(z.dataset)&scores.celltype.eq(z.celltype)&scores.module.eq(z.module)]
 a=d[d.condition.eq(z.case)].sample_id.nunique();b=d[d.condition.eq(z.control)].sample_id.nunique()
 den.append({'dataset':z.dataset,'celltype':z.celltype,'module':z.module,'case':z.case,'control':z.control,'counted_case':a,'counted_control':b,'original_case':z.n_case,'original_control':z.n_control,'matches_original':a==z.n_case and b==z.n_control})
save(pd.DataFrame(den),O/'review/validation_denominators.tsv')
assert all(z['matches_original'] for z in den)
# Consolidate every panel source, with explicit relocation of original F4 panels.
maps=rd(O/'review/source_map.tsv').to_dict('records')
for z in maps:
 if z['panel']=='F4B':z['panel']='SF14a (original F4B source file)'
 if z['panel']=='F4C':z['panel']='SF14b (original F4C source file)'
 if z['panel']=='F4C_DONOR':z['record_key']='ligand=TNFSF12 | module=ICI_COLITIS_EPITHELIAL_LOSS_STRICT | celltype | donor | treatment; paired difference'
 if z['panel']=='F5C_display':z['original_source']='F5C_family; F5C_summary; F5C_DONOR'
 for key in ['file','original_source']:
  val=str(z.get(key,''))
  for oldroot in [str(O),O.as_posix()]:val=val.replace(oldroot+'\\','').replace(oldroot+'/','')
  z[key]=val
for rel in ['review/conditional_panel_source_map.tsv','review/organoid_supplement_panel_map.tsv','spatial_extension/review/panel_source_map.tsv','xenium_extension/review/panel_source_map.tsv']:
 m=rd(O/rel)
 for z in m.to_dict('records'):
  panel=' | '.join(str(z[k]) for k in ['figure','panel','sections'] if k in z)
  source=z.get('source',z.get('sources',''))
  if rel.startswith(('spatial_extension/','xenium_extension/')):
   source='; '.join(rel.split('/')[0]+'/source_data/'+f.strip() for f in source.split(';'))
  maps.append({'panel':panel,'file':source,'original_source':source,'record_key':z.get('key',z.get('record_key','See source table ID columns')),'unit':z.get('unit',z.get('statistical_unit','See source map')),'transformation':f'Existing estimates; map: {rel}'})
for k,src in [('F1C_new_spatial_counts','spatial_extension/source_data/sample_manifest.tsv;spatial_extension/source_data/section_QC.tsv'),('F1C_xenium_counts','xenium_extension/review/analysis_summary.json')]:
 maps.append({'panel':k,'file':'source_data/'+k+'.tsv','original_source':src,'record_key':'patient; section; assigned cells; counts separately','unit':'patients and observations separately','transformation':'metadata counts'})
save(pd.DataFrame(maps),O/'review/ALL_panel_source_map.tsv')
source=[]
for folder in ['source_data','organoid_donor_extension/source_data',str(R.relative_to(O)),'spatial_extension/source_data','xenium_extension/source_data']:
 for p in sorted((O/folder).rglob('*')):
  if p.is_file():source.append({'path':p.relative_to(O).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p),'role':'Source data / complete estimates; biological keys retained in file'})
save(pd.DataFrame(source),O/'supplementary/source_index.tsv')
# A row-level Chinese edit ledger includes original and revised text and source.
led=rd(O/'review/changes.tsv');save(led,O/'review/中文逐项修改账本.tsv')
print(f'ASSEMBLY_PASS: {len(rows)} figure plates; Table S1-S79; {len(source)} source files')
