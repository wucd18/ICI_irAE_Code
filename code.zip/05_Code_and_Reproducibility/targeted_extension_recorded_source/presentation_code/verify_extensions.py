"""Check new-cohort units, frozen scores, source keys and publication formats."""
from pathlib import Path
import pandas as pd,numpy as np,json,hashlib,sys,re
from scipy import sparse,stats
from PIL import Image
O=Path(__file__).resolve().parents[1];checks=[]
def ck(name,ok,detail=''):checks.append({'check':name,'status':'PASS' if bool(ok) else 'FAIL','detail':str(detail)})
def rd(p):return pd.read_csv(p,sep='\t',float_precision='round_trip',low_memory=False)
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(4*1024**2),b''):h.update(b)
 return h.hexdigest()
x=O/'spatial_extension';sd=x/'source_data';pt=rd(sd/'patient_scores.tsv');sm=rd(sd/'sample_manifest.tsv');q=rd(sd/'section_QC.tsv');t=rd(sd/'frozen_transfer_results.tsv');cv=rd(sd/'module_coverage.tsv')
ck('Oxford_unique_patient_module',not pt.duplicated(['patient','module']).any())
ck('Oxford_repeated_sections_count_once',sm.groupby('patient').condition.nunique().eq(1).all() and pt.patient.nunique()==sm.patient.nunique())
ck('Oxford_four_frozen_tests',len(t)==cv.module.nunique()==4 and set(t.module)==set(cv.module))
for row in t.itertuples():
 d=pt[pt.module.eq(row.module)];a=d.loc[d.condition.eq('ICI colitis'),'oriented_score'];b=d.loc[d.condition.eq('Healthy'),'oriented_score'];u=stats.mannwhitneyu(a,b,alternative='two-sided')
 ck(row.module+'_patient_U_P_denominators',row.n_case==len(a) and row.n_control==len(b) and np.isclose(u.statistic,row.U) and np.isclose(u.pvalue,row.P))
 ck(row.module+'_patient_median_difference',np.isclose(a.median()-b.median(),row.median_difference))
order=np.argsort(t.P.to_numpy());bh=np.minimum.accumulate((t.P.to_numpy()[order]*len(t)/np.arange(1,len(t)+1))[::-1])[::-1];back=np.empty(len(t));back[order]=np.minimum(bh,1)
ck('Oxford_BH_all_four_tests',np.allclose(back,t.FDR_new_four_module_family))
v=rd(sd/'common_feature_universe.tsv');mp=rd(sd/'frozen_gene_identity_map.tsv');cols=rd(sd/'patient_matrix_columns.tsv');a=sparse.load_npz(sd/'patient_pseudobulk_counts.npz').toarray();ranks=stats.rankdata(a,axis=0,method='average')/a.shape[0]
for row in pt.itertuples():
 j=int(cols.loc[cols.patient.eq(row.patient),'matrix_column_1based'].iloc[0])-1
 ids=set(mp.loc[mp.module.eq(row.module)&mp.status.eq('MAPPED'),'feature_id']);raw=ranks[v.feature_id.isin(ids).to_numpy(),j].mean()
 ck(row.record_key+'_frozen_rank',np.isclose(raw,row.raw_score) and np.isclose(row.oriented_score,1-raw if row.expected_direction=='down' else raw))
sp=rd(sd/'spot_scores.tsv.gz');ck('Oxford_spot_keys_unique',not sp.duplicated(['gsm','barcode','module']).any());ck('Oxford_total_spots_by_source',sp[['gsm','barcode']].drop_duplicates().shape[0]==q.kept_tissue_spots.sum())
ck('Oxford_coordinates_finite',np.isfinite(sp[['x','y']]).all().all());ck('Oxford_patient_scores_finite',np.isfinite(pt[['raw_score','oriented_score']]).all().all())
manifest=rd(x/'review/input_manifest_before.tsv');ck('Oxford_inputs_unchanged',all(sha(z.path)==z.sha256 for z in manifest.itertuples()))
x=O/'xenium_extension';sd=x/'source_data'
summary=json.loads((x/'review/analysis_summary.json').read_text());pt=rd(sd/'patient_compartment_scores.tsv');g=rd(sd/'patient_gene_expression.tsv');c=rd(sd/'cell_coordinates_scores.tsv.gz');v=rd(sd/'panel_genes.tsv');keys=rd(sd/'pseudobulk_column_keys.tsv');a=sparse.load_npz(sd/'patient_compartment_counts.npz').toarray();mp=rd(sd/'frozen_gene_map.tsv')
ck('Xenium_not_counted_as_new_independent_cohort',summary['independent_new_cohorts']==0 and summary['hypothesis_tests']==0)
ck('Xenium_cell_keys_unique',not c.cell_key.duplicated().any());ck('Xenium_patient_compartment_module_unique',not pt.duplicated(['patient','compartment','module']).any());ck('Xenium_panel_size_matches_matrix',a.shape==(len(v),len(keys)))
ranks=stats.rankdata(a,axis=0,method='average')/a.shape[0]
for row in pt.itertuples():
 j=int(keys.index[keys.patient.eq(row.patient)&keys.compartment.eq(row.compartment)][0]);genes=set(mp.loc[mp.module.eq(row.module)&mp.status.eq('PRESENT'),'gene']);raw=ranks[v._index.isin(genes),j].mean()
 ck(row.record_key+'_targeted_frozen_rank',np.isclose(raw,row.raw_rank) and np.isclose(row.oriented_rank,1-raw if row.module.endswith('LOSS_STRICT') else raw))
for row in g.itertuples():
 d=c[c.analysis_included&c.patient.eq(row.patient)&c.compartment.eq(row.compartment)];values=d[row.gene+'_molecules']
 ck(row.record_key+'_observed_molecules',len(d)==row.n_cells and values.sum()==row.total_molecules and np.isclose(values.mean(),row.mean_molecules_per_cell) and np.isclose((values>0).mean(),row.fraction_positive_cells))
ck('Xenium_raw_scores_finite',np.isfinite(pt[['raw_rank','oriented_rank']]).all().all());ck('Xenium_no_missing_target_molecules',not c.filter(regex='_molecules$').isna().any().any())
vk=rd(sd/'spatial_view_cell_keys.tsv.gz');vb=rd(sd/'spatial_view_bounds.tsv');inc=c[c.analysis_included]
ck('Xenium_display_tiles_keep_every_assigned_cell',not vk.cell_key.duplicated().any() and set(vk.cell_key)==set(inc.cell_key))
ck('Xenium_display_tile_counts_match',vb.n_cells.sum()==len(inc))
for row in vb.itertuples():
 ids=vk.loc[vk.patient.eq(row.patient)&vk.view_tile.eq(row.tile),'cell_key'];z=inc[inc.cell_key.isin(ids)]
 ck(row.view_key+'_native_coordinate_bounds',len(z)==row.n_cells and np.allclose([z.x_centroid.min(),z.x_centroid.max(),z.y_centroid.min(),z.y_centroid.max()],[row.xmin,row.xmax,row.ymin,row.ymax]))
# Decode every new raster at its final physical dimensions.
for name in ['spatial_extension','xenium_extension']:
 x=O/name;dims=rd(x/'review/figure_dimensions.tsv')
 for row in dims.itertuples():
  for suffix,dpi in [('.tiff',600),('_preview.png',200)]:
   f=x/'figures'/(row.figure+suffix)
   with Image.open(f) as im:
    im.load();ok=all(abs(k-round(z*dpi))<=1 for k,z in zip(im.size,[row.width_in,row.height_in]));info=im.info.get('dpi',(0,0))
    if dpi==600:ok=ok and all(abs(k-600)<.1 for k in info)
    ck(row.figure+suffix+'_physical_format',ok,f'{im.size}, dpi={info}')
  ck(row.figure+'_PDF_signature',(x/'figures'/(row.figure+'.pdf')).read_bytes().startswith(b'%PDF'))
 index=rd(x/'review/panel_source_map.tsv');ck(name+'_source_map_present',len(index)>0)
tab=rd(O/'supplementary/table_index.tsv');n=sorted(tab[tab.table.str.startswith('Table_S')].table.str.extract(r'(\d+)$')[0].astype(int).tolist());ck('Supplement_tables_continuous',n==list(range(1,max(n)+1)))
report=pd.DataFrame(checks);report.to_csv(O/'review/extension_verification.tsv',sep='\t',index=False)
result={'status':'PASS' if report.status.eq('PASS').all() else 'FAIL','checks':len(report),'failed_checks':report.loc[report.status.ne('PASS')].to_dict('records'),'scope':'numerical and format verification; no claim that biological hypotheses or source-model applicability all passed'}
(O/'review/extension_verification.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2));sys.exit(0 if result['status']=='PASS' else 1)
