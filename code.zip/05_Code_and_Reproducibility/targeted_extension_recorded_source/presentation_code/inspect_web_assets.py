from pathlib import Path
import re,json
O=Path(__file__).resolve().parents[1]
t=(O/'new_data/mendeley.html').read_text(encoding='utf-8')
for m in re.finditer(r'.{0,70}(?:INITIAL|download_url|downloadUrl|public-api|"files"|Seurat|metadata|\.rds|\.zip).{0,130}',t):print(m.group()[:230])
print('PORTAL:',(O/'new_data/portal_loaded.html').read_text()[-1800:])
for m in re.finditer(r'<script[^>]*>(.*?)</script>',t,re.S):
 s=m.group(1)
 if len(s)>2000:
  (O/'new_data/mendeley_embedded.js').write_text(s,encoding='utf-8')
  print('SCRIPT',s[:250],s[-150:])
