$ErrorActionPreference='Stop'
$revisionRoot=Split-Path -Parent $PSScriptRoot
$word=$null
$records=@()
$attemptStart=(Get-Date).ToUniversalTime().ToString('o')
try {
 $word=New-Object -ComObject Word.Application
 $word.Visible=$false
 $word.DisplayAlerts=0
 $word.AutomationSecurity=3
 $word.Options.UpdateLinksAtOpen=$false
 foreach($tag in @('RED','CLEAN')) {
  $inputDoc=Join-Path $revisionRoot ('manuscript\manuscript_V1_revised_'+$tag+'.docx')
  $renderDir=Join-Path $revisionRoot ('review\render\'+$tag)
  New-Item -ItemType Directory -Path $renderDir -Force | Out-Null
  $pdf=Join-Path $renderDir ('manuscript_V1_revised_'+$tag+'.pdf')
  $start=(Get-Date).ToUniversalTime().ToString('o')
  $doc=$word.Documents.Open($inputDoc,$false,$true,$false)
  try {
   $doc.Repaginate()
   $pages=$doc.ComputeStatistics(2)
   $doc.ExportAsFixedFormat($pdf,17,$false,0,0,1,1,0,$true,$true,0,$true,$true,$false)
   $records+=[pscustomobject]@{input=$inputDoc;output=$pdf;pages=$pages;renderer='Microsoft Word COM';version=$word.Version;start_utc=$start;end_utc=(Get-Date).ToUniversalTime().ToString('o');exit_code=0}
  } finally { $doc.Close(0);[void][Runtime.InteropServices.Marshal]::ReleaseComObject($doc) }
 }
 $records|ConvertTo-Json -Depth 4|Set-Content -LiteralPath (Join-Path $revisionRoot 'logs\word_render_records.json') -Encoding utf8
} catch {
 [pscustomobject]@{renderer='Microsoft Word COM';start_utc=$attemptStart;end_utc=(Get-Date).ToUniversalTime().ToString('o');status='FAILED_TO_RENDER';error=$_.Exception.Message;hresult=$_.Exception.HResult}|ConvertTo-Json -Depth 4|Set-Content -LiteralPath (Join-Path $revisionRoot 'logs\word_render_failure.json') -Encoding utf8
 throw
} finally {
 if($null -ne $word){$word.Quit(0);[void][Runtime.InteropServices.Marshal]::ReleaseComObject($word)}
}
