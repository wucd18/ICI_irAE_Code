param([ValidateSet('Fixtures','Verify','Conditional','Organoid','Both')][string]$Stage='Verify')
$ErrorActionPreference='Stop'
$statPython='D:\Software\python\python.exe'
& $statPython (Join-Path $PSScriptRoot 'analysis_code\run_restored.py') $statPython '-X' 'utf8' (Join-Path $PSScriptRoot 'analysis_code\run_targeted.py') '--stage' $Stage
if($LASTEXITCODE -ne 0){throw "Targeted analysis failed with actual exit $LASTEXITCODE; logs retained."}
exit 0
